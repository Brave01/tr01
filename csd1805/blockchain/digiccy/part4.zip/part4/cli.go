package main

import (
	"flag"
	"fmt"
	"log"
	"os"
	"strconv"
)

// CLI responsible for processing command line arguments
type CLI struct{}

func (cli *CLI) createBlockchain(address string) {
	// 1 创建区块对象(创建数据库)，addresss是获取挖矿奖励的地址
	bc := CreateBlockchain(address)
	bc.db.Close()
	fmt.Println("Done!")
}

func (cli *CLI) getBalance(address string) {
	// 2 读取数据库中blocks表中的信息，创建区块链对象
	bc := NewBlockchain(address)
	defer bc.db.Close()

	balance := 0
	// 查找指定地址的未花费交易输出
	UTXOs := bc.FindUTXO(address)
	//遍历所有的未花费交易的输出
	for _, out := range UTXOs {
		// 将其中的“币”值相加
		balance += out.Value
	}
	// 打印指定地址的余额
	fmt.Printf("Balance of '%s': %d\n", address, balance)
}

// 打印使用方法
func (cli *CLI) printUsage() {
	fmt.Println("Usage:")
	fmt.Println("  getbalance -address ADDRESS - Get balance of ADDRESS")
	fmt.Println("  createblockchain -address ADDRESS - Create a blockchain and send genesis block reward to ADDRESS")
	fmt.Println("  printchain - Print all the blocks of the blockchain")
	fmt.Println("  send -from FROM -to TO -amount AMOUNT - Send AMOUNT of coins from FROM address to TO")
}

// 验证参数的个数
func (cli *CLI) validateArgs() {
	if len(os.Args) < 2 {
		// 提示用户的使用方法
		cli.printUsage()
		os.Exit(1)
	}
}

func (cli *CLI) printChain() {
	// 创建区块链对象
	bc := NewBlockchain("")
	defer bc.db.Close()
	//  创建迭代器
	bci := bc.Iterator()

	for {
		// 获取区块
		block := bci.Next()
		// 前一个区块的Hash
		fmt.Printf("Prev. hash: %x\n", block.PrevBlockHash)
		// 当前块的Hash
		fmt.Printf("Hash: %x\n", block.Hash)
		// 生成工作量证明
		pow := NewProofOfWork(block)
		// 工作量证明的验证
		fmt.Printf("PoW: %s\n", strconv.FormatBool(pow.Validate()))
		fmt.Println()
		// 判断上一个块的Hash为空时，遍历结束
		if len(block.PrevBlockHash) == 0 {
			break
		}
	}
}

func (cli *CLI) send(from, to string, amount int) {
	// 创建区块链对象
	bc := NewBlockchain(from)
	defer bc.db.Close()
	// 普通交易
	tx := NewUTXOTransaction(from, to, amount, bc)
	//挖矿，产生新的区块
	bc.MineBlock([]*Transaction{tx})
	fmt.Println("Success!")
}

// Run parses command line arguments and processes commands
func (cli *CLI) Run() {
	//验证参数的个数
	cli.validateArgs()
	// 1 获取余额的子命令
	getBalanceCmd := flag.NewFlagSet("getbalance", flag.ExitOnError)
	// 2 创建区块链的子命令
	createBlockchainCmd := flag.NewFlagSet("createblockchain", flag.ExitOnError)
	// 3 普通交易的子命令
	sendCmd := flag.NewFlagSet("send", flag.ExitOnError)
	// 4 打印区块链的子命令
	printChainCmd := flag.NewFlagSet("printchain", flag.ExitOnError)

	// 1.1 获取余额的参数
	getBalanceAddress := getBalanceCmd.String("address", "", "The address to get balance for")
	// 1.2 创建区块链子命令的的参数
	createBlockchainAddress := createBlockchainCmd.String("address", "", "The address to send genesis block reward to")

	// 1.3 send子命令的参数，from为发送者
	sendFrom := sendCmd.String("from", "", "Source wallet address")
	// send子命令的参数，to为接收者
	sendTo := sendCmd.String("to", "", "Destination wallet address")
	// send子命令的参数，amount为币值
	sendAmount := sendCmd.Int("amount", 0, "Amount to send")

	// 对命令行参数进行解析
	switch os.Args[1] {
	case "getbalance":
		// 获取余额的子命令的解析
		err := getBalanceCmd.Parse(os.Args[2:])
		if err != nil {
			log.Panic(err)
		}
	case "createblockchain":
		// 创建区块的子命令的解析
		err := createBlockchainCmd.Parse(os.Args[2:])
		if err != nil {
			log.Panic(err)
		}
	case "printchain":
		// 打印区块的子命令的解析
		err := printChainCmd.Parse(os.Args[2:])
		if err != nil {
			log.Panic(err)
		}
	case "send":
		// 普通交易的子命令的解析
		err := sendCmd.Parse(os.Args[2:])
		if err != nil {
			log.Panic(err)
		}
	default:
		// 用户的输入与任何一条命令都不匹配，打印使用信息
		cli.printUsage()
		os.Exit(1)
	}
	// 判断解析
	if getBalanceCmd.Parsed() {
		//如果没有获取地址参数
		if *getBalanceAddress == "" {
			//打印错误信息，并退出
			getBalanceCmd.Usage()
			os.Exit(1)
		}
		// 将用户输入的值作为参数，获取指定地址的余额
		cli.getBalance(*getBalanceAddress)
	}

	if createBlockchainCmd.Parsed() {
		// 如果没有获取地址参数
		if *createBlockchainAddress == "" {
			//打印错误信息并退出
			createBlockchainCmd.Usage()
			os.Exit(1)
		}
		// 将用户输入的值为参数，创建区块链对象
		cli.createBlockchain(*createBlockchainAddress)
	}

	if printChainCmd.Parsed() {
		// 直接调用
		cli.printChain()
	}

	if sendCmd.Parsed() {
		if *sendFrom == "" || *sendTo == "" || *sendAmount <= 0 {
			sendCmd.Usage()
			os.Exit(1)
		}
		// 调用send函数完成普通交易
		cli.send(*sendFrom, *sendTo, *sendAmount)
	}
}

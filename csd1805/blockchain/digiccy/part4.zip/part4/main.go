package main

func main() {
	// 创建命令行工具对象
	cli := CLI{}
	// 调用Run函数，与用户交互，并且调用区块链的相关函数
	cli.Run()
}

package main

import (
	"bytes"
	"crypto/sha256"
	"encoding/gob"
	"encoding/hex"
	"fmt"
	"log"
)

const subsidy = 10 //挖矿的奖励

// Transaction represents a Bitcoin transaction
type Transaction struct {
	ID   []byte
	Vin  []TXInput
	Vout []TXOutput
}

// IsCoinbase checks whether the transaction is coinbase
func (tx Transaction) IsCoinbase() bool {
	return len(tx.Vin) == 1 && len(tx.Vin[0].Txid) == 0 && tx.Vin[0].Vout == -1
}

// SetID sets ID of a transaction
func (tx Transaction) SetID() {
	var encoded bytes.Buffer
	var hash [32]byte

	enc := gob.NewEncoder(&encoded)
	err := enc.Encode(tx)
	if err != nil {
		log.Panic(err)
	}
	hash = sha256.Sum256(encoded.Bytes())
	tx.ID = hash[:]
}

// TXInput represents a transaction input
type TXInput struct {
	Txid      []byte
	Vout      int
	ScriptSig string
}

// TXOutput represents a transaction output
type TXOutput struct {
	Value        int
	ScriptPubKey string
}

// 输入的判断(目前仅仅是字符串比较)
func (in *TXInput) CanUnlockOutputWith(unlockingData string) bool {
	return in.ScriptSig == unlockingData
}

// 输出也一样(目前仅仅是字符串比较)
func (out *TXOutput) CanBeUnlockedWith(unlockingData string) bool {
	return out.ScriptPubKey == unlockingData
}

// 创币交易
func NewCoinbaseTX(to, data string) *Transaction {
	if data == "" {
		data = fmt.Sprintf("Reward to '%s'", to)
	}
	//输入是一些无效信息，因为创币交易没有输入
	txin := TXInput{[]byte{}, -1, data}
	//输出包含了"币"值和接收币的地址(目前仅仅是一个字符串)
	txout := TXOutput{subsidy, to}
	//构造交易对象
	tx := Transaction{nil, []TXInput{txin}, []TXOutput{txout}}
	// 设置交易的ID(Hash)
	tx.SetID()
	//返回交易的地址
	return &tx
}

// 普通交易
func NewUTXOTransaction(from, to string, amount int, bc *Blockchain) *Transaction {
	var inputs []TXInput
	var outputs []TXOutput
	// 获取指定地址可花费"币值"，以及包含币值额输出
	acc, validOutputs := bc.FindSpendableOutputs(from, amount)
	// 余额不足，产生异常，交易结束
	if acc < amount {
		log.Panic("ERROR: Not enough funds")
	}

	// 构造交易输入列表(引用了输出)
	for txid, outs := range validOutputs {
		txID, err := hex.DecodeString(txid)
		if err != nil {
			log.Panic(err)
		}

		for _, out := range outs {
			input := TXInput{txID, out, from}
			inputs = append(inputs, input)
		}
	}

	//构造交易输出列表(等于，大于两种情况)
	//等于这种情况，只有币的接收者有输出
	outputs = append(outputs, TXOutput{amount, to})
	if acc > amount {
		//大于这种情况，币的发送者也有输出
		outputs = append(outputs, TXOutput{acc - amount, from}) // a change
	}
	//构造交易
	tx := Transaction{nil, inputs, outputs}
	//设置交易ID
	tx.SetID()
	//返回普通交易
	return &tx
}

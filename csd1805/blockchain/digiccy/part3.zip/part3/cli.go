package main

import (
	"flag"
	"fmt"
	"log"
	"os"
	"strconv"
)

// 定义命令接口这个类型
type CLI struct {
	bc *Blockchain //字段是一个区块链对象地址
}

// 1 打印使用方法
func (cli *CLI) printUsage() {
	fmt.Println("Usage:")
	fmt.Println("  addblock -data BLOCK_DATA - add a block to the blockchain")
	fmt.Println("  printchain - print all the blocks of the blockchain")
}

// 2 验证参数(主要是验证参数的数量)
func (cli *CLI) validateArgs() {
	if len(os.Args) < 2 {
		cli.printUsage()
		os.Exit(1)
	}
}

// 3 添加区块(调用了区块链的函数)
func (cli *CLI) addBlock(data string) {
	cli.bc.AddBlock(data)
	fmt.Println("Success!")
}

// 4 打印区块链信息(调用了区块链迭代器)
func (cli *CLI) printChain() {
	// 调用区块链的Iterator()方法创建一个区块链迭代器
	bci := cli.bc.Iterator()

	for {

		// 调用迭代器的Next()，返回当前区块
		block := bci.Next()
		// 打印区块中所有的信息
		fmt.Printf("Prev. hash: %x\n", block.PrevBlockHash)
		fmt.Printf("Data: %s\n", block.Data)
		fmt.Printf("Hash: %x\n", block.Hash)
		pow := NewProofOfWork(block)
		fmt.Printf("PoW: %s\n", strconv.FormatBool(pow.Validate()))
		fmt.Println()
		// 循环的结束条件
		if len(block.PrevBlockHash) == 0 {
			break
		}
	}
}

// Run parses command line arguments and processes commands
func (cli *CLI) Run() {

	// 1 验证参数个数
	cli.validateArgs()
	// 2 创建两个子命令 addblock 有一个参数data
	addBlockCmd := flag.NewFlagSet("addblock", flag.ExitOnError)
	// printchain是没有参数
	printChainCmd := flag.NewFlagSet("printchain", flag.ExitOnError)
	// 为 addblock子命令添加参数
	addBlockData := addBlockCmd.String("data", "", "Block data")

	// 3 解析子命令的参数
	switch os.Args[1] {
	case "addblock":
		err := addBlockCmd.Parse(os.Args[2:])
		if err != nil {
			log.Panic(err)
		}
	case "printchain":
		err := printChainCmd.Parse(os.Args[2:])
		if err != nil {
			log.Panic(err)
		}
	default:
		// 打印子命令的使用方法
		cli.printUsage()
		os.Exit(1)
	}
	//判断如果命令已经解析
	if addBlockCmd.Parsed() {
		if *addBlockData == "" {
			addBlockCmd.Usage()
			os.Exit(1)
		}
		// 使用命令行参数的值作为函数的参数，添加区块
		cli.addBlock(*addBlockData)
	}
	// 判断如果命令已经解析,打印区块信息
	if printChainCmd.Parsed() {
		cli.printChain()
	}
}

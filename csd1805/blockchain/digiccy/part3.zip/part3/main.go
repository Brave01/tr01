package main

func main() {
	// 1 创建区块链
	bc := NewBlockchain()
	// 3 关闭数据库文件
	defer bc.db.Close()
	// 2 创建命令行对象
	cli := CLI{bc}
	// 调用命令的Run函数，接收用户输入，并响应
	cli.Run()
}

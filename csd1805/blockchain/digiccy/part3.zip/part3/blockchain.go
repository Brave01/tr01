package main

import (
	"fmt"
	"log"

	"github.com/boltdb/bolt"
)

const dbFile = "blockchain.db" //数据库文件名称
const blocksBucket = "blocks"  //“表”的名称

// Blockchain keeps a sequence of Blocks
type Blockchain struct {
	tip []byte   //区块链中最后一个块的Hash
	db  *bolt.DB //数据库对象地址
}

// BlockchainIterator is used to iterate over blockchain blocks
type BlockchainIterator struct {
	currentHash []byte
	db          *bolt.DB
}

// AddBlock saves provided data as a block in the blockchain
func (bc *Blockchain) AddBlock(data string) {
	var lastHash []byte
	// 只读事务，从blocks表中获取最后一个块的Hash
	err := bc.db.View(func(tx *bolt.Tx) error {
		b := tx.Bucket([]byte(blocksBucket))
		// 调用Get函数，返回键为"l"的值，最后一个块的Hash
		lastHash = b.Get([]byte("l"))

		return nil
	})

	if err != nil {
		log.Panic(err)
	}
	// 创建一个新块
	newBlock := NewBlock(data, lastHash)
	//读写事务，将新块的数据保存到数据库中
	err = bc.db.Update(func(tx *bolt.Tx) error {
		//根据“表”名获取表对象b
		b := tx.Bucket([]byte(blocksBucket))
		// 1 添加新块
		err := b.Put(newBlock.Hash, newBlock.Serialize())
		if err != nil {
			log.Panic(err)
		}
		// 2 保存最后一个块的Hash
		err = b.Put([]byte("l"), newBlock.Hash)
		if err != nil {
			log.Panic(err)
		}
		//在区块链对象中，保存最后一个块的Hash
		bc.tip = newBlock.Hash

		return nil
	})
}

// 为区块链添加迭代器方法，返回一个迭代器
func (bc *Blockchain) Iterator() *BlockchainIterator {
	bci := &BlockchainIterator{bc.tip, bc.db}

	return bci
}

// Next返回，返回下个区块的地址
func (i *BlockchainIterator) Next() *Block {
	var block *Block
	// 只读事务
	err := i.db.View(func(tx *bolt.Tx) error {
		//获取表对象
		b := tx.Bucket([]byte(blocksBucket))
		// 根据迭代器中保存的当前块Hash，获取区块数据
		encodedBlock := b.Get(i.currentHash)
		// 将区块数据反序列化等到块对象
		block = DeserializeBlock(encodedBlock)

		return nil
	})

	if err != nil {
		log.Panic(err)
	}
	// 将当前块中保存的前一个块的Hash保存到迭代器中
	i.currentHash = block.PrevBlockHash
	// 返回当前块的地址
	return block
}

// NewBlockchain creates a new Blockchain with genesis Block
func NewBlockchain() *Blockchain {
	var tip []byte
	// 新建一个数据库文件，文件名：dbFile
	db, err := bolt.Open(dbFile, 0600, nil)
	if err != nil {
		log.Panic(err)
	}
	//读写事务
	err = db.Update(func(tx *bolt.Tx) error {

		b := tx.Bucket([]byte(blocksBucket))
		//表不存在时，
		if b == nil {
			fmt.Println("No existing blockchain found. Creating a new one...")
			// 创建一个创世块
			genesis := NewGenesisBlock()
			// 创建一个数据“表”
			b, err := tx.CreateBucket([]byte(blocksBucket))
			if err != nil {
				log.Panic(err)
			}
			//调用put函数，以创世块的Hash为键，以创世块的数据为值
			err = b.Put(genesis.Hash, genesis.Serialize())
			if err != nil {
				log.Panic(err)
			}
			//以l为键，以最后一个块（创世块）的Hash为值
			err = b.Put([]byte("l"), genesis.Hash)
			if err != nil {
				log.Panic(err)
			}
			// 在区块链字段中保存最后一个块的Hash
			tip = genesis.Hash
		} else {
			// 表已经存在，从表中获取最后一个块的Hash，保存到tip中
			tip = b.Get([]byte("l"))
		}

		return nil
	})

	if err != nil {
		log.Panic(err)
	}
	//创建一个区块链对象，并返回区块链对象的地址
	bc := Blockchain{tip, db}

	return &bc
}

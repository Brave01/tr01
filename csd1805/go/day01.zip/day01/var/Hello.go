// Hello
package main

import (
	"fmt"
	"unicode/utf8"
	"unsafe"
)

//g:=100//简答声明不能用于包级别的变量

var g int = 1000

// 1 变量声明
func vardeclare() {
	// 1 变量的一般声明格式
	var a int = 100
	// 2 简短声明
	b := 3.14
	// 3 省略类型
	var s = "Hello"
	// 4 多个变量声明
	i, j, k := 10, 20, 30
	fmt.Println(a, b, g, s, i, j, k)
}

// 2 变量赋值
func varValue() {
	var i int
	i += 10
	i += 10
	var f float32
	var s string
	s = "Hello"
	fmt.Println(i, f, s)
	x := 10
	y := 20
	fmt.Println(x, y)
	// 多重赋值可以不引入第三变量直接交换
	x, y = y, x
	fmt.Println(x, y)
}

// 常量的使用
func constDemo() {
	const pi = 3.14
	const x = 3.14 * 2 //表达式
	fmt.Println(pi, x)
	//批量声明
	const (
		a = 100
		b
		c = 0
		d
	)
	fmt.Println(a, b, c, d)
	// iota常量
	const (
		aa = iota
		bb
		cc
		dd
	)
	fmt.Println(aa, bb, cc, dd)
}

// 数据类型
func DataType() {
	// 1 bool类型
	var flag bool
	fmt.Println(flag)
	flag = true
	fmt.Println(flag)
}
func IntDemo() {
	// int类型的长度(与系统和编译器都相关4或8个字节)
	var i int = 100
	fmt.Println(unsafe.Sizeof(i))
	a, b := 10, 20
	fmt.Println(a+b, a-b, a*b, a/b, a%b)
	//在Go语言中，++、--是表达式，不是语句
	a++
	i = a
	fmt.Println(i, a)
}
func floatDemo() {
	//float32与float64之间需要强制转换
	var f1 float32 = 12.5
	var f2 float64 = 0.5
	fmt.Println(f1, f2)
	f1 = float32(f2)
	f2 = float64(f1)
	fmt.Println(f1, f2)
	// 科学计数法
	f3 := 1.99E4
	f4 := 1.99e-3
	fmt.Println(f3, f4)
	// 复数
	c1 := 10 + 30i
	fmt.Println(c1, imag(c1), real(c1))
}
func stringDemo() {
	s1 := "Hello"
	s2 := " world"
	s3 := s1 + s2
	fmt.Println(s3, len(s3))
	// 取字符和取子串
	fmt.Println(s3[:5], string(s3[0]))
	fmt.Println(s3[6:], string(s3[len(s3)-1]))
	// 字符串中的字符不可修改
	//s3[0] = 'h'
	s3 = "hello世界"
	fmt.Println(s3)
	/*
		// 字符串遍历(按字节遍历)
		len := len(s3)
		fmt.Println(len)
		for i := 0; i < len; i++ {
			fmt.Println(s3[i])
		}*/
	fmt.Println(utf8.RuneCountInString(s3))
	//按照字符遍历
	for _, v := range s3 {
		fmt.Println(string(v))
	}
	// unicode与utf-8、utf-16之间的关系？
	// unicode就是一种字符编码。utf-8、utf-16存储的unicode
	//编码，但是存储方式不同。

	// 原生字符串字面值
	str := `静夜思-李白
窗前明月光
疑是地上霜
举头望明月
低头思故乡`
	fmt.Println(str)
}

// 指针演示
func PointerDemo() {
	var i int = 100
	var pi *int
	fmt.Println(pi)
	pi = &i
	fmt.Println(pi, &i, i, *pi)
	var ppi **int
	ppi = &pi
	fmt.Println(ppi, &pi)
	fmt.Println("i的值：", i, *pi, **ppi)
	fmt.Println("i的地址：", &i, pi, *ppi)
}

type Score int
type Age int

func typeDemo() {
	var s Score = 98
	fmt.Println(s)
	var a Age = 20
	fmt.Println(a)
	var i int = 25
	fmt.Println(i)
	s = Score(i) //不能直接赋值,需要类型转换

}

var a int = 15

func UseRangeDemo() {

	if true {
		//新的变量
		a := 10
		fmt.Println(a)
	}
	fmt.Println(a)
}

func Stdio() {
	fmt.Println("请输入两个整数值：")

	var a, b int
	//标准输入，空白分隔符可以是空格、Tab和回车
	//fmt.Scan(&a, &b)
	//空白分隔符可以是空格、Tab，这时的回车表示输入结束
	//fmt.Scanln(&a, &b)
	//标准输入，格式化输入,在字符串中指定分隔符
	//fmt.Scanf("%d:%d", &a, &b)
	//标准输出(在输出的结尾自动换行)
	fmt.Println("a=", a, "b=", b)
	//不换行
	fmt.Print("a=", a, "b=", b, "\n")
	// 格式化输出(输出值，不管什么类型，可以统一使用%v)
	fmt.Printf("a=%v,b=%v\n", a, b)
	fmt.Printf("a=%v,b=%v\n", 3.14, 23.56)
	fmt.Printf("a=%v,b=%v\n", "Hello", "World")
	// 把所有其它类型转换为长的字符串
	num := 100
	pi := 3.14
	flag := true
	s := "Hello"

	str := fmt.Sprintf("num=%v,pi=%v,flag=%v,s=%v",
		num, pi, flag, s)
	fmt.Printf(str)

}

func main() {

	Stdio()
	//vardeclare()
	//varValue()
	//constDemo()
	//DataType()
	//IntDemo()
	//floatDemo()
	//stringDemo()
	//PointerDemo()
	//typeDemo()
	//UseRangeDemo()

}

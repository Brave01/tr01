// main
package main

import (
	"fmt"
	"go/mycalc/math"
	"go/mycalc/math2"
)

func main() {
	add := math.Add(100, 100)
	sub := math.Sub(100, 50)
	mul := math2.Mul(100, 100)
	fmt.Println(add, sub, mul)
}

package math2

func Mul(a, b int) int {
	return a * b
}

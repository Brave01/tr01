package math

func Sub(a, b int) int {
	return a - b
}

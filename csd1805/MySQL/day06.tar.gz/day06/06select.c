#include <stdio.h>
#include <mysql/mysql.h>
int main()
{
    MYSQL mysql;
    MYSQL_RES* res;
    unsigned int cols;
    unsigned int rows;
    mysql_init(&mysql);
    if(!(mysql_real_connect(&mysql,
        "localhost","root","tarena","choose",0,NULL,0)))
    {
       printf("连接失败!\n");
       return -1;
    }
    mysql_query(&mysql,"set character set utf8");
    if(mysql_query(&mysql,"update choose set score=score+10"))
    {
       // 查询失败
       printf("查询失败\n");
    }
    else
    {
       res = mysql_store_result(&mysql);
       if(res) //有数据
       {
          cols = mysql_num_fields(res);// 结果集的列数
          rows = mysql_num_rows(res);  // 结果集的行数
          printf("列数:%d,行数:%d\n",cols,rows);
       }
       else // res为 null
       {
         if(mysql_field_count(&mysql)==0) // 执行的不是select
         {
           // 执行dml 操作时，影响的函数
            rows = mysql_affected_rows(&mysql);
            printf("影响的行数:%d\n",rows);
         }
       }
    }

    mysql_close(&mysql);
    return 0;
}




























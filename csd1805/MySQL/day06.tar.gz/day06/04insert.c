#include <stdio.h>
#include <mysql/mysql.h>
int main()
{
    MYSQL* mysql;
    char sqlstr[200];
    char stuno[10];
    char stuname[20];
    char phone[20];
    mysql = mysql_init(NULL);
    /* 连接数据库 */
    mysql = mysql_real_connect(mysql,
            "localhost","root","tarena","choose",0,NULL,0);
    /* 设置字符集 */
    mysql_query(mysql,"set character set utf8");
    printf("请输入学号：");
    scanf("%s",stuno);
    printf("请输入姓名：");
    scanf("%s",stuname);
    printf("请输入学生的手机号:");
    scanf("%s",phone);
    sprintf(sqlstr,"insert into student(student_no,student_name,student_contact) values('%s','%s','%s')",stuno,stuname,phone);
//    printf("%s\n",sqlstr);
    /* 执行插入操作 */
    if(mysql_query(mysql,sqlstr))
    {
       printf("插入失败!\n");
    }
    else{
       printf("插入成功!\n");
    }
    /* 关闭数据库 */
    mysql_close(mysql);
    return 0;
}








#include <stdio.h>
#include <mysql/mysql.h>
int main()
{
    MYSQL* mysql;
    MYSQL_RES* res;
    MYSQL_ROW row;
    unsigned int n_cols,n_rows;
    mysql = mysql_init(NULL);
    if(!mysql_real_connect(mysql,
            "localhost","root","tarena","choose",0,NULL,0)){
      printf("连接失败!\n");
      return -1;
    }
    mysql_query(mysql,"set character set utf8");
    if(mysql_query(mysql,"select * from student")){
       printf("执行失败!\n");
    }
    else{
       res = mysql_store_result(mysql);
       n_cols = mysql_num_fields(res);
       n_rows = mysql_num_rows(res);
       int i,j;
       for(i=0;i<n_rows;i++){
          row = mysql_fetch_row(res);
          for(j=0;j<n_cols;j++){
             printf("%s\t",row[j]);
          }
          printf("\n");
       }
       mysql_free_result(res);
    }
    mysql_close(mysql);
    return 0;
}
















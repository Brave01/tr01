#include <stdio.h>
#include <mysql/mysql.h>
int main()
{
    MYSQL mysql;
    mysql_init(&mysql);/*初始化MYSQL结构*/
   /*  建立数据库连接 */
    if(!(mysql_real_connect(&mysql,
                       "localhost",/*主机名或ip地址*/
                       "root",     /* 登录名 */
                       "tarena",   /* 密码 */
                       "choose",   /* 数据库名 */
                       0,NULL,0)))
    {
       printf("连接失败!\n");
    }
    else
    {
       printf("连接成功!\n");
    }
    mysql_close(&mysql);/* 关闭数据库连接 */
    return 0;
}


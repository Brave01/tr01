#include <stdio.h>
#include <mysql/mysql.h>
int main()
{
    MYSQL* mysql;
    char sqlstr[200];
    char stuno[10]="2017011";
    mysql = mysql_init(NULL);
    /* 建立数据库连接 */
    mysql = mysql_real_connect(mysql,
            "localhost","root","tarena","choose",0,NULL,0);
    sprintf(sqlstr,
        "delete from student where student_no=%s",stuno);
    /* 根据条件删除数据 */
    if(mysql_query(mysql,sqlstr))
    {
       printf("删除失败!\n");
    }
    else
    {
       printf("删除成功!\n");
    }
    /* 关闭数据库连接 */
    mysql_close(mysql);
    return 0;
}













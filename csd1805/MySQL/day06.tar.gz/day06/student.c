#include <stdio.h>
#include <mysql/mysql.h>
void addstu(MYSQL* mysql)
{
   char sqlstr[200];
   char stuno[10];
   char stuname[10];
   char phone[20];
   int class_no;
   printf("请输入学生学号:");
   scanf("%s",stuno);
   printf("请输入学生姓名:");
   scanf("%s",stuname);
   printf("请输入联系方式:");
   scanf("%s",phone);
   printf("请输入班级编号:");
   scanf("%d",&class_no);
   sprintf(sqlstr,"insert into student values('%s','%s','%s',%d)",
           stuno,stuname,phone,class_no);
   printf("%s\n",sqlstr);
   mysql_query(mysql,sqlstr);
   if(mysql_errno(mysql))
   {
      printf("添加学生失败，%s\n",mysql_error(mysql));
   }
   else
   {
      printf("添加成功!\n");
   }
}
void modifystu(MYSQL* mysql)
{
    char sqlstr[200];
    char stuno[10];
    char stuname[10];
    char phone[20];
    int class_no;
    printf("请输入要修改的学生的学号：");
    scanf("%s",stuno);
    printf("请输入学生的姓名：");
    scanf("%s",stuname);
    printf("请输入学生的联系方式：");
    scanf("%s",phone);
    printf("请输入学生的班级编号：");
    scanf("%d",&class_no);
    sprintf(sqlstr,"update student set student_name='%s',student_contact='%s',class_no=%d where student_no='%s'",stuname,phone,class_no,stuno);
//    printf("%s\n",sqlstr);
    if(mysql_query(mysql,sqlstr))
    {
       printf("%s\n",mysql_error(mysql));
    }
    else
    {
       printf("修改成功!\n");
    }
}
void searchstu(MYSQL* mysql)
{
   MYSQL_RES* res;
   unsigned int num_fields,num_rows;
   MYSQL_ROW row;
   int c_no;
   char sqlstr[200];
   printf("请输入班级编号：");
   scanf("%d",&c_no);
   sprintf(sqlstr,
    "select * from student where class_no=%d",c_no);
   if(!mysql_query(mysql,sqlstr))
   {
      res = mysql_store_result(mysql);
      num_fields = mysql_num_fields(res);
      num_rows = mysql_num_rows(res);
      int i,j;
      for(i=0;i<num_rows;i++)
      {
         row = mysql_fetch_row(res);
         for(j=0;j<num_fields;j++)
         {
            printf("%s\t",row[j]);
         }
         printf("\n");
      }
      mysql_free_result(res);
   }
}
int main()
{
    MYSQL* mysql;
    mysql = mysql_init(NULL);
    if(!(mysql_real_connect(mysql,"localhost","root","tarena","choose",0,NULL,0)))
    {
       printf("%s\n",mysql_error(mysql));
       return -1;
    }
    mysql_query(mysql,"set character set utf8");
    int option;
    while(1)
    {
        printf("欢迎使用迷你版学生管理系统\n");
        printf("1.添加学生信息\n");
        printf("2.修改学生信息\n");
        printf("3.删除学生\n");
        printf("4.根据学号查询学生信息\n");
        printf("5.显示学生列表\n");
        printf("0.退出\n");
        printf("请选择：");
        scanf("%d",&option);
        switch(option)
        {
            case 1:
                printf("学生管理系统--添加学生\n");
                addstu(mysql);
                break;
            case 2:
                printf("学生管理系统--修改学生\n");
                modifystu(mysql);
                break;
            case 3:
                printf("学生管理系统--删除学生\n");
                break;
            case 4:
                printf("学生管理系统--根据学号查询学生\n");
                searchstu(mysql);
                break;
            case 5:
                printf("学生管理系统--显示学生列表\n");
                break;
            case 0:
                printf("退出学生管理系统\n");
                exit(0);
        }
    }
    mysql_close(mysql);
    return 0;
}

#include <stdio.h>
#include <mysql/mysql.h>
int main()
{
    MYSQL* mysql;
    unsigned int num_fields,num_rows;
    MYSQL_RES* res;
    MYSQL_ROW row;
    int c_no;
    char sqlstr[200];
    mysql = mysql_init(NULL);
    if(!mysql_real_connect(mysql,
        "localhost","root","tarena","choose",0,NULL,0))
    {
       printf("连接失败!\n");
       return -1;
    }
    printf("请输入要查询的班级编号:");
    scanf("%d",&c_no);
    sprintf(sqlstr,"select student_name,student_name,class_name from student t,classes c where t.class_no=c.class_no and c.class_no=%d",c_no);
    mysql_query(mysql,"set character set utf8");
    if(!mysql_query(mysql,sqlstr))
    {
       res = mysql_store_result(mysql);
       num_fields = mysql_num_fields(res);
       num_rows = mysql_num_rows(res);
       int i,j;
       for(i=0;i<num_rows;i++)
       {
         row = mysql_fetch_row(res);
         for(j=0;j<num_fields;j++)
         {
            printf("%s\t",row[j]);
         }
         printf("\n");
       }
       mysql_free_result(res);
    }
    mysql_close(mysql);
    return 0;
}

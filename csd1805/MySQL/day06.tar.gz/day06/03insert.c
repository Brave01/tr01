#include <stdio.h>
#include <mysql/mysql.h>
int main()
{
    MYSQL* mysql;
    mysql = mysql_init(NULL);
    /* 建立数据库连接 */
    mysql = mysql_real_connect(mysql,
            "localhost","root","tarena","choose",0,NULL,0);
    /* 设置字符集 */
//    mysql_query(mysql,"set character set utf8");
    /* 向学生表student插入一行数据 */
    if(mysql_query(mysql,"insert into student values('2017011','小崔','13500000000',null)"))
    {
       printf("插入失败!\n");
    }
    else
    {
       printf("插入成功!\n");
    }
    /* 关闭数据库连接 */
    mysql_close(mysql);
    return 0;
}













#include <stdio.h>
#include <mysql/mysql.h>
int main()
{
    MYSQL* mysql;
    MYSQL_RES* res;
    unsigned int cols;
    MYSQL_FIELD* fields;
    mysql = mysql_init(NULL);
    if(!mysql_real_connect(mysql,
            "localhost","root","tarena","choose",0,NULL,0))
    {
      printf("连接失败!\n");
      return -1;
    }
    if(mysql_query(mysql,"select * from student"))
    {
       printf("执行失败!\n");
    }
    else{
       res = mysql_store_result(mysql);
       cols = mysql_num_fields(res);
       fields = mysql_fetch_fields(res);
       int i=0;
       for(;i<cols;i++)
       {
         printf("%s,%s\n",fields[i].name,fields[i].table);
       }
       mysql_free_result(res);
    }
    mysql_close(mysql);
    return 0;
}
















#include <stdio.h>
#include <mysql/mysql.h>
int main()
{
    MYSQL mysql;
    mysql_init(&mysql);
    char* pIP = "172.30.4.45";
    char* pUser = "root";
    char* pPwd = "tarena";
    char* pDb = "choose";
    if(!(mysql_real_connect(&mysql,pIP,pUser,pPwd,pDb,0,NULL,0)))
    {
       printf("连接失败!%s\n",mysql_error(&mysql));
    }
    else
    {
       printf("连接成功!\n");
    }
    mysql_close(&mysql);
    return 0;
}




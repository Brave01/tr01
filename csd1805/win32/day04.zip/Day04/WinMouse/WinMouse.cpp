#include <windows.h>
#include <stdio.h>
HINSTANCE g_hInstance = 0;// ���浱ǰ����ʵ�����
HANDLE g_hOutput = 0;
int g_xPos = 100,g_yPos = 100;
void OnLButtonDown(HWND hWnd,WPARAM wParam,LPARAM lParam)
{
	char szText[256]={0};
	sprintf(szText,"WM_LBUTTONDOWM--����״̬:%08X,���λ��(%d,%d)\n",
		wParam,LOWORD(lParam),HIWORD(lParam));
	WriteConsole(g_hOutput,szText,strlen(szText),NULL,NULL);
}
void OnLButtonUp(HWND hWnd,WPARAM wParam,LPARAM lParam)
{
	char szText[256]={0};
	sprintf(szText,"WM_LBUTTONUP--����״̬:%08X,���λ��(%d,%d)\n",
		wParam,LOWORD(lParam),HIWORD(lParam));
	WriteConsole(g_hOutput,szText,strlen(szText),NULL,NULL);
}
void OnMouseMove(HWND hWnd,WPARAM wParam,LPARAM lParam)
{
/*	char szText[256]={0};
	sprintf(szText,"WM_MOUSEMOVE--����״̬:%08X,���λ��(%d,%d)\n",
		wParam,LOWORD(lParam),HIWORD(lParam));
	WriteConsole(g_hOutput,szText,strlen(szText),NULL,NULL);*/
    g_xPos = LOWORD(lParam);
	g_yPos = HIWORD(lParam);
	InvalidateRect(hWnd,NULL,FALSE);
}
void OnLButtonDblClk(HWND hWnd,WPARAM wParam,LPARAM lParam)
{
	char szText[256] = {0};
	sprintf(szText,"WM_LBUTTONDBLCLK--- ����״̬:%08X,���λ��(%d,%d)\n",
		wParam,LOWORD(lParam),HIWORD(lParam));
	WriteConsole(g_hOutput,szText,strlen(szText),NULL,NULL);
}
void OnMouseWheel(HWND hWnd,WPARAM wParam)
{
	char szText[256]={0};
	short nOffset = HIWORD(wParam);
	sprintf(szText,"WM_MOUSEWHEEL:%d\n",nOffset);
	WriteConsole(g_hOutput,szText,strlen(szText),NULL,NULL);
}
void OnPaint(HWND hWnd)
{
	PAINTSTRUCT ps = {0};
	HDC hdc = BeginPaint(hWnd,&ps);
	TextOut(hdc,g_xPos,g_yPos,"Hello",5);
	EndPaint(hWnd,&ps);
}
// ���崰�ڴ�������
LRESULT CALLBACK WndProc(HWND hWnd,UINT msgID,
	WPARAM wParam,LPARAM lParam)
{
	switch(msgID)
	{
	case WM_PAINT:
		OnPaint(hWnd);
		break;
	case WM_MOUSEWHEEL:
		OnMouseWheel(hWnd,wParam);
		break;
	case WM_LBUTTONDBLCLK:
		OnLButtonDblClk(hWnd,wParam,lParam);
		break;
	case WM_MOUSEMOVE:
		OnMouseMove(hWnd,wParam,lParam);
		break;
	case WM_LBUTTONUP:
		OnLButtonUp(hWnd,wParam,lParam);
		break;
	case WM_LBUTTONDOWN:
		OnLButtonDown(hWnd,wParam,lParam);
		break;
	case WM_DESTROY:
		PostQuitMessage(0);  // GetMessage����0 ?
		break;
	}
	return DefWindowProc(hWnd,msgID,wParam,lParam);
}
// ע�ᴰ����
void Register(LPSTR lpClassName,WNDPROC wndProc)
{
	WNDCLASSEX wce = {0};
	wce.cbSize = sizeof(wce);
	wce.cbClsExtra = 0;
	wce.cbWndExtra = 0;
	wce.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
	wce.hCursor = NULL;
	wce.hIcon = NULL;
	wce.hIconSm = NULL;
	wce.hInstance = g_hInstance;
	wce.lpfnWndProc = wndProc;
	wce.lpszClassName = lpClassName;
	wce.lpszMenuName = NULL;
	wce.style = CS_HREDRAW|CS_VREDRAW | CS_DBLCLKS;
	RegisterClassEx(&wce);
}
// ��������
HWND CreateMain(LPSTR lpClassName,LPSTR lpWindowName)
{
	HWND hWnd = CreateWindowEx(0,lpClassName,lpWindowName,
		WS_OVERLAPPEDWINDOW,100,100,700,500,
		NULL,NULL,g_hInstance,NULL);
	return hWnd;
}
// ��ʾ����
void Display(HWND hWnd)
{
	ShowWindow(hWnd,SW_SHOW);
	UpdateWindow(hWnd);
}
// ��Ϣѭ��
void Message()
{
	MSG nMsg = {0};
	while(GetMessage(&nMsg,NULL,0,0))
	{
		TranslateMessage(&nMsg);
		DispatchMessage(&nMsg);
	}
}
// WinMain����
int CALLBACK WinMain(HINSTANCE hInstance,HINSTANCE hPreIns,
	LPSTR lpCmdLine,int nCmdShow)
{
	AllocConsole();
	g_hOutput = GetStdHandle(STD_OUTPUT_HANDLE);
	g_hInstance = hInstance;
	Register("Main",WndProc);				// ע�ᴰ����
	HWND hWnd = CreateMain("Main","Window");// ��������
	Display(hWnd);							// ��ʾ����
	Message();								// ��Ϣѭ��
	return 0;
}
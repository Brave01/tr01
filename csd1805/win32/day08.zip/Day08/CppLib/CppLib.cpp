int CppLib_add(int num1,int num2)
{
	return num1 + num2;
}
int CppLib_sub(int num1,int num2)
{
	return num1 - num2;
}
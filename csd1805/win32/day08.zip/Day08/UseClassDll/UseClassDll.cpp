#include <stdio.h>
#include "../ClassDll/math.h"
#pragma comment(lib,"../Debug/ClassDll.lib")

int main()
{
	CMath math;
	printf("sum=%d\n",math.add(7,3));
	printf("sub=%d\n",math.sub(7,3));
	getchar();
	return 0;
}
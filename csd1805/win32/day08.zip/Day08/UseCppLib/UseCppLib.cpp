#include <stdio.h>
int CppLib_add(int,int);
int CppLib_sub(int,int);
#pragma comment(lib,"../Debug/CppLib.lib")
// C�⺯��������
extern "C"int Clib_add(int,int);
extern "C"int Clib_sub(int,int);
#pragma comment(lib,"../Debug/Clib.lib")
int main()
{
	int sum = CppLib_add(5,3);
	int sub = CppLib_sub(5,3);
	printf("sum=%d,sub=%d\n",sum,sub);

	sum = Clib_add(5,2);
	sub = Clib_sub(5,2);
	printf("sum=%d,sub=%d\n",sum,sub);

	getchar();
	return 0;
}
int Clib_add(int num1,int num2)
{
	return num1 + num2;
}
int Clib_sub(int num1,int num2)
{
	return num1 - num2;
}
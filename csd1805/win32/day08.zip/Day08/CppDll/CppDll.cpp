int CppDll_add(int num1,int num2)
{
	return num1 + num2;
}
int CppDll_sub(int num1,int num2)
{
	return num1 - num2;
}
_declspec(dllexport)int CppDll_mul(int num1,int num2)
{
	return num1 * num2;
}
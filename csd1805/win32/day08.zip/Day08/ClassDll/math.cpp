#define DLLCLASS_EXPORT
#include <windows.h>
#include <stdio.h>
#include "math.h"
BOOL CALLBACK DllMain(HINSTANCE hinstDLL,DWORD fdwReason,
	LPVOID lpvReserved)
{
	switch(fdwReason)
	{
	case DLL_PROCESS_ATTACH:
		printf("Loading...\n"); // ��ʼ��
		break;
	case DLL_PROCESS_DETACH:
		printf("UnLoading...\n"); // �ƺ���
		break;
	}
	return TRUE;
}
int CMath::add(int num1,int num2)
{
	return num1 + num2;
}
int CMath::sub(int num1,int num2)
{
	return num1 - num2;
}
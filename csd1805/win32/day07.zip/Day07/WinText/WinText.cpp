#include <windows.h>
HINSTANCE g_hInstance = 0;// ���浱ǰ����ʵ�����
void OnPaint(HWND hWnd)
{
	PAINTSTRUCT ps = {0};
	HDC hdc  = BeginPaint(hWnd,&ps);

	SetTextColor(hdc,RGB(255,0,0));
//	SetBkColor(hdc,RGB(0,0,255));
	SetBkMode(hdc,TRANSPARENT);

	HFONT hFont = CreateFont(30,0,100,0,900,0,0,0,GB2312_CHARSET,0,0,0,0,
		 "Ҷ����ë������2.0��");
	HGDIOBJ hOldFont = SelectObject(hdc,hFont);
	char szText[256] = "He&llo";
	TextOut(hdc,100,100,szText,strlen(szText));

	RECT rc = {0};
	rc.left = 100;
	rc.top = 150;
	rc.right = 200;
	rc.bottom = 200;

//	Rectangle(hdc,100,150,200,200);

	DrawText(hdc,szText,strlen(szText),&rc,
		DT_CENTER|DT_VCENTER|DT_SINGLELINE|DT_NOCLIP|DT_NOPREFIX);
	    // DT_VCENTER��DT_BOTTOM �� DT_WORDBREAK��ͻ
	    // ��������ʾ��ʽֻ����DT_SINGLELINEʱ��Ч(����)

	char szExText[] = "H�й�����";
	int nDis[] = {50,0,40,0,30,0,20,0};
	ExtTextOut(hdc,100,300,0,NULL,szExText,strlen(szExText),nDis);

	SelectObject(hdc,hOldFont);
	DeleteObject(hFont);

	EndPaint(hWnd,&ps);
}
// ���崰�ڴ�������
LRESULT CALLBACK WndProc(HWND hWnd,UINT msgID,
	WPARAM wParam,LPARAM lParam)
{
	switch(msgID)
	{
	case WM_PAINT:
		OnPaint(hWnd);
		break;
	case WM_DESTROY:
		PostQuitMessage(0);  // GetMessage����0 ?
		break;
	}
	return DefWindowProc(hWnd,msgID,wParam,lParam);
}
// ע�ᴰ����
void Register(LPSTR lpClassName,WNDPROC wndProc)
{
	WNDCLASSEX wce = {0};
	wce.cbSize = sizeof(wce);
	wce.cbClsExtra = 0;
	wce.cbWndExtra = 0;
	wce.hbrBackground = CreateSolidBrush(RGB(200,230,230));
	wce.hCursor = NULL;
	wce.hIcon = NULL;
	wce.hIconSm = NULL;
	wce.hInstance = g_hInstance;
	wce.lpfnWndProc = wndProc;
	wce.lpszClassName = lpClassName;
	wce.lpszMenuName = NULL;
	wce.style = CS_HREDRAW|CS_VREDRAW;
	RegisterClassEx(&wce);
}
// ��������
HWND CreateMain(LPSTR lpClassName,LPSTR lpWindowName)
{
	HWND hWnd = CreateWindowEx(0,lpClassName,lpWindowName,
		WS_OVERLAPPEDWINDOW,100,100,700,500,
		NULL,NULL,g_hInstance,NULL);
	return hWnd;
}
// ��ʾ����
void Display(HWND hWnd)
{
	ShowWindow(hWnd,SW_SHOW);
	UpdateWindow(hWnd);
}
// ��Ϣѭ��
void Message()
{
	MSG nMsg = {0};
	while(GetMessage(&nMsg,NULL,0,0))
	{
		TranslateMessage(&nMsg);
		DispatchMessage(&nMsg);
	}
}
// WinMain����
int CALLBACK WinMain(HINSTANCE hInstance,HINSTANCE hPreIns,
	LPSTR lpCmdLine,int nCmdShow)
{
	g_hInstance = hInstance;
	Register("Main",WndProc);				// ע�ᴰ����
	HWND hWnd = CreateMain("Main","Window");// ��������
	Display(hWnd);							// ��ʾ����
	Message();								// ��Ϣѭ��
	return 0;
}
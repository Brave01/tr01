#include <windows.h>
HINSTANCE g_hInstance = 0;// ���浱ǰ����ʵ�����
void OnPaint(HWND hWnd)
{
	PAINTSTRUCT ps = {0};
	HDC hdc = BeginPaint(hWnd,&ps);

	SetMapMode(hdc,MM_ANISOTROPIC);
	SetWindowExtEx(hdc,1,1,NULL);
	SetViewportExtEx(hdc,2,-3,NULL);

	Ellipse(hdc,100,-100,300,-300);
	Ellipse(hdc,300,100,600,300);
	EndPaint(hWnd,&ps);
}
// ���崰�ڴ�������
LRESULT CALLBACK WndProc(HWND hWnd,UINT msgID,
	WPARAM wParam,LPARAM lParam)
{
	switch(msgID)
	{
	case WM_PAINT:
		OnPaint(hWnd);
		break;
	case WM_DESTROY:
		PostQuitMessage(0);  // GetMessage����0 ?
		break;
	}
	return DefWindowProc(hWnd,msgID,wParam,lParam);
}
// ע�ᴰ����
void Register(LPSTR lpClassName,WNDPROC wndProc)
{
	WNDCLASSEX wce = {0};
	wce.cbSize = sizeof(wce);
	wce.cbClsExtra = 0;
	wce.cbWndExtra = 0;
	wce.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
	wce.hCursor = NULL;
	wce.hIcon = NULL;
	wce.hIconSm = NULL;
	wce.hInstance = g_hInstance;
	wce.lpfnWndProc = wndProc;
	wce.lpszClassName = lpClassName;
	wce.lpszMenuName = NULL;
	wce.style = CS_HREDRAW|CS_VREDRAW;
	RegisterClassEx(&wce);
}
// ��������
HWND CreateMain(LPSTR lpClassName,LPSTR lpWindowName)
{
	HWND hWnd = CreateWindowEx(0,lpClassName,lpWindowName,
		WS_OVERLAPPEDWINDOW,100,100,700,500,
		NULL,NULL,g_hInstance,NULL);
	return hWnd;
}
// ��ʾ����
void Display(HWND hWnd)
{
	ShowWindow(hWnd,SW_SHOW);
	UpdateWindow(hWnd);
}
// ��Ϣѭ��
void Message()
{
	MSG nMsg = {0};
	while(GetMessage(&nMsg,NULL,0,0))
	{
		TranslateMessage(&nMsg);
		DispatchMessage(&nMsg);
	}
}
// WinMain����
int CALLBACK WinMain(HINSTANCE hInstance,HINSTANCE hPreIns,
	LPSTR lpCmdLine,int nCmdShow)
{
	g_hInstance = hInstance;
	Register("Main",WndProc);				// ע�ᴰ����
	HWND hWnd = CreateMain("Main","Window");// ��������
	Display(hWnd);							// ��ʾ����
	Message();								// ��Ϣѭ��
	return 0;
}
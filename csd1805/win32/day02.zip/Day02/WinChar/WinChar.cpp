//#define UNICODE
#include <stdio.h>
#include <windows.h>

//#define WIDECHAR

void T_Char()
{
	TCHAR* pszText = __TEXT("Hello");
#ifdef UNICODE
	wprintf(L"%s\n",pszText);
#else
	printf("��:%s\n",pszText);
#endif
/*#ifdef WIDECHAR
	wchar_t* pszText = L"Hello";
	wprintf(L"%s\n",pszText);
#else
	char* pszText = "Hello";
	printf("��:%s\n",pszText);
#endif*/
}
void W_Char()
{
	wchar_t* pszText = L"Hello wchar";
	int nLen = wcslen(pszText);
	wprintf(L"%s,%d\n",pszText,nLen);
}
void C_Char()
{
	char* pszText = "Hello Char";
	printf("%s\n",pszText);
}
void PrintUnicode()
{
/*	wchar_t* pszText = L"������";
    HANDLE hOutput = GetStdHandle(STD_OUTPUT_HANDLE);
	WriteConsole(hOutput,pszText,wcslen(pszText),NULL,NULL);
*/
	HANDLE hOutput = GetStdHandle(STD_OUTPUT_HANDLE);
	for(WORD nH = 60;nH<256;nH++)
	{
		for(WORD nL = 60;nL<256;nL++)
		{
			wchar_t nWChar = nH*256 + nL;
			WriteConsole(hOutput,&nWChar,1,NULL,NULL);
		}
		printf("\n");
	}
}
int main()
{
	PrintUnicode();
//	T_Char();
//	W_Char();
//	C_Char();
	getchar();
	return 0;
}
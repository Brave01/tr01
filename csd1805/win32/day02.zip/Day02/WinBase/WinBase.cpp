LRESULT CALLBACK WindowProc(HWND hWnd,UINT msgID,
	WPARAM wParam,LPARAM lParam)
{
	return DefWindowProc(hWnd,msgID,wParam,lParam);
}
int CALLBACK WinMain(HINSTANCE hInstance,HINSTANCE hPreIns,
	LPSTR lpCmdLine,int nCmdShow)
{
	// ע�ᴰ����
	WNDCLASS wc = {0};
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
	wc.hCursor = NULL;
	wc.hIcon = NULL;
	wc.hInstance = hInstance;
	wc.lpfnWndProc = WindowProc;
	wc.lpszClassName = "Main"; /**********/
	wc.lpszMenuName = NULL;
	wc.style = CS_HREDRAW | CS_VREDRAW;
	RegisterClass(&wc);
	HWND hWnd = CreateWindow("Main","Window",
		WS_OVERLAPPEDWINDOW,
		100,100,700,500,NULL,NULL,hInstance,NULL);
	ShowWindow(hWnd,SW_SHOW);
	// ��Ϣѭ��
	MSG nMsg = {0};
	while(GetMessage(&nMsg,NULL,0,0))
	{
		TranslateMessage(&nMsg);
		DispatchMessage(&nMsg);
	}
}

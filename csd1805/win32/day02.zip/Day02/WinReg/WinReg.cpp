#include <windows.h>
HINSTANCE g_hInstance = 0;  // ���浱ǰ����ʵ�����
void SysReg()
{
	// ϵͳ�����࣬����Ҫ����Աע��
	// ��������
	HWND hWnd = CreateWindow("BUTTON","OK", WS_OVERLAPPEDWINDOW,
		100,100,700,500,NULL,NULL,g_hInstance,NULL);
	// ��ʾ����
	ShowWindow(hWnd,SW_SHOW);
	UpdateWindow(hWnd);
	// ��Ϣѭ��
	MSG nMsg = {0};
	while(GetMessage(&nMsg,NULL,0,0))
	{
		TranslateMessage(&nMsg);
		DispatchMessage(&nMsg);
	}
}
void AppReg()
{
	WNDCLASSEX wce = {0};
	wce.cbSize = sizeof(wce);
	wce.cbClsExtra = 0;
	wce.cbWndExtra = 0;
	wce.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
	wce.hCursor = NULL;
	wce.hIcon = NULL;
	wce.hIconSm = NULL;
	wce.hInstance = g_hInstance;    /*************/
	wce.lpfnWndProc = DefWindowProc;
	wce.lpszClassName = "Main";     /*************/
	wce.lpszMenuName = NULL;
	wce.style = CS_HREDRAW |CS_VREDRAW;
	RegisterClassEx(&wce);
}
int WinMain(HINSTANCE hInstance,HINSTANCE hPreIns,
	LPSTR lpCmdLine,int nCmdShow)
{
//	SysReg();
	AppReg();
	return 0;
}
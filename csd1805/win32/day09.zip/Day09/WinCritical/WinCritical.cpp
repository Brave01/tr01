#include <stdio.h>
#include <windows.h>
CRITICAL_SECTION cs = {0}; // �ٽ�������
// �̴߳�������
DWORD CALLBACK TestProc(LPVOID pParam)
{
	char* pszText = (char*)pParam;
	while(1)
	{
		EnterCriticalSection(&cs);  // �����ٽ���
		for(int i=0;i<strlen(pszText);i++)
		{
			printf("%c",pszText[i]);
			Sleep(100);
		}
		printf("\n");
		LeaveCriticalSection(&cs);  // �뿪�ٽ���
		Sleep(10);
	}
	return 0;
}
DWORD CALLBACK TestProc2(LPVOID pParam)
{
	char* pszText = (char*)pParam;
	while(1)
	{
		EnterCriticalSection(&cs);
		for(int i=0;i<strlen(pszText);i++)
		{
			printf("%c",pszText[i]);
			Sleep(100);
		}
		printf("\n");
		LeaveCriticalSection(&cs);
		Sleep(10);
	}
	return 0;
}
int main()
{
	InitializeCriticalSection(&cs); // ��ʼ���ٽ���
	// �����߳�
	DWORD nID = 0;
	char* pszText = "********";
	HANDLE hThread = CreateThread(NULL,0,TestProc,pszText,0,&nID);

	char* pszText2 = "--------";
	HANDLE hThread2 = CreateThread(NULL,0,TestProc2,pszText2,
		0,&nID);
	getchar();
	DeleteCriticalSection(&cs);    // ɾ���ٽ���
	CloseHandle(hThread);
	CloseHandle(hThread2);
	return 0;
}
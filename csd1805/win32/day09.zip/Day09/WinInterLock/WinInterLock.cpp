#include <stdio.h>
#include <windows.h>
long g_nValue = 0;
DWORD CALLBACK ThreadProc1(LPVOID pParam)
{
	for(int i=0;i<100000000;i++)
	{
//		g_nValue++;
		InterlockedIncrement(&g_nValue);
	}
	return 0;
}
DWORD CALLBACK ThreadProc2(LPVOID pParam)
{
	for(int i=0;i<100000000;i++)
	{
//		g_nValue++;
		InterlockedIncrement(&g_nValue);
	}
	return 0;
}
int main()
{
	// �����߳�
	DWORD nIDs[2];
	HANDLE hThread[2];
	hThread[0] = CreateThread(NULL,0,ThreadProc1,NULL,0,&nIDs[0]);
	hThread[1] = CreateThread(NULL,0,ThreadProc2,NULL,0,&nIDs[1]);
	// �Ⱥ������߳̾�������ź�(��ִ����)
	WaitForMultipleObjects(2,hThread,TRUE,INFINITE);
	printf("%d\n",g_nValue);
	getchar();
	CloseHandle(hThread[0]);
	CloseHandle(hThread[1]);
	return 0;
}
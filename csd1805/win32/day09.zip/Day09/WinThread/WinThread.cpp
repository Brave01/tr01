#include <stdio.h>
#include <windows.h>
// �̴߳�������
DWORD CALLBACK TestProc(LPVOID pParam)
{
	char* pszText = (char*)pParam;
	while(1)
	{
		for(int i=0;i<strlen(pszText);i++)
		{
			printf("%c",pszText[i]);
			Sleep(10);
		}
		printf("\n");
	}
	return 0;
}
DWORD CALLBACK TestProc2(LPVOID pParam)
{
	char* pszText = (char*)pParam;
	while(1)
	{
		for(int i=0;i<strlen(pszText);i++)
		{
			printf("%c",pszText[i]);
			Sleep(10);
		}
		printf("\n");
	}
	return 0;
}
int main()
{
	// �����߳�
	DWORD nID = 0;
	char* pszText = "********";
	HANDLE hThread = CreateThread(NULL,0,TestProc,pszText,0,&nID);

	char* pszText2 = "--------";
	HANDLE hThread2 = CreateThread(NULL,0,TestProc2,pszText2,
		0,&nID);

	getchar();
//	ResumeThread(hThread2);
//	SuspendThread(hThread);
	getchar();
	CloseHandle(hThread);
	CloseHandle(hThread2);
	return 0;
}
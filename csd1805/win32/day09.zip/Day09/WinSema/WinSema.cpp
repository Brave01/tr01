#include <stdio.h>
#include <windows.h>
HANDLE hSema = 0; 
DWORD CALLBACK PrintProc(LPVOID pParam)
{
	while(1)
	{
		WaitForSingleObject(hSema,INFINITE);
		printf("******************\n");
	}
	return 0;
}
int main()
{
	hSema = CreateSemaphore(NULL,3,10,NULL);
	DWORD nID = 0;
	HANDLE hThread = CreateThread(NULL,0,PrintProc,NULL,0,&nID);
	getchar();
	ReleaseSemaphore(hSema,8,NULL);
	WaitForSingleObject(hThread,INFINITE);
	CloseHandle(hThread);
	CloseHandle(hSema);
	return 0;
}
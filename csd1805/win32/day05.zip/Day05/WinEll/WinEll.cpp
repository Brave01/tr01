#include <windows.h>
#define ELL_D 50
HINSTANCE g_hInstance = 0;// ���浱ǰ����ʵ�����
int g_xPos = 100,g_yPos = 100;
int LEFT_RIGHT = 1;  //  ��������
int RIGHT_LEFT = 0;  //  ��������
int TOP_BOTTOM = 1;  //  ��������
int BOTTOM_TOP = 0;  //  ��������
void OnPaint(HWND hWnd)
{
	PAINTSTRUCT ps = {0};
	HDC hdc = BeginPaint(hWnd,&ps);
	Ellipse(hdc,g_xPos,g_yPos,g_xPos+ELL_D,g_yPos+ELL_D);
	EndPaint(hWnd,&ps);
}
void OnTimer(HWND hWnd,WPARAM wParam)
{
	RECT rcClient = {0};
	GetClientRect(hWnd,&rcClient);
	if(g_xPos>=rcClient.right - ELL_D)
	{
		LEFT_RIGHT = 0;
		RIGHT_LEFT = 1;
	}
	if(g_xPos<=rcClient.left)
	{
		LEFT_RIGHT = 1;
		RIGHT_LEFT = 0;
	}
	if(g_yPos>=rcClient.bottom - ELL_D)
	{
		TOP_BOTTOM = 0;
		BOTTOM_TOP = 1;
	}
	if(g_yPos<=rcClient.top)
	{
		TOP_BOTTOM = 1;
		BOTTOM_TOP = 0;
	}

	if(LEFT_RIGHT==1)
	{
		g_xPos++;
	}
	if(RIGHT_LEFT==1)
	{
		g_xPos--;
	}
	if(TOP_BOTTOM==1)
	{
		g_yPos++;
	}
	if(BOTTOM_TOP==1)
	{
		g_yPos--;
	}
	InvalidateRect(hWnd,NULL,FALSE);
}
// ���崰�ڴ�������
LRESULT CALLBACK WndProc(HWND hWnd,UINT msgID,
	WPARAM wParam,LPARAM lParam)
{
	switch(msgID)
	{
	case WM_TIMER:
		OnTimer(hWnd,wParam);
		break;
	case WM_CREATE:
		SetTimer(hWnd,1001,50,NULL);
		break;
	case WM_PAINT:
		OnPaint(hWnd);
		break;
	case WM_DESTROY:
		PostQuitMessage(0);  // GetMessage����0 ?
		break;
	}
	return DefWindowProc(hWnd,msgID,wParam,lParam);
}
// ע�ᴰ����
void Register(LPSTR lpClassName,WNDPROC wndProc)
{
	WNDCLASSEX wce = {0};
	wce.cbSize = sizeof(wce);
	wce.cbClsExtra = 0;
	wce.cbWndExtra = 0;
	wce.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
	wce.hCursor = NULL;
	wce.hIcon = NULL;
	wce.hIconSm = NULL;
	wce.hInstance = g_hInstance;
	wce.lpfnWndProc = wndProc;
	wce.lpszClassName = lpClassName;
	wce.lpszMenuName = NULL;
	wce.style = CS_HREDRAW|CS_VREDRAW;
	RegisterClassEx(&wce);
}
// ��������
HWND CreateMain(LPSTR lpClassName,LPSTR lpWindowName)
{
	HWND hWnd = CreateWindowEx(0,lpClassName,lpWindowName,
		WS_OVERLAPPEDWINDOW,100,100,700,500,
		NULL,NULL,g_hInstance,NULL);
	return hWnd;
}
// ��ʾ����
void Display(HWND hWnd)
{
	ShowWindow(hWnd,SW_SHOW);
	UpdateWindow(hWnd);
}
// ��Ϣѭ��
void Message()
{
	MSG nMsg = {0};
	while(GetMessage(&nMsg,NULL,0,0))
	{
		TranslateMessage(&nMsg);
		DispatchMessage(&nMsg);
	}
}
// WinMain����
int CALLBACK WinMain(HINSTANCE hInstance,HINSTANCE hPreIns,
	LPSTR lpCmdLine,int nCmdShow)
{
	g_hInstance = hInstance;
	Register("Main",WndProc);				// ע�ᴰ����
	HWND hWnd = CreateMain("Main","Window");// ��������
	Display(hWnd);							// ��ʾ����
	Message();								// ��Ϣѭ��
	return 0;
}
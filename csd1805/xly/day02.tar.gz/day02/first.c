#include<stdio.h>//.h头文件 include包含进文件中
//stdio.h   自己 函数、变量声明 .h

int main () {//主函数 程序执行的入口

    printf("hello world");
        //""之间的内容显示在屏幕上
    return 0;//表示函数的结束 返回特定数值
}

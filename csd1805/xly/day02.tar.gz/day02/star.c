#include<stdio.h>

int main () {
    printf("   *\n");
    printf("  * *\n");
    printf(" * * *\n");
    printf("* * * *\n");

    printf("   *\n  * *\n * * *\n* * * *\n");
    return 0;
}

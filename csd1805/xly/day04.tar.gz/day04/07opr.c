#include<stdio.h>

int main () {
    int num = 5;
    num += 4;//num = num + 4;
    printf("%d \n",num);
    num *= 2 + 2;//num = num * (2 + 2);
    printf("%d \n",num);
    return 0;
}

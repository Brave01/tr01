#include<stdio.h>

int main () {
    int num = 45;
    int tmp = 7;
    printf("45%%7=%d\n",num%tmp);
    printf("7%%45=%d\n",tmp%num);
    return 0;
}

#include<stdio.h>

int main (){
    int num = 5;
    printf("%d \n",num > 6);
    printf("%d \n",num == 5);
    printf("%d \n",!1);//非
    printf("%d \n",!-1);
    printf("%d \n",3 < 7 < 5);
    printf("%d \n",3 < 7 && 7 < 5);
    printf("%d \n",3 < 7 || 7 < 5);

    0 && num++;
    printf("%d\n",num);
    1 || num++;
    printf("%d\n",num);
    return 0;
}









#include<stdio.h>

int main (){
    int num = 12345;
    int tmp = 10;
    printf("%d\n",num);
    num = num / tmp;
    printf("%d\n",num);
    num = num / tmp;
    printf("%d\n",num);
    num = num / tmp;
    printf("%d\n",num);
    num = num / tmp;
    printf("%d\n",num);
    return 0;
}

#include<stdio.h>

int main () {
    int a = 10,b = 3;
    printf("a/b=%d\n",a/b);
    return 0;
}

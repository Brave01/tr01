#include<stdio.h>

int main () {
    int num = 0;
    int tmp = 0;
    printf("请输入一个数字:\n");
    scanf("%d",&num);
    
    tmp = num >= 0 ? num : 0 - num;
    printf("绝对值是%d\n",tmp);
    return 0;
}








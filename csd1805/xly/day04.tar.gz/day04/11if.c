#include<stdio.h>

int main () {
    int num = 0;
    printf("请输入一个数字!\n");
    scanf("%d",&num);
    if(num > 0){
        printf("正数\n");
    }else if(num == 0){
        printf("零\n");
    }else {
        printf("负数\n");
    }
    return 0;
}

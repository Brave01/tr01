#include<stdio.h>

int main () {
    int num = 0;
    int g = 0,s = 0,b = 0;
    printf("请输入一个三位数:\n");
    scanf("%d",&num);
    g = num % 10;
    s = num / 10 % 10;
    b = num / 100;
    printf("个位是%d\n",g);
    printf("十位是%d\n",s);
    printf("百位是%d\n",b);
    return 0;
}





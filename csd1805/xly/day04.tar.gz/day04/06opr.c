#include<stdio.h>

int main () {
    int num = 10;
    int tmp = 0;
    /*printf("%d \n",num);
    num++;
    printf("%d \n",num);
    ++num;
    printf("%d \n",num);*/
    tmp = num++;//tmp 10  num + 1
    printf("tmp = %d,num = %d\n",tmp,num);
    tmp = ++num;// num + 1   tmp 12
    printf("tmp = %d,num = %d\n",tmp,num);

    
    return 0;    
}







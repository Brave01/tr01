#include<stdio.h>

int main () {
    int num = 0;
    int mo = 0;
    printf("请输入里程数：\n");
    scanf("%d",&num);

    if(num <= 3){
        printf("费用是5元！\n");
    }else if(num > 3){
        mo = 5 + (num - 3) * 1;
        printf("费用是%d元\n",mo);
    }
    return 0;
}









#include<stdio.h>

int main () {
    float r = 0;
    float c,s;
    printf("请输入半径的长度\n");
    scanf("%g",&r);
    c = 2 * r * 3.14f;
    s = 3.14f * r * r;
    printf("周长是%g,面积是%g\n",c,s);
    return 0;
}

#include<stdio.h>

int main () {
    
    printf("%f   ,%g   \n",3.14f,3.14f);
    return 0;
}

#include<stdio.h>

int main () {
    int num=0 ,tmp=0;

    num = 44;
    tmp = 45;
    
    printf("num + tmp is %d\n",num + tmp);


    //printf("num is %d\n",num);
    //num = 89;
    //printf("num is %d\n",num);

    return 0;
}






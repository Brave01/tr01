#include<stdio.h>

int main () {
    int a = 3,b = 5;
    /*int c = 0;
    c = a;
    a = b;
    b = c;*/
    
    a = a + b;
    b = a - b;
    a = a - b;

    printf("a = %d,b = %d\n",a,b);
    return 0;
}




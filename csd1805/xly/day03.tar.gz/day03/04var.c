#include<stdio.h>

int main () {
    int num;
    printf("请输入数字：\n");
    scanf("%d",&num);
    printf("num is %d\n",num);
    return 0;
}

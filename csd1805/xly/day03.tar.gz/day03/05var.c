#include<stdio.h>

int main () {
    int num = 0,mo = 0;
    printf("请输入公里数\n");
    scanf("%d",&num);
    mo = 5 + (num - 3) * 1;
    printf("费用为:%d\n",mo);
    return 0;
}

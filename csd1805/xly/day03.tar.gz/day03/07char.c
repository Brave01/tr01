#include<stdio.h>

int main () {
    char num = 65;
    
    printf("num is %c\n",num);
    printf("num is %hhd\n",num);
    return 0;
}

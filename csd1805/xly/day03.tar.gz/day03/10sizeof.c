#include<stdio.h>

int main () {
    char num = 0;
    printf("char所占字节数为%d\n",sizeof(char));
    printf("num所占字节数为%d\n",sizeof(num));

    printf("sizeof(2) is %d\n",sizeof(2));
    return 0;
}

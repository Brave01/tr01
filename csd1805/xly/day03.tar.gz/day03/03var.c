#include<stdio.h>

int main () {
/*    int a = 1,b = 9;
    printf("%d X %d = %d\n",a,b,a*b);
    a = a + 1;
    b = b - 1;
    printf("%d X %d = %d\n",a,b,a*b);
    a = a + 1;
    b = b - 1;
    printf("%d X %d = %d\n",a,b,a*b);
    a = a + 1;
    b = b - 1;
    printf("%d X %d = %d\n",a,b,a*b);
    a = a + 1;
    b = b - 1;
    printf("%d X %d = %d\n",a,b,a*b);*/

    int a = 1,sum = 10;
    printf("%d X %d = %d\n",a,sum-a,a*(sum - a));
    a = a + 1;
    printf("%d X %d = %d\n",a,sum-a,a*(sum - a));
    a = a + 1;
    printf("%d X %d = %d\n",a,sum-a,a*(sum - a));
    a = a + 1;
    printf("%d X %d = %d\n",a,sum-a,a*(sum - a));
    a = a + 1;
    printf("%d X %d = %d\n",a,sum-a,a*(sum - a));






    return 0;
}







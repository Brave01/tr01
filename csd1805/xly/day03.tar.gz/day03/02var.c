#include<stdio.h>

int main () {
    int num = 0;
    printf("num 地址是%p\n",&num);
    return 0;
}

/*
 * 判断一个数是否跟7有关
 */


#include <stdio.h>

int main()
{
    int num = 0;
   //1. 输入数据
   printf("请输入一个1-99的整数：");
   scanf("%d",&num); 

   //2.判断
   if(num >0 && num<100)
   {
       if(num % 7 == 0 || num % 10 == 7 ||num /10 == 7)     
       {
            printf("num 跟7有关\n"); 
       }
       else
       {
           printf("num 跟7无关\n");  
       
       }
   
   }

   else
   {
        printf("您输入数不对\n"); 
   }
    

    return 0;
}


/*
 * <幸运52>猜价格游戏
 * 
 * 运行程序,计算机会随机生成一个iphoneX 的价格  
 * iphoneX 价格范围 8000 - 9000  
 * 用户输入一个10的整数倍的价格,
 * 计算机会根据玩家输入的价格的提示价格低了或高了
 * 如果用户输入价格正确会打印消息恭喜用户,
 * 并赠送一部iphoneX的手机给玩家～.～
 *
 * 程序已经给出了生成随机价格的代码
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main(){
    int price = 0;
    //guess 变量用于保存玩家输入的价格
    int guess;

    printf("/t/t<幸运52-猜价格游戏\n");
    printf("游戏会随机产生一个iphoneX 的价格 区间在8000-8990之间\n");
    printf("并且价格是10的整数倍\n");
    printf("输入猜的价格后,游戏会提示猜高了或者低了\n");
    printf("在规定的时间，猜对价格会获得一部iphoneX手机\"");
    
    srand(time(0));
    price =8000+(rand()%100)*10; //生成一个8000-8990的价格
                                 //价格是10的整数倍
    //printf("price = %d\n",price); //打印价格可以调试测试用


    //下面是要补充的业务代码,请同学们完成
    
    return 0;
}

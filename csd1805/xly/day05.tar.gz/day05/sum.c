/*
[练习:统计评委评分程序]
从键盘上连续 输入5个整数(循环)  计算平均数(小数)
去掉一个最高分  去掉一个最低分  计算平均成绩
*/
//gg=G
#include <stdio.h>

int main(){
    float sum = 0;
    int i = 0;
    int num = 0;
    float avg = 0;
    int min = 0;
    int max = 0;

     
    for(i = 0;i<5;i++)
    {
        printf("输入一个整数:");
        scanf("%d",&num);
        sum = sum + num;

        if(i == 0)  //第一次输入的数 默认就是最大最小的数
        {
            min = num; 
            max = num; 
        }
        else
        {


            if(min > num)
                min = num;

            if(max < num)
                max = num;

        }
    }      

    avg = sum / 3;
    printf("平均成绩=%f\n",avg);

   return 0;

}



/*
*/


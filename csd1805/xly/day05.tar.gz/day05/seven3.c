/*
 * 打印1-99 所有跟7有关 数
 */


#include <stdio.h>

int main()
{
    int num = 0;

   // for(num = 1;num < 100; num++)
    num =1;
    while(num < 100)
    {
        if(num % 7 == 0 || num % 10 == 7 ||num /10 == 7)     
        {
            printf("%d跟7有关\n",num); 
        }
        num++;
    }

    return 0;
}


/*
 *
 * 输入密码，直到输对为止
 */
#include <stdio.h>

int main(){
   int passwd = 123456; //程序设定密码
   int usr_pd = 0;  //输入密码

   while(1)
   {
       printf("请输入密码:");
       scanf("%d",&usr_pd);

       if(usr_pd == passwd)
       {
            printf("密码正确\n"); 
            break;
       }

   }
    
    return 0;
}
 

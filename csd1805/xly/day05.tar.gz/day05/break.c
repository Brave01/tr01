/*
 * break 使用
 */

#include <stdio.h>

int main(){

    int num = 0;
    //for(int i = 0;i<5;i++)
    //for(;;) //死循环
    while(1) //死循环
    {
        printf("输入一个1-99 之间的数：");
        scanf("%d",&num);
        if(num >0 && num <100)
            break;
    }

    printf("跳出来了吗\n");  
    return 0;
}

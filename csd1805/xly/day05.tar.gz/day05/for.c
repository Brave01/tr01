/*
   将有次数的循环  改成次数不确定的循环
*/
#include <stdio.h>
int main(){
    int num = -1;
   // for(;num<0 || num>100;) //while
    while(num<0 || num>100)
    {
        printf("请输入一个1-99之间的数:");
        scanf("%d",&num);
    }
    printf("num = %d\n",num);
    return 0;
}


#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
int main(){

    int guess = 1; //该变量用于保存用户猜的价格

    srand(time(0));
    int price = 0; //8000 - 8990
    //(0-99)*10+8000
    price=rand()%100*10+8000; //0~ 42

    //printf("price = %d\n",price);
    //请补充代码  

    while(1)
    {

        price=rand()%100*10+8000; //0~ 42
        guess=rand()%100*10+8000; //0~ 42

        //printf("请输入您猜的价格:");
        //scanf("%d",&guess);

        if(guess>price)  
        {
            printf("猜高了\n");
        }

        if(guess<price)  
        {
            printf("猜低了\n");
        }

        if(guess == price)
        {
            printf("恭喜你 猜对了\n"); 
            break; 
        }

        sleep(1);
    }
return 0;
}

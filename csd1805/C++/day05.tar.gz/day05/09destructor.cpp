#include <iostream>
using namespace std;
class Integer{
public:
    Integer(int data = 0)
        :m_data(new int(data)){
        //m_data = new int(data);
    }
    void print(void)const{
        cout << *m_data << endl;
    }
    ~Integer(void){
        cout << "Integer的析构函数" << endl;
        delete m_data;
        m_data = NULL;
    }
private:
    int* m_data;
};
int main(void)
{
    if(1){
        Integer i(100);
        i.print();//100
        cout << "test1" << endl;
        Integer* pi = new Integer(200);
        pi->print();//200
        delete pi;//delete-->调用析构
        cout << "test3" << endl;
    }//}-->调用析构函数
    cout << "test2" << endl;
    return 0;
}








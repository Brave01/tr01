#include <iostream>
using namespace std;
class A{
public:
    //void func1(const A* this)
    void func1(void) const {
        cout << "常函数" << endl;
    }
    //void func2(A* this)
    void func2(void){
        cout << "非 常函数" << endl;
    }
};
int main(void)
{
    A a;
    a.func1();//A::func1(&a),A*
    a.func2();

    const A a2 = a;
    a2.func1();//A::func1(&a2),const A*
    //a2.func2();//error
    
    const A* pa = &a;//pa常指针
    pa->func1();
    //pa->func2();//error
   
    const A& ra = a;//ra常引用
    ra.func1();
    //ra.func2();//error

    return 0;
}








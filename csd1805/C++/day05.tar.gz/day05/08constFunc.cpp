#include <iostream>
using namespace std;
class A{
public:
    void func(void)const{//const A* this
        cout << "func常版本" << endl;
    }
    void func(void){//A* this
        cout << "func非常版本" << endl;
    }
};
int main(void)
{
    A a;
    a.func();//非常版本
    const A& ra = a;
    ra.func();//常版本
    return 0;
}







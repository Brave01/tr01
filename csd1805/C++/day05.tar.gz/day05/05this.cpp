#include <iostream>
using namespace std;

class Student;//短视声明
class Teacher{
public:
    //向参数表示的学生对象提问
    void educate(Student* s);
    //获取学生对象回答的答案
    void reply(const string& answer);
private:
    string m_answer;//保存答案
};
class Student{
public:
    //接收问题,并将答案传回给教师对象
    void ask(
        const string& question,Teacher* t);
};
void Teacher::educate(Student* s){
    s->ask("什么是this指针?",this);
    cout << "学生回答:" << m_answer << endl;
}
void Teacher::reply(const string& answer){
    m_answer = answer;
}
void Student::ask(
    const string& question,Teacher* t){
    cout << "问题:" << question << endl;
    t->reply("this指针指向调用对象的地址");
}
int main(void)
{
    Teacher teacher;
    Student student;
    teacher.educate(&student);
    return 0;
}










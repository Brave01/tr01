#include <iostream>
using namespace std;
class Integer{
public:
    Integer(int data = 0)
        :m_data(new int(data)){
        //m_data = new int(data);
    }
    void print(void)const{
        cout << *m_data << endl;
    }
    ~Integer(void){
        cout << "Integer的析构函数" << endl;
        delete m_data;
        m_data = NULL;
    }
    /*编译器提供的缺省拷贝构造函数(浅拷贝)*/
    /*Integer(const Integer& that){
        cout << "缺省的拷贝构造" << endl;
        m_data = that.m_data;
    }*/
    /*自定义深拷贝构造函数*/
    Integer(const Integer& that){
        cout << "自定义深拷贝" << endl;
        //m_data = new int;
        //*m_data = *that.m_data;
        m_data = new int(*that.m_data);
    }
private:
    int* m_data;
};
int main(void)
{
    Integer i1(100);
    Integer i2 = i1;//拷贝构造
    i1.print();//100
    i2.print();//100
    return 0;
}








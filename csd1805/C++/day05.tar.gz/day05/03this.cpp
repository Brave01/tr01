#include <iostream>
using namespace std;

class User{
public:
    /*User(const string& name,int age)
        :m_name(name),m_age(age){
        cout << "构造函数:" << this << endl;
    }*/
    //使用this指针区分成员变量和参数变量
    User(const string& m_name,int m_age){
        this->m_name = m_name;
        this->m_age = m_age;
    }
    void print(void){
        cout << "我叫" << this->m_name << 
          ",今年" << this->m_age << "岁" 
          << endl;
    }/*编译器编译以后:
    void print(User* this){
        cout << this->m_name << .. 
            << this->m_age << .. 
    }*/
private:
    string m_name;
    int m_age;
};
int main(void)
{
    User u1("张三",22);
    cout << "&u1=" << &u1 << endl;
    
    User u2("李四",23);
    cout << "&u2=" << &u2 << endl;

    u1.print();//User::print(&u1);
    u2.print();//User::print(&u2);
    return 0;
}







#include <iostream>
using namespace std;
class A{
public:
    A(int data = 0):m_data(data){}
    void print(void) const {//常函数
        cout << m_data++ << endl;
    }/*
    void print(const A* this){
        cout << this->m_data++ << endl;
    }*/
private:
    mutable int m_data;
};
int main(void)
{
    A a(100);
    a.print();//100
    a.print();//101
    a.print();//102
    return 0;
}






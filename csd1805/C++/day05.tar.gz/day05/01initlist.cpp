#include <iostream>
using namespace std;
int g = 100;
class A{
public:
    A(void):m_r(g),m_c(200){
        //m_r = g;
        //m_c = 200;
    }
    int& m_r;
    const int m_c;
};
int main(void)
{
    A a;
    cout << a.m_r << endl;//100
    cout << a.m_c << endl;//200
    return 0;
}









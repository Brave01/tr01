#include <iostream>
#include <cstring>
using namespace std;
class String{
public:
    //构造函数
    String(const char* str){
        m_str = new char[strlen(str)+1];
        strcpy(m_str,str);
    }
    //练习:析构函数,拷贝构造
    ~String(void){
        delete[] m_str;
        m_str = NULL;
    }
    String(const String& that){
        m_str = 
            new char[strlen(that.m_str)+1];
        strcpy(m_str,that.m_str);
    }
    const char* c_str(void)const{
        return m_str;
    }
private:
    char* m_str;
};
int main(void)
{
    String s("hello");
    cout << s.c_str() << endl;//hello
    String s2 = s;
    cout << s2.c_str() << endl;//hello

    return 0;
}








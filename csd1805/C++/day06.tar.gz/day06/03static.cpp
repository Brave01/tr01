#include <iostream>
using namespace std;
class A{
public:
    //普通成员变量在构造函数中定义和初始化
    A(int data=0):m_data(data){}
    int m_data;
    static int s_data;//声明
};
//静态成员变量的定义和初始化要在类的外部完成
int A::s_data = 100;//定义
int main(void)
{
    A a(200);
    //静态成员变量不属于对象
    cout << sizeof(a) << endl;//4
    
    //静态成员变量可以通过"类名::"去访问
    cout << A::s_data << endl;//100
    //普通的成员变量必须通过对象去访问
    cout << a.m_data << endl;//200

    //静态成员变量也可以通过对象去访问
    cout << a.s_data << endl;//ok,100

    A a2(a);
    a2.m_data = 222;
    a2.s_data = 111;//A::s_data = 111

    cout << a.s_data << endl;//111
    cout << a.m_data << endl;//200

    return 0;

}







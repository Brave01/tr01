#include <iostream>
using namespace std;
class Student{
public:
    Student(const string& name)
        :m_name(name){}
    void who(void){
        cout << "我叫" << m_name << endl;
    }
    string m_name;
};
int main(void)
{
    //成员变量指针
    string Student::*pname 
        = &Student::m_name;
    //成员函数指针
    void (Student::*pwho)(void) 
        = &Student::who;
    Student s("王建立");
    cout << s.*pname << endl;
    (s.*pwho)();

    return 0;
}







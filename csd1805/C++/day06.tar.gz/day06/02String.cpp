#include <iostream>
#include <cstring>
using namespace std;
class String{
public:
    //构造函数
    String(const char* str){
        m_str = new char[strlen(str)+1];
        strcpy(m_str,str);
    }
    //析构函数
    ~String(void){
        delete[] m_str;
        m_str = NULL;
    }
    //深拷贝构造
    String(const String& that){
        m_str = 
            new char[strlen(that.m_str)+1];
        strcpy(m_str,that.m_str);
    }
    //深拷贝赋值
    //s2 = s3;-->s2.operator=(s3)
    String& operator=(const String& that){
        if(&that != this){
            delete[] m_str;
            m_str = new char[
                strlen(that.m_str)+1];
            strcpy(m_str,that.m_str);
            //分配新内存有可能失败，所以可以
            //先分配新内存，后释放旧内存
            /*char* str = new char[
                strlen(that.m_str)+1];
            delete[] m_str;
            m_str = strcpy(str,that.m_str);
            */
            //复用拷贝构造和析构函数
            /*String tmp(that);
            swap(m_str,tmp.m_str);*/
        }
        return *this;
    }
    const char* c_str(void)const{
        return m_str;
    }
private:
    char* m_str;
};
int main(void)
{
    String s("hello");
    cout << s.c_str() << endl;//hello
    String s2 = s;
    cout << s2.c_str() << endl;//hello
    String s3("今天是星期五");
    s2 = s3;//拷贝赋值
    cout << s2.c_str() << endl;

    return 0;
}








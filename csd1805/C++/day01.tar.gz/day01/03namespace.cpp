#include <iostream>
using namespace std;//以后使用标准名字空间的成员可以省略"std::"

namespace ns1{
    void func(void){
        cout << "ns1::func" << endl;
    }
    int num = 100;
}
namespace ns2{
    void func(void){
        cout << "ns2::func" << endl;
    }
    int num = 200;
}

int num = 300;//放到无名名字空间里面

int main(void)
{
    /*
    using ns1::func;//名字空间声明
    func();//ns1::func
    //using ns2::func;
    using namespace ns2;//名字空间指令
    func();//ns1::func
    ns2::func();*/

    cout << num << endl;//300
    using ns1::num;
    cout << num << endl;//100
    cout << ns2::num << endl;//200
    cout << ::num << endl;//300

    return 0;
}




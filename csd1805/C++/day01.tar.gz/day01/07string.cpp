#include <iostream>
#include <cstring>
using namespace std;

int main(void)
{
    //定义字符串
    string s = "hello";
    cout << s << endl;

    //字符串拷贝
    string s2 = s;
    cout << s2 << endl;//hello

    //字符串连接
    //s = s + " world";
    s += " world";
    cout << s << endl;//hello world

    //字符串比较
    cout << (s == s2) << endl;//0
    cout << (s > s2) << endl;//1

    //随机访问:获取字符串中某个字符
    s[0] = 'H';
    s[6] = 'W';
    cout << s << endl;//Hello World

    //获取字符串的长度
    cout << s.size() << endl;//11
    cout << s.length() << endl;//11

    //将string转换为C风格const char*
    cout << strlen(s.c_str()) << endl;//11
    
    return 0;
}









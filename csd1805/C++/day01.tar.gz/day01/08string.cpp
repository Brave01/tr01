#include <iostream>
using namespace std;
int main(void)
{
    string str;
    int count=0;
    cout << "请输入一个字符串:" << endl;
    cin >> str;
    for(int i=0;i<str.size();i++){
        if(str[i] == 'a' || str[i] == 'A'){
            ++count;
        }
    }
    cout << "A/a个数是:" << count << endl;
    return 0;
}



#include <iostream>
using namespace std;
int main(void)
{
    enum Color{RED,YELLOW,BLUE};
    cout << RED << ',' << YELLOW << ','
        << BLUE << endl;//0 1 2
    /*enum*/ Color c;
    //c = 2;//C:ok,C++:error
    c = BLUE;//C:ok,C++:ok
    cout << c << endl;//2

    return 0;
}





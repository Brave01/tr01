#include <iostream>
//#include <stdio.h>
#include <cstdio>//语法和上面等价
int main(void)
{
    std::cout << "hello world!"<< std::endl;
    printf("hello world!\n");
    return 0;
}









#include <iostream>
using namespace std;//以后使用标准名字空间的成员可以省略"std::"

namespace ns1{
    void func(void){
        cout << "ns1::func" << endl;
    }
}
namespace ns2{
    void func(void){
        cout << "ns2::func" << endl;
    }
}
int main(void)
{
    //func();//error
    //名字空间里面成员不能直接访问
    //可以通过"空间名::"去访问
    ns1::func();
    ns2::func();

    //名字空间指令
    using namespace ns1;
    /*ns1::*/func();
    using namespace ns2;
    //func();//歧义错误
    ns2::func();

    return 0;
}


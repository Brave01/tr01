#include <iostream>
using namespace std;
int foo(int i){
    cout << "foo(int)" << endl;
}
void foo(int i,int j){
    cout << "foo(int,int)" << endl;
}
void foo(int a,float f){
    cout << "foo(int,float)" << endl;
}
int main(void)
{
    foo(10);
    foo(10,20);
    foo(10,1.23f);
   
    /*函数指针的类型决定其匹配的版本*/
    void (*pfoo)(int,float) = foo;
    pfoo(10,20);

    return 0;
}






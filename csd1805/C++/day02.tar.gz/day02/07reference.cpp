#include <iostream>
using namespace std;
int main(void)
{
    int a = 66;
    int& b = a;//b引用a,b就是a的别名
    cout << "&a=" << &a << endl;
    cout << "&b=" << &b << endl;
    b++;
    cout << "a=" << a << endl;//67
    cout << "b=" << b << endl;//67

    //int& r;//error
    //double& r = a;//error

}




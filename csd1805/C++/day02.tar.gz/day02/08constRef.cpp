#include <iostream>
using namespace std;
int func(void){
    int num = 123;
    //编译会生成临时变量保存return数据
    return num;//int tmp=num
}
int main(void)
{
    //函数返回的是临时变量(右值),普通引用
    //无法接收,常引用可以
    //int res = tmp;
    //int& res = func();//error
    const int& res = func();//ok
    cout << res << endl;//123

    //100是常数(右值),普通引用不能引用右值
    //int& ri = 100;//error
    //常引用可以引用右值
    const int& ri = 100;//ok

    int i = 200;
    //i是左值,但是给double类型rd初始化时需要
    //先做隐式转换,转换之后结果会保存到一个
    //临时变量中,临时变量都是右值,所以error
    //double& rd = i;//error

    //rd实际引用的是临时变量,不是i本身
    const double& rd = i;
    cout << "&i=" << &i << endl;
    cout << "&rd=" << &rd << endl;

    return 0;
}






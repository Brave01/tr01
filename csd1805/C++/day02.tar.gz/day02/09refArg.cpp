#include <iostream>
using namespace std;

/*void swap1(int* x,int* y){
    *x = *x ^ *y;//011 ^ 101 = 110(x)
    *y = *x ^ *y;//110 ^ 101 = 011(y)->3
    *x = *x ^ *y;//110 ^ 011 = 101(x)->5
}*/
void swap2(int& x,int& y){
    x = x ^ y;
    y = x ^ y;
    x = x ^ y;
}
int main(void)
{
    int a = 3,b = 5;
    //swap1(&a,&b);
    swap2(a,b);
    //a=5,b=3
    cout << "a=" << a << ",b=" << b << endl;
    return 0;
}






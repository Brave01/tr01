#include <iostream>
using namespace std;
struct Student{
    char name[128];
    int age;
    int no;
};
void print(const Student& s){
    cout << "我叫" << s.name << ",今年" <<
        s.age/*++*/ <<"岁,学号是" << s.no 
        << endl;
}
int main(void)
{
    const Student stu = {"老王",45,10086};
    print(stu);
    print(stu);
    print(stu);
    return 0;
}














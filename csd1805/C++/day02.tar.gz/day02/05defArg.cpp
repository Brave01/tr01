#include <iostream>
using namespace std;
//函数声明
void foo(int a,int b = 200,int c = 300);
int main(void)
{
    foo(10);//10,200,300
    foo(10,20);//10,20,300
    foo(10,20,30);//10,20,30
    return 0;
}
//函数定义
void foo(int a,int b/*=200*/,int c/*=300*/){
    cout << a << ',' << b << ',' << c
        << endl;
}





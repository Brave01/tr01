
extern void hello(void);
//extern void _Z5hellov(void);

int main(void)
{
    hello();
    //_Z5hellov();
    return 0;
}

#include <iostream>
using namespace std;

int main(void)
{
    int* pi = new int;
    *pi = 123;
    cout << *pi << endl;
    delete pi;//防止内存泄露
    pi = NULL;//避免野指针
    
    //new内存同时初始化
    int* p2 = new int(321);
    cout << *p2 << endl;//321
    delete p2;
    p2 = NULL;

    //new数组,包含10元素
    int* pa = new int[10];
    for(int i=0;i<10;i++){
        pa[i] = i;
        cout << pa[i] << ' ';
    }
    cout << endl;
    delete[] pa;
    pa = NULL;

    //new数组,同时初始化,需要C++11标准支持
    int* pa2 = 
        new int[10]{9,8,7,6,5,4,3,2,1,0};
    for(int i=0;i<10;i++){
        cout << pa2[i] << ' ';
    }
    cout << endl;
    delete[] pa2;
    pa2 = NULL;

    return 0;
}







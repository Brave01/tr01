#include <iostream>
using namespace std;

int main(void)
{
    bool b = false;
    cout << sizeof(b) << endl;//1
    cout << b << endl;//0
    b = 3+5;
    cout << b << endl;//1
    b = 10/3.0;
    cout << b << endl;//1
    char* p = NULL;
    b = p;
    cout << b << endl;//0
    return 0;
}










void func(int i,double d){}
void func(double i,double d){}

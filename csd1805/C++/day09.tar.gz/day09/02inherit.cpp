#include <iostream>
using namespace std;
class Base{
public:
    Base(void):m_i(0){}
    Base(int i):m_i(i){}
    Base(const Base& that):m_i(that.m_i){
        cout << "Base(const Base&)" << endl;
    }
    Base& operator=(const Base& that){
        cout << "Base::operator=" << endl;
        if(&that != this){
            m_i = that.m_i;
        }
        return *this;
    }
    int m_i;
};
class Derived:public Base{
public:
    Derived(void):m_i(0){}
    Derived(int i):Base(i),m_i(i){}
    //Base(that):指明基类部分也要以拷贝方式
    //来初始化
    Derived(const Derived& that)
        :m_i(that.m_i),Base(that){}
    Derived& operator=(const Derived& that){
        if(&that != this){
            //显式调用基类的拷贝赋值函数,
            //完成基类子对象的复制
            Base::operator=(that);
            m_i = that.m_i;
        }
        return *this;
    }
    int m_i;
};
int main(void)
{
    Derived d1(123);
    Derived d2(d1);//拷贝构造
    cout << d1.m_i << ',' << d1.Base::m_i
        << endl;//123 123
    cout << d2.m_i << ',' << d2.Base::m_i
        << endl;//123 123

    Derived d3;
    d3 = d1;//拷贝赋值
    cout << d3.m_i << ',' << d3.Base::m_i
        << endl;//123 123

}














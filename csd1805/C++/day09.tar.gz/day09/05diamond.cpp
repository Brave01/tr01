#include <iostream>
using namespace std;
/* 钻石继承
 *   A(int m_data)
 *  / \
 * B   C
 *  \ /
 *   D(汇聚子类)
 * */
class A{
public:
    A(int data):m_data(data){
        cout << "A:" << this << "," 
            << sizeof(A) << endl;
    }
protected:
    int m_data;
};
class B:virtual public A{//虚继承
public:
    B(int data):A(data){
        cout << "B:" << this << "," << 
            sizeof(B) << endl;
    }
    void set(int data){
        m_data = data;
    }
};
class C:virtual public A{//虚继承
public:
    C(int data):A(data){
        cout << "C:" << this << "," << 
            sizeof(C) << endl;
    }
    int get(void){
        return m_data;
    }
};
class D:public B,public C{
public:
    //虚继承,继承链最末端的汇聚子类负责
    //构造公共基类子对象
    D(int data):B(data),C(data),A(data){
        cout << "D:" << this << "," << 
            sizeof(D) << endl;
    }
};
int main(void)
{
    D d(100);
    cout << d.get() << endl;//100
    d.set(200);
    cout << d.get() << endl;//200
    return 0;
}













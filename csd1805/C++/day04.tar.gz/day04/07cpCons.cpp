#include <iostream>
using namespace std;
class A{
public:
    A(int data = 0){
        cout << "A(int)" << endl;
        m_data = data;
    }
    A(const A& that){
        cout << "A(const A&)" << endl;
        m_data = that.m_data;
    }
    int m_data;
};
class B{
public:
    A m_a;//成员子对象
};
int main(void)
{
    B b;
    b.m_a.m_data = 12345;
    B b2(b);//拷贝构造
    cout << b.m_a.m_data << endl;//12345
    cout << b2.m_a.m_data << endl;//12345
    return 0;
}















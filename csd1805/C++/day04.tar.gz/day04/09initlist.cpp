#include <iostream>
using namespace std;
class Student{
public:
    //先把成员变量定义出来(内存分配)
    //再执行构函数函数体,赋初值
    /*Student(const string& name,int age,
            int no){
        cout << "构造函数" << endl;
        m_name = name;
        m_age = age;
        m_no = no;
    }*/
    //使用初始化表:定义成员变量同时初始化
    Student(const string& name,int age,
        int no):m_name(name),m_age(age),
                m_no(no){}

    void who(void){
        cout << "我叫" << m_name << ",今年"
            << m_age << "岁,学号是" << m_no
            << endl;
    }
private:
    string m_name;
    int m_age;
    int m_no;
};
int main(void)
{
    //创建对象,实例化对象,构造对象
    //(...),指明构造函数需要的实参
    Student s("李辉",35,10011);
    s.who();

    return 0;
}











#include <iostream>
using namespace std;
class A{
public:
    A(int data){
        cout << "A的构造函数" << endl;
        m_data = data;
    }
    int m_data;
};
class B{
public:
    //:m_a(..),显式指明成员子对象m_a的
    //初始化方式
    B(void):m_a(12345){
        cout << "B的构造函数" << endl;
    }
    A m_a;
};
int main(void)
{
    B b;
    return 0;
}









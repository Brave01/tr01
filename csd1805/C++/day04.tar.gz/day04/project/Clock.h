#ifndef __CLOCK_H
#define __CLOCK_H

#include <iostream>
#include <cstdio>
#include <ctime>
#include <unistd.h>
//类的声明
class Clock{
public:
    Clock(time_t t);
    void run(void);
private:
    int m_hour;
    int m_min;
    int m_sec;
};

#endif 




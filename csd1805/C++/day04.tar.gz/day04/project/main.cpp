#include "Clock.h"

int main(void)
{
    Clock c(time(0));
    c.run();
    return 0;
}

#include "Clock.h"
//类的实现
//使用"类名::"指明该函数属于哪个类
Clock::Clock(time_t t){
    tm* local = localtime(&t);
    m_hour = local->tm_hour;
    m_min = local->tm_min;
    m_sec = local->tm_sec;
}
void Clock::run(void){
    while(1){
        printf("\r%02d:%02d:%02d",
                m_hour,m_min,m_sec);
        fflush(stdout);//刷新输出缓冲区
        if(++m_sec == 60){
            m_sec = 0;
            if(++m_min == 60){
                m_min = 0;
                if(++m_hour == 24)
                    m_hour = 0;
            }
        }
        sleep(1);
    }
}






#include <iostream>
using namespace std;

class A{
public:
    A(int data = 0){
        cout << "A(int=0)" << endl;
        m_data = data;
    }
    //拷贝构造函数
    A(const A& that){
        cout << "A(const A&)" << endl;
        m_data = that.m_data;    
    }
    int m_data;
};
int main(void)
{
    const A a1(12345);
    A a2(a1);
    //A a2 = a1;//和上面写法完全等价
    cout << a1.m_data << endl;
    cout << a2.m_data << endl;

    return 0;
}










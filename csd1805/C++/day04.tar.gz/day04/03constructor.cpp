#include <iostream>
using namespace std;
class Student{
public:
    Student(const string& name,int age,
            int no){
        cout << "构造函数" << endl;
        m_name = name;
        m_age = age;
        m_no = no;
    }
    void who(void){
        cout << "我叫" << m_name << ",今年"
            << m_age << "岁,学号是" << m_no
            << endl;
    }
private:
    string m_name;
    int m_age;
    int m_no;
};
int main(void)
{
    //创建对象,实例化对象,构造对象
    //(...),指明构造函数需要的实参
    //Student s("李辉",35,10011);
    //和上面等价
    Student s = Student("李辉",35,10011);
    s.who();
    //栈区创建对象数组
    Student sarr[3] = {
        Student("白骨精",19,10012),
        Student("林黛玉",18,10013),
        Student("潘金莲",20,10014)};
    sarr[0].who();
    sarr[1].who();
    sarr[2].who();
    //在堆区创建单个对象
    Student* ps = 
        new Student("貂蝉",17,10015);
    ps->who();//(*ps).who()
    delete ps;
    ps = NULL;
    //在堆区创建多个对象,c++11
    Student* parr = new Student[3]{
        Student("小乔",28,10016),
        Student("大乔",29,10017),
        Student("西施",30,10018)};
    parr[0].who();//(*(parr+0)).who()
    parr[1].who();
    parr[2].who();
    delete[] parr;
    parr = NULL;
    
    return 0;
}











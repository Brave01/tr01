#include <iostream>
using namespace std;
class A{
public:
    A(void){
        cout << "A(void)" << endl;
    }
    A(const A& that){
        cout << "A(const A&)" << endl;
    }
};
void foo(A a){}
A bar(void){
    A a;//无参
    cout << "&a=" << &a << endl; 
    return a;//拷贝
}
int main(void)
{
    A a1;//无参
    A a2 = a1;//拷贝
    foo(a1);//拷贝
    /* 正常情况bar返回a拷贝到临时对象,临时
     * 对象再拷贝到a3,发生两次拷贝;但是因
     * 为编译器优化,让a3直接引用a,不再发生
     * 拷贝*/
    //去优化的选项
    //g++ xx.cpp -fno-elide-constructors
    A a3 = bar();//拷贝
    cout << "&a3=" << &a3 << endl;
    return 0;
}



















#include <iostream>
using namespace std;
class Integer{
public:
    Integer(void){
        cout << "Integer(void)" << endl;
        m_data = 0;
    }
    //int->Integer
    //类型转换构造函数
    /*explicit*/ Integer(int data){
        cout << "Integer(int)" << endl;
        m_data = data;
    }
    void print(void){
        cout << m_data << endl;
    }
private:
    int m_data;
};
int main(void)
{
    Integer i;
    i.print();//0
    //1)自动调用类型转换构造函数,用123作为
    //构造实参创建一个临时对象
    //2)再用临时对象给i进行赋值操作
    i = 123;
    i.print();//123

    //使用类型转换构造函数实现的隐式转换代码
    //可读性差,推荐使用显式转换
    //i = (Integer)321;//C风格
    i = Integer(321);//C++风格
    i.print();//321

    return 0;
}











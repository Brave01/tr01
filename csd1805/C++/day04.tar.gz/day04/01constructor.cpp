#include <iostream>
using namespace std;
class Student{
public:
    Student(const string& name,int age,
            int no){
        cout << "构造函数" << endl;
        m_name = name;
        m_age = age;
        m_no = no;
    }
    void who(void){
        cout << "我叫" << m_name << ",今年"
            << m_age << "岁,学号是" << m_no
            << endl;
    }
private:
    string m_name;
    int m_age;
    int m_no;
};
int main(void)
{
    //创建对象,实例化对象,构造对象
    //(...),指明构造函数需要的实参
    Student s("李辉",35,10011);
    s.who();

    //构造函数不能想普通成员函数一样去调用
    //s.Student("李三",36,10012);
    return 0;
}











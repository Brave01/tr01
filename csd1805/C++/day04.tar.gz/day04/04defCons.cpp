#include <iostream>
using namespace std;

class A{
public:
    A(void){
        cout << "A的无参构造函数" << endl;
        m_data = 12345;
    }
    int m_data;
};
class B{
public:
    //B(int num){}
    int m_num;//基本类型
    A m_a;//类 类型(成员子对象)
};
int main(void)
{
    B b;
    cout << b.m_num << endl;//?
    cout << b.m_a.m_data << endl;//12345
    return 0;
}










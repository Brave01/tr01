#include <iostream>
using namespace std;
class FileError{};
class MemoryError{};
//函数声明
void func(void) 
    throw(FileError,MemoryError,int);
//函数定义
void func(void) 
    throw(int,FileError,MemoryError){
    throw MemoryError();
    throw -1;
    //throw FileError();
}
int main(void)
{
    try{
        func();
    }
    catch(FileError& ex){
        cout << "文件错误的处理" << endl;
        return -1;
    }
    catch(MemoryError& ex){
        cout << "内存错误的处理" << endl;
        return -1;
    }
    catch(int ex){
        cout << "int错误的处理" << endl;
        return -1;
    }
}






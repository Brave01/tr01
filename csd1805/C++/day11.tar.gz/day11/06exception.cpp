#include <iostream>
using namespace std;
class Base{
public:
    virtual void func(void)throw(int){}
    virtual ~Base(void)throw(){}
};
class Derived:public Base{
public:
    void func(void)throw(){}
    ~Derived(void)throw(){}
};
int main(void){
    return 0;
}




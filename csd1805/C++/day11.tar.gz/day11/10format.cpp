#include <iostream>
#include <iomanip>
using namespace std;

int main(void)
{
    cout << 100/3.0 << endl;//33.3333
    //cout.precision(10);
    //cout << 100/3.0 << endl;//33.33333333
    cout << setprecision(10) << 100/3.0
        << endl;
    cout << '[';
    /*cout.width(10);//设置域宽
    cout.fill('-');//设置空白位置填充的字符
    cout.setf(ios::showpos);//显示符号位
    cout.setf(ios::internal);//内插对齐 
    cout << 12345 << "]" << endl;*/
    cout << setw(10) << setfill('-') <<
        showpos << internal << 12345 << 
        ']' << endl;
    return 0;
}








#include <iostream>
using namespace std;
class A{
public:
    A(void){ cout << "A的构造" << endl; }
    ~A(void){ cout << "A的析构" << endl; }
};
class B{
public:
    B(void):m_a(new A){
        if("error"){
            delete m_a;
            throw -1;
        }
        //...
    }
    ~B(void){
        delete m_a;
    }
    A* m_a;
};
int main(void)
{
    try{
        B b;
    }
    catch(int ex){
        cout << "捕获到异常:" << ex << endl;
        return 0;
    }
}








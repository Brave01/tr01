#include <fstream>
#include <iostream>
using namespace std;

int main(void)
{
    ofstream ofs("last.txt");
    char wbuf[] = "C++终于结束了!";
    ofs.write(wbuf,sizeof(wbuf));
    ofs.close();

    ifstream ifs("last.txt");
    char rbuf[50] = {0};
    ifs.read(rbuf,sizeof(rbuf));
    cout << "读到数据:" << rbuf << endl;
    ifs.close();

    return 0;
}





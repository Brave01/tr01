#include <fstream>
#include <iostream>
using namespace std;
int main(void)
{
    ofstream ofs("file.txt");
    ofs << 12345 << ' ' << 6.78 << ' ' 
        << "hello" << endl;
    ofs.close();

    ifstream ifs("file.txt");
    int i;
    double d;
    string s;
    ifs >> i >> d >> s;
    cout << i << ',' << d << ',' 
        << s << endl;
    ifs.close();
    return 0;
}





#include <iostream>
#include <sstream>
using namespace std;
int main(void)
{
    int i = 12345;
    double d = 6.78;
    string s = "hello";
    /* char buf[100] = {0}
     * sprintf(buf,"%d %g %s",i,d,s);
     * */
    ostringstream oss;
    oss << i << ' ' << d  << ' ' << s;
    cout << oss.str() << endl;

    istringstream iss;
    iss.str("54321 8.76 world");
    int i2;
    double d2;
    string s2;
    //sscanf(buf,"%d %g %s",&i2,&d2,s)
    iss >> i2 >> d2 >> s2;
    cout << i2 << ',' << d2 << ',' << s2 
        << endl;
    return 0;
}






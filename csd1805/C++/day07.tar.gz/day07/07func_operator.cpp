#include <iostream>
using namespace std;

class Func{
public:
    double operator()(double x){
        return x*x;
    }
    int operator()(int x,int y){
        return x+y;
    }
};
int main(void)
{
    Func func;
    //func.operator()(3.3)
    cout << func(3.3) << endl;//10.89
    //func.operator()(10,20)
    cout << func(10,20) << endl;//30
    return 0;
}








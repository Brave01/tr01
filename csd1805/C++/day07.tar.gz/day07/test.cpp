#include <iostream>
using namespace std;

int main(void)
{
    int i = 1;
    cout << i++ << endl;//1
    cout << i << endl;//2

    //i++ = 10;
    //i++++;

    //cout << i << endl;//10
    //cout << i << endl;//13

    //++10;
}






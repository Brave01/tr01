#include <iostream>
using namespace std;
class Integer{
public:
    Integer(int i):m_i(i){}
    void print(void)const{
        cout << m_i << endl;
    }
    //前++:成员函数形式
    Integer& operator++(void){
        ++m_i;
        return *this;
    }
    //前--:全局函数形式
    friend Integer& operator--(Integer& i){
        --i.m_i;
        return i;
    }
    //后++:成员函数形式
    const Integer operator++(int){
        Integer old = *this;
        ++m_i;//++(*this)
        return old;
    }
    //后--:全局函数形式
    friend const Integer operator--(
            Integer& i,int){
        Integer old = i;
        --i.m_i;//--i
        return old;
    }
private:
    int m_i;
};
int main(void)
{
    Integer i(100);
    Integer j = ++i;//i.operator++()
    j.print();//101
    i.print();//101
    j = ++++i;//i.operator++().operator++()
    j.print();//103
    i.print();//103

    j = --i;//operator--(i);
    j.print();//102
    i.print();//102
    j = ----i;
    j.print();//100
    i.print();//100

    j = i++;//i.operator++(0/*哑元*/)
    j.print();//100
    i.print();//101

    j = i--;//operator--(i,0)
    j.print();//101
    i.print();//100

    return 0;
}









#include <iostream>
using namespace std;

int main(void)
{
    int* pi = NULL;
    //char c = (long)pi;//C风格
    char c = long(pi);//C++风格

    void* pv = pi;
    //静态类型转换,合理:ok
    pi = static_cast<int*>(pv);
    //静态类型转换,不合理:error
    c = static_cast<long>(pi);

    return 0;
}




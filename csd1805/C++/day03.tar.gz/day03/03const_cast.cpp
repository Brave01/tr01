#include <iostream>
using namespace std;

int main(void)
{
    /* volatile修饰的变量表示"易变的",告诉
     * 编译器每次使用该变量时,都要从内存中
     * 去读取,而不要使用寄存器副本,防止编
     * 译器优化导致的错误结果*/
    const volatile int ci = 10;
    int* pci = const_cast<int*>(&ci);
    *pci = 20;
    cout << "ci=" << ci << endl;//20
    cout << "*pci=" << *pci << endl;//20
    cout << "&ci=" << (void*)&ci << endl;
    cout << "pci=" << pci << endl;
    return 0;
}




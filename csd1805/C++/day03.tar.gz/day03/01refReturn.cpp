#include <iostream>
using namespace std;
struct Teacher{
    string name;
    string& who(void){
        return name;
    }
    /* 不要返回局部变量的引用
     * int& func(void){
        int num = 123;
        return num;
    }*/
};
int main(void)
{
    Teacher wang = {"王建立"};
    cout << wang.name << endl;
    wang.who() = "老王";
    cout << wang.name << endl;
}







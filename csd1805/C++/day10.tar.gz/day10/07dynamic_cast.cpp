#include <iostream>
using namespace std;
class A{ virtual void foo(void){} };
class B:public A{ void foo(void){} };
class C:public A{ void foo(void){} };
int main(void)
{
    B b;
    A* pa = &b;
//    B* pb = static_cast<B*>(pa);//合理
//    C* pc = static_cast<C*>(pa);//不合理
    //使用动态类型转换
    B* pb = dynamic_cast<B*>(pa);//合理
    C* pc = dynamic_cast<C*>(pa);//不合理
    cout << "pa=" << pa << endl;
    cout << "pb=" << pb << endl;
    cout << "pc=" << pc << endl;

    A& ra = b;
    C& rc = dynamic_cast<C&>(ra);
    return 0;
}







#include <iostream>
using namespace std;
class Base{
public:
    Base(void){
        cout << "Base的构造函数" << endl;
    }
    //虚析构函数
    virtual ~Base(void){
        cout << "Base的析构函数" << endl;
    }
};
class Derived:public Base{
public:
    Derived(void){
        cout << "Derived的构造函数" << endl;
    }
    ~Derived(void){
        cout << "Derived的析构函数" << endl;
    }
};
int main(void)
{
    Base* pb = new Derived;
    //...
    //pb->析构函数
    delete pb;

}







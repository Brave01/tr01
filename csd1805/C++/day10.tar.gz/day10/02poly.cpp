#include <iostream>
using namespace std;
class Base{
public:
    virtual int cal(int a,int b){
        return a + b;
    }
    /* func是基类中成员函数,里面this指针类型
     * 一定是Base*.
     * 但是func函数的调用对象可以是子类对象,
     * this又指向调用对象,这时this就是一个指
     * 向子类对象的基类指针,再通过它去调用虚
     * 函数,也可以表现多态的特性
     * */
    void func(void){
        cout << cal(10,20) << endl;//200
    }/*
    void func(Base* this=&d){
        cout << this->cal(10,20) << endl;
    }*/
};
class Derived:public Base{
public:
    int cal(int a,int b){
        return a * b;
    }
};
int main(void)
{
    Derived d;
    Base b = d;
    cout << b.cal(10,20) << endl;

    d.func();//func(&d)
    return 0;
    
}









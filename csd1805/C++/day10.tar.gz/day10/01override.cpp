#include <iostream>
using namespace std;
class A{};
class B:public A{};
class Base{
public:
    virtual void foo(void)const{
        cout << "Base::foo()" << endl;
    }
    virtual A& func(void){
        cout << "Base::func()" << endl;
    }
};
class Derived:public Base{
private:
    /*virtual*/ void foo(void)const{
        cout << "Derived::foo()" << endl;
    }
    B& func(void){
        cout << "Derived::func()" << endl;
    }
};
int main(void)
{
    Derived d;
    Base* pb = &d;
    pb->foo();
    pb->func();
    return 0;
}








#include "Technician.h"

Technician::Technician(const string& name,double salary,double allow)
    :Employee(name,salary,L2),m_allow(allow){
        //保存员工绩效信息
        fprintf(file," %g",m_allow);    
}
Technician::Technician(const string& filename){
    int level;
    char name[20]={0};
    //将ID转换为字符串
    if(access(filename.c_str(),F_OK) == -1){
        cout << "id=" << filename << "员工不存在!" << endl;
    }
    else{
        //打开对应的员工文件
        file = fopen(filename.c_str(),"r+");
        fscanf(file,"%d %d %s %lf %lf",
                &level,&m_id,name,&m_salary,&m_allow);
        m_level = L2;
        m_name = name;
    }
}
Technician::Technician(void){}
Technician::~Technician(void){}


void Technician::printExtra(void)const{
    cout << "职位:技术员" << endl;
    cout << "研发津贴:" << m_allow << endl;
}
double Technician::calMerit(void){
    cout << "请输入进度因数:";
    double factor;
    cin >> factor;
    return 23*8*m_attend * m_allow * factor;
}






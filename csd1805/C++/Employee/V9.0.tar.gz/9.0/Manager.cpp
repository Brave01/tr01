#include "Manager.h"

Manager::Manager(const string& name,double salary,double bonus)
    :Employee(name,salary,L3),m_bonus(bonus){
    //保存经理的绩效奖金
    fprintf(file," %g",m_bonus);    
}
Manager::Manager(const string& filename){
    int level;
    char name[20]={0};
    //将ID转换为字符串
    if(access(filename.c_str(),F_OK) == -1){
        cout << "id=" << filename << "员工不存在!" << endl;
    }
    else{
        //打开对应的员工文件
        file = fopen(filename.c_str(),"r+");
        fscanf(file,"%d %d %s %lf %lf",
                &level,&m_id,name,&m_salary,&m_bonus);
        m_level = L3;
        m_name = name;
    }
}
Manager::Manager(void){}
Manager::~Manager(void){}

void Manager::printExtra(void)const{
    cout << "职位:经理" << endl;
    cout << "绩效奖金:" << m_bonus << endl;
}
double Manager::calMerit(void){
    cout << "请输入绩效因数:";
    double factor;
    cin >> factor;
    return m_bonus * factor;
}



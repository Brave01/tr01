#include "Employee.h"
#include "Technician.h"
#include "Manager.h"
#include "CTO.h"
#include "Company.h"

#include <unistd.h>
#include <cstdio>
#include <cstdlib>

int main()
{
    Company& company = Company::getCompany();
    company.run();
    return 0;
}





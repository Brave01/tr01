#include <iostream>
using namespace std;
//人类(基类)
class Human{
public:
    Human(const string& name,int age)
        :m_name(name),m_age(age),m_id(123){}
    void eat(const string& food){
        cout << "我在吃" << food << endl;
    }
    void sleep(int hour){
        cout << "我睡了" << hour << "小时"
            << endl;
    }
//保护的成员可以在类的内部和子类中访问
protected:
    string m_name;
    int m_age;
public:
    //私有成员子类中无法直接访问,但是可以
    //通过基类提供的接口函数间接访问
    const int& getId(void)const{
        return m_id;
    }
private:
    int m_id;
};
//学生类继承人类(人类派生的一个子类)
class Student:public Human{
public:
    //:Human(..),指明基类部分的初始化方式
    Student(const string& name,int age,
        int no):Human(name,age),m_no(no){}
    void learn(const string& course){
        cout << "我在学" << course << endl;
    }
    void who(void){
        cout << "我叫" << m_name << ",今年"
            << m_age << "岁,学号是" << m_no
            << endl;
        cout << "身份证号:"<<getId() <<endl;
    }
private:
    int m_no;
};
//教师类继承人类(人类派生的另一个子类)
class Teacher:public Human{
public:
    Teacher(const string& name,int age,
        int salary):Human(name,age),
                    m_salary(salary){}
    void teach(const string& course){
        cout << "我在讲" << course << endl;
    }
    void who(void){
        cout << "我叫" << m_name << ",今年"
            << m_age << "岁,工资是" << 
            m_salary << endl;
    }
private:
    int m_salary;
};
int main(void)
{
    Student s("关羽",29,10001);
    s.who();
    s.eat("红烧牛肉面");
    s.sleep(8);
    s.learn("孙武兵法");

    Teacher t("悟空",30,50000);
    t.who();
    t.eat("水蜜桃");
    t.sleep(6);
    t.teach("Unix C编程");

    //Student*-->Human*:向上造型
    Human* ph = &s;
    ph->eat("平谷大桃");
    ph->sleep(2);
    //ph->who();
    
    //Human*-->Student*:向下造型(安全)
    Student* ps = static_cast<Student*>(ph);
    ps->who();

    Human h("林黛玉",28);
    //Human*-->Student*:向下造型(危险)
    Student* ps2 =static_cast<Student*>(&h);
    ps2->who();

    return 0;
}






#include <iostream>
#include <typeinfo>
using namespace std;
//隐式推断类型实参
template<class T>void Max(T x, T y){
    cout << "x:" << typeid(x).name() << "," 
         << "y:" << typeid(y).name() << endl;
}
//类型参数 和 调用参数 不完全相关
template<class D,class T>void Func(T x){

}
template<class T>void Foo(T x, T y){

}
template<class R,class T>R Bar(T x){
    R r;
    return r;
}
int main(){
    int nx=10, ny=20;
    Max(nx,ny);//==>Max<>(nx,ny)==>Max<int>(nx,ny);
    double dx=12.3, dy=45.6;
    Max(dx,dy);
    string sx="world", sy="hello";
    Max(sx,sy);

    Func<double>(nx);
    Foo(nx,static_cast<int>(dy));
    Bar<string>(nx);
    return 0;
}







#include <iostream>
using namespace std;
class Integer{
public:
    Integer(int const& i):m_i(i){}
    Integer operator+(Integer const& that){
        return m_i + that.m_i;
    }
    friend ostream& operator<<(ostream& os, Integer const& that){
        return os << that.m_i;
    }
private:
    int m_i;
};
//类模板
template<class T>class CMath{
public:
    CMath(T const& t1, T const& t2):m_t1(t1),m_t2(t2){}
    T sum(){
        return m_t1 + m_t2;
    }
private:
    T m_t1;
    T m_t2;
};
/*
class CMath<int>{
public:
    CMath(int const& t1, int const& t2):m_t1(t1),m_t2(t2){}
    int sum(){
        return m_t1 + m_t2;
    }
private:
    int m_t1;
    int m_t2;
};
*/
int main(){
    int nx=10, ny=20;
    CMath<int> math(nx,ny);
    cout << math.sum() << endl;
    
    Integer ix=100, iy=200;
    CMath<Integer> math2(ix,iy);
    cout << math2.sum() << endl;

//    CMath<> math3(nx,ny);
    return 0;
}










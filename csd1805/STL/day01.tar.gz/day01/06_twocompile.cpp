#include <iostream>
using namespace std;
class A{
public:
    void foo(){
        cout << "A::foo()" << endl;
    }
};
template<class T>void Func(){
//    rewrewrrewrwer;
    A a;
    a.foo();
    T t;
    t.foo();
}
int main(){
    Func<A>();
    return 0;
}

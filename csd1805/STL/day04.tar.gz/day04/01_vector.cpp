#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

class Student{
public:
    Student(string const& name="",int const& age=0):
                m_name(name),m_age(age){}
    friend ostream& operator<<(ostream& os, Student const& s){
        return os << s.m_name << "," << s.m_age;
    }
    bool operator==(Student const& that)const{
        return m_age==that.m_age;
    }
    bool operator<(Student const& that)const{
        return m_age > that.m_age;
    }
private:
    string m_name;
    int m_age;
};

template<class T>
void print(string const& str, vector<T>& v){
    cout << str << endl;
    typedef typename vector<T>::iterator IT;
    for(IT it=v.begin();it!=v.end();++it){
        cout << *it << ' '; 
    }
    cout << endl << "-------------------" << endl;
}
template<class T>class CMP{
public:
    bool operator()(T const& a, T const& b){
        return a < b;
    }
/*
    bool operator()(int const& a, int const& b){
        return a > b;
    }
    bool operator()(Student const& a, Student const& b){
        return a < b;
    }*/
};
int main(){
    vector<Student> vs;
    vs.push_back(Student("张飞",28));
    vs.push_back(Student("关羽",32));
    vs.push_back(Student("赵云",25));
    vs.push_back(Student("黄忠",44));
    vs.push_back(Student("马超",35));
    print("添加节点后:", vs);
    vs.pop_back();
    print("删除尾节点后:", vs);
    vs.insert(vs.begin(),Student("王建立",45));
    print("在迭代器指向的位置添加节点后:", vs);
    vs.erase(++vs.begin());
    print("删除迭代器指向的节点后:", vs);

    typedef vector<Student>::iterator IT;
    IT fit = find(vs.begin(),vs.end(),Student("赵云",25));
    if(fit!=vs.end()){
        vs.erase(fit);
    }
    print("找到赵云并删除后:", vs);

//    sort(vs.begin(),vs.end());
    CMP<Student> cmp;
    sort(vs.begin(),vs.end(),cmp);
    print("排序后:", vs);

/*
    vector<int> vi;
    for(int i=0; i<10; i++)
        vi.push_back(10-i);
    print("添加节点后:", vi);
    vi.pop_back();
    print("删除尾节点后:", vi);
    typedef vector<int>::iterator IT;

    vi.insert(vi.begin(),1);
    print("在迭代器指向的位置添加节点后:", vi);

    vi.erase(--vi.end());
    print("删除迭代器指向的节点后:", vi);

    IT it = ++vi.begin();
    *it = -100;
    print("更改迭代器指向的节点后:", vi);

    IT fit = find(vi.begin(),vi.end(),5);//利用==实现比较查找
    if(fit!=vi.end())
        vi.erase(fit);
    print("找到元素5并删除后:", vi);

//    sort(vi.begin(),vi.end());//利用<实现排序
    CMP<int> cmp;
    sort(vi.begin(),vi.end(),cmp);//
    print("排序后:",vi);*/
    return 0;
}










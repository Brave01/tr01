#include <iostream>
#include <queue>
#include <list>
#include <deque>
#include <vector>
using namespace std;
int main(){
    queue<int> qi;
    qi.push(1);
    qi.push(2);
    qi.push(3);
    qi.push(4);
    qi.push(5);
    qi.push(6);
    while(!qi.empty()){
        cout << qi.front() << endl;
        qi.pop();
    }
    return 0;
}

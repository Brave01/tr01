#include <iostream>
#include <deque>
#include <algorithm>
using namespace std;
template<class T>void print(string const& str, deque<T>& d){
    typedef typename deque<T>::iterator IT;
    for( IT it=d.begin(); it!=d.end(); ++it )
        cout << *it << ' ';
    cout << endl << "------------------" << endl;
}
template<class T>class CMP{
public:
    bool operator()(T const& a, T const& b){
        return a > b;
    }
};
int main(){
    deque<int> di;
    for(int i=0; i<5; i++)
        di.push_back(10-i);
    for(int i=0; i<5; i++)
        di.push_front(100+i);
    print("添加节点后:", di);
    di.pop_back();
    di.pop_front();
    print("删除头尾节点后:", di);
    di.insert(di.begin(),3);
    print("在迭代器指向的位置添加节点后:", di);
    di.erase(di.begin());
    print("删除迭代器指向的节点后:", di);

    typedef deque<int>::iterator IT;
    IT it=++di.begin();
    *it = 500;
    print("更改迭代器指向的节点后:", di);

    IT fit = find(di.begin(),di.end(),101);
    if(fit!=di.end())
        di.erase(fit);
    print("找到元素101并删除后:", di);

//    sort(di.begin(),di.end());
    CMP<int> cmp;
    sort(di.begin(),di.end(),cmp);
    print("排序后:", di);
    return 0;
}












#include <iostream>
#include <stdarg.h>
using namespace std;

string StrCat(char const*str1, char const*str2,...){
    string str = str1;
    str += str2;
    va_list ap;
    va_start(ap,str2);
    char const* strX;
    while((strX=va_arg(ap,char const*))!="!!!"){
        str += strX;
    }
    va_end(ap);
    return str;
}

int main(){
    cout << StrCat("zhang", "ji", "wen", "!!!") << endl;
    return 0;
}

#include <iostream>
#include <queue>
#include <list>
#include <vector>
#include <deque>
using namespace std;
template<class T>class CMP{
public:
    bool operator()(T const& a, T const& b){
        return a > b;
    }
};
int main(){
    priority_queue<int,vector<int>,CMP<int> > pq;
    pq.push(3);
    pq.push(9);
    pq.push(2);
    pq.push(8);
    pq.push(4);
    pq.push(7);
    while(!pq.empty()){
        cout << pq.top() << endl;
        pq.pop();
    }
    return 0;
}

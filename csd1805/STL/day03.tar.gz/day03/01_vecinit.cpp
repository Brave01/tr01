#include <iostream>
#include <vector>
using namespace std;
void print(string const& str, vector<int>& v){
    cout << str << endl;
    cout << "向量大小:" << v.size() << endl;
    for(size_t i=0; i<v.size(); i++)
        cout << v[i] << ' ';
    cout << endl;
    cout << "向量容量:" << v.capacity() << endl;
    for(size_t i=0; i<v.capacity(); i++)
        cout << v[i] << ' ';
    cout << endl << "----------------" << endl;
}
int main(){
    vector<int> v1;//容量为0,大小为0
    print("v1:", v1);

    vector<int> v2(5);
    print("v2:", v2);

    vector<int> v3(5,10);
    print("v3:", v3);

    vector<int> vn;
    vn.resize(10);
//    vn.reserve(10);
    for(int i=0; i<10; i++)
        vn[i] = i+1;
    print("vn:", vn);
    vn.push_back(100);//数据增加1个,容量增加不止1个.
    print("vn:", vn);
    return 0; 
}








#include <iostream>
#include <stdexcept>
using namespace std;

template<class T>class list{
public:
//
//缺省构造
//
    list():m_head(NULL),m_tail(NULL){}
//
//拷贝构造
//
    list(list const& ls):m_head(NULL),m_tail(NULL){
        for(node*pnode=ls.m_head; pnode; pnode=pnode->m_next){
            push_back(pnode->m_data);
        }
    }
//
//析构函数
//
    ~list(){
        clear();
    }
//
//链表判空
//
    bool empty(){
        return m_head==NULL && m_tail==NULL;    
    }
//
//添加头节点
//
    void push_front(T const& data){
        m_head = new node(data,NULL,m_head);
        if(m_head->m_next)
            m_head->m_next->m_prev = m_head;
        else
            m_tail = m_head;
    }
//
//删除头节点
//
    void pop_front(){
        if(empty())
            return;
        node* pnode = m_head->m_next;
        delete(m_head);
        if(pnode)
            pnode->m_prev = NULL;
        else
            m_tail = NULL;
        m_head = pnode;
    }
//
//获取头节点数据
//
    T& front(){
        if(empty())
            throw underflow_error("front():null node");
        return m_head->m_data;
    }
    T const& front()const{
        return const_cast<list*>(this)->front();
    }
//
//添加尾节点
//
    void push_back(T const& data){
        m_tail = new node(data,m_tail,NULL);
        if(m_tail->m_prev)
            m_tail->m_prev->m_next = m_tail;
        else
            m_head = m_tail;
    }
//
//删除尾节点
//
    void pop_back(){
        if(empty())
            return;
        node* pnode = m_tail->m_prev;
        delete(m_tail);
        if(pnode)
            pnode->m_next = NULL;
        else
            m_head = NULL;
        m_tail = pnode;
    }
//
//获取尾节点数据
//
    T& back(){
        if(empty())
            throw underflow_error("back():null node");
        return m_tail->m_data;
    }
    T const& back()const{
        return const_cast<list*>(this)->back();
    }
//
//清空链表
//
    void clear(){
        while(!empty()){
            pop_front();
        }
    }
//
//获取链表大小(节点个数)
//
    size_t size(){
        size_t i = 0;
        for(node*pnode=m_head; pnode; pnode=pnode->m_next){
            ++i;
        }
        return i;
    }
//
//重载输出流运算符
//
    friend ostream& operator<<(ostream& os, list<T>& l){
        for(node*pnode=l.m_head; pnode; pnode=pnode->m_next){
            os << pnode->m_data << ' ';
        }
        return os;
    }
private:
//
//节点类
//
    class node{
    public:
        node(T const& data, node* prev=NULL, node* next=NULL):
                    m_data(data),m_prev(prev),m_next(next){}
        node* m_prev;
        node* m_next;
        T m_data;
    };
public:
//
//非常迭代类
//
    class iterator{
    public:
        iterator(node*start=NULL,node*end=NULL,node*cur=NULL):
                    m_start(start),m_end(end),m_cur(cur){}
        T& operator*(){
            if(m_cur==NULL)
                throw underflow_error("operator*()");
            return m_cur->m_data;
        }
        iterator& operator++(){
            if(m_cur==NULL)
                m_cur = m_start;
            else
                m_cur = m_cur->m_next;
            return *this;
        }
        iterator& operator--(){
            if(m_cur==NULL)
                m_cur = m_end;
            else
                m_cur = m_cur->m_prev;
            return *this;
        }
        bool operator==(iterator const& that)const{
            return m_cur == that.m_cur;
        }
        bool operator!=(iterator const& that)const{
            return !(*this==that);//m_cur != that.m_cur;
        }
    private:
        node* m_start;
        node* m_cur;
        node* m_end;
        friend class list;
    };
//
//获取起始迭代器(用于遍历)
//
    iterator begin(){
        return iterator(m_head,m_tail,m_head);
    }
//
//获取终止迭代器(用于结束标志)
//
    iterator end(){
        return iterator(m_head,m_tail);
    }
//
//在迭代器指向的位置添加节点
//
    iterator insert(iterator const& loc,T const& data){
        if(loc==end()){
            push_back(data);
            return iterator(m_head,m_tail,m_tail);
        }else{
            node* pnode=new node(data,loc.m_cur->m_prev,loc.m_cur);
            if(pnode->m_prev)
                pnode->m_prev->m_next = pnode;
            else
                m_head = pnode;
            pnode->m_next->m_prev = pnode;
            return iterator(m_head,m_tail,pnode);
        }
    }
//
//删除迭代器指向的节点
//
    iterator erase(iterator const& loc){
        if(loc==end())
            throw underflow_error("erase():null node");
        node* pdel = loc.m_cur;
        node* pnext = loc.m_cur->m_next;
        if(pdel->m_prev)
            pdel->m_prev->m_next = pdel->m_next;
        else
            m_head = pdel->m_next;
        if(pdel->m_next)
            pdel->m_next->m_prev = pdel->m_prev;
        else
            m_tail = pdel->m_prev;
        delete(pdel);    
        return iterator(m_head,m_tail,pnext);
    }
//
//常迭代类
//
    class const_iterator{
    public:
        const_iterator(iterator const& it):m_it(it){}
        T const& operator*(){
            return *m_it;
        }
        const_iterator& operator++(){
            ++m_it;
            return *this;
        }
        const_iterator& operator--(){
            --m_it;
            return *this;
        }
        bool operator==(const_iterator const& that)const{
            return m_it==that.m_it;
        }
        bool operator!=(const_iterator const& that)const{
            return !(*this==that);//m_it!=that.m_it;
        }
    private:
        iterator m_it;
    };
//
//获取起始常迭代器
//
    const_iterator begin()const{
        return iterator(m_head,m_tail,m_head);
    }
//
//获取终止常迭代器
//
    const_iterator end()const{
        return iterator(m_head,m_tail);
    }
    node* m_head;
    node* m_tail;
};
//
//利用"=="实现比较查找
//
template<class IT,class T>IT find(IT begin, IT end, T const& data){
    for( IT it=begin; it!=end; ++it ){
        if( *it==data ){
            return it;
        }
    }
    return end;
}
//
//利用"<"实现排序
//
template<class IT>void sort(IT begin, IT end){
    IT p = begin;
    IT last = end;
    --last;
    for(IT i=begin,j=last;i!=j;){
        while(i!=p && *i<*p){
            ++i;
        }
        if(i!=p){
            swap(*i,*p);
            p = i;
        }
        while(j!=p && *p<*j){
            --j;
        }
        if(j!=p){
            swap(*p,*j);
            p = j;
        }
    }
    IT it=begin;
    ++it;
    if(p!=begin && p!=it){
        sort(begin,p);
    }
    it = p;
    ++it;
    if(it!=end && it!=last){
        sort(it,end);
    }
}
//
//利用"比较器"实现排序
//
template<class IT,class CMP>void sort(IT begin, IT end,CMP cmp){
    IT p = begin;  
    IT last = end;
    --last;
    for(IT i=begin,j=last;i!=j;){
        while(i!=p && cmp(*i,*p)){//*i<*p
            ++i;
        }
        if(i!=p){
            swap(*i,*p);
            p = i;
        }
        while(j!=p && cmp(*p,*j)){//*p<*j
            --j;
        }
        if(j!=p){
            swap(*p,*j);
            p = j;
        }
    }
    IT it=begin;
    ++it;
    if(p!=begin && p!=it){
        sort(begin,p,cmp);
    }
    it = p;
    ++it;
    if(it!=end && it!=last){
        sort(it,end,cmp);
    }
}
//模拟STL库
//------------------------------------------
//模拟傻瓜用户
void print(string const& str, list<int>& l){
    cout << str << endl;
    typedef list<int>::iterator IT;
    for(IT it=l.begin(); it!=l.end(); ++it){
       cout << *it << ' ';//利用迭代器实现 遍历查找 操作
    }
    cout << endl << "------------------" << endl;
}
//
//比较类
//
class CMP{
public:
    bool operator()(int const& a, int const& b){
        return a < b;
    }
};
int main(){
    list<int> ls;
    for(int i=0; i<5; i++)
        ls.push_front(10+i);
    for(int i=0; i<5; i++)
        ls.push_back(100-i);
    print("添加节点后:", ls);
    ls.pop_front();
    ls.pop_back();
    print("删除头尾节点后:", ls);

    ls.insert(++ls.begin(),100);//利用迭代器实现 增 操作
    print("在迭代器指向的位置添加节点后:", ls);
    
    ls.erase(++ls.begin());//利用迭代器实现 删 操作
    print("删除迭代器指向的节点后:", ls);
    
    typedef list<int>::iterator IT;
    IT it=ls.begin();
    *it = 300;//利用迭代器实现 改 操作
    print("更改迭代器指向的节点后:", ls);

    IT fit = find(ls.begin(),ls.end(),100);
    if(fit!=ls.end()){
        ls.erase(fit);
    }
    print("找到元素100并删除后:", ls);

//  sort(ls.begin(),ls.end());
    CMP cmp;
    sort(ls.begin(),ls.end(),cmp);
    print("排序后:", ls);

/*    
    list<int> const cls = ls;
    typedef list<int>::const_iterator CIT;
    for(CIT cit=cls.begin(); cit!=cls.end(); ++cit)
        cout << *cit << ' ';
    cout << endl << "--------------" << endl;

    CIT cit = cls.begin();
//    *cit = 500;//不能通过常迭代器更改链表数据*/
    return 0;
}












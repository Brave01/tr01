#include <iostream>
#include <regex.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
using namespace std;
int main(int argc, char* argv[]){
    if(argc<2){
        cout << "a.out用法:[文件名]" << endl;
        return -1;
    }
    string strPath = "./";
    strPath += argv[1];
    FILE* pFile = fopen(strPath.c_str(),"r");
    fseek(pFile,0,SEEK_END);
    long nlen = ftell(pFile);
    char* buf = (char*)malloc(nlen+1);
    fseek(pFile,0,SEEK_SET);
    fread(buf,1,nlen,pFile);
    buf[nlen]='\0';
    fclose(pFile);
    regex_t ex;//正则表达式
    regcomp(&ex,"href=\"\\s*\\([^ >]*\\)\\s*\"",0);

    char* html = buf;
    regmatch_t match[2];
    while( regexec(&ex,html,2,match,0)!=REG_NOMATCH ){
        html += match[1].rm_so;
        int len = match[1].rm_eo - match[1].rm_so;
        char* url = (char*)malloc(len+1);
        memcpy(url,html,len);
        url[len]='\0';
        cout << url << endl;
        free(url);
        html += len + match[0].rm_eo - match[1].rm_eo;
    }
    free(buf);
    regfree(&ex);
    return 0;
}











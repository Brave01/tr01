#include <iostream>
#include <netdb.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
using namespace std;

int main(int argc, char* argv[]){
    if(argc<2){
        cout << "a.out用法:[域名]" << endl;
        return -1;
    }
    hostent* svr = gethostbyname(argv[1]);
    cout << "官方主机名:" << svr->h_name << endl;
    int i=0;
    while(svr->h_aliases[i]!=NULL){
        cout << "主机别名:" << svr->h_aliases[i++] << endl;
    }
    i=0;
    while(svr->h_addr_list[i]!=NULL){
        in_addr* nip = (in_addr*)svr->h_addr_list[i++];
        cout << "IP地址:" << inet_ntoa(*nip) << endl;
    }
    return 0;
}







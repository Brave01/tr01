#include <iostream>
#include <string.h>
using namespace std;

int main(){
    char buf[] = "zhangjiwen@tedu.cn";//待拆串
    char delim[] = "@.";//拆分规则串
    for(char*token=strtok(buf,delim);token;token=strtok(NULL,delim))
    {
        cout << token << endl;
    }
/*
    cout << buf << endl;

    char* pz = strtok(buf,delim);
    cout << pz << endl;

    char* pt = strtok(NULL,delim);
    cout << pt << endl;

    char* pc = strtok(NULL,delim);
    cout << pc << endl;

    char* pn = strtok(NULL,delim);
    if(pn==NULL)
        cout << "NULL" << endl;

    cout << buf << endl;*/
    return 0;
}





#include <iostream>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <unistd.h>
using namespace std;
int main(int argc, char* argv[]){
    if(argc<2){
        cout << "a.out用法:[IP地址]" << endl;
        return -1;
    }
    int sockfd = socket(AF_INET,SOCK_STREAM,0);
    sockaddr_in addrS;
    addrS.sin_family = AF_INET;
    addrS.sin_port = htons(80);
    addrS.sin_addr.s_addr = inet_addr(argv[1]);//inet_aton(.,.)
    connect(sockfd,(sockaddr*)&addrS,sizeof(addrS));
    string strRequest = "GET / HTTP/1.0\r\n"
                        "HOST:www.tmooc.cn\r\n"
                        "Accept:*/*\r\n"
                        "Connection:Close\r\n"
                        "User-Agent:Mozilla/5.0\r\n"
                        "Referer:www.tmooc.cn\r\n\r\n";
    send(sockfd,strRequest.c_str(),strRequest.size(),0);
    for(;;){
        char buf[1024]={ 0 };
        int len = recv(sockfd,buf,1023,0);
        if(len==-1)
            return -1;
        if(len==0)
            break;
        cout << buf << flush;
    }
    close(sockfd);
    return 0;
}












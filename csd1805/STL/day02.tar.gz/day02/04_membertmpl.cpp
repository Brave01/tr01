#include <iostream>
using namespace std;

template<class T>class Arrary{
public:
    T& operator[](size_t i){
        return m_arr[i];
    }
private:
    T m_arr[10];
};
template<class D, template<class E>class C>class Sum{
public:
    Sum(C<D> const& s):m_s(s){}
    D add(){
        D d = D();
        for(int i=0; i<10; i++)
            d += m_s[i];
        return d;
    }
private:
    C<D> m_s;//Arrary<D> m_s;
};
int main(){
    Arrary<int> a;
    for(int i=0; i<10; i++)
        a[i] = i+1;
    Sum<int, Arrary> s(a);
    cout << s.add() << endl;
    return 0;
}








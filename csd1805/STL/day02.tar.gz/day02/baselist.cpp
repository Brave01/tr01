#include <iostream>
#include <stdexcept>
using namespace std;

template<class T>class list{
public:
//
//缺省构造
//
    list():m_head(NULL),m_tail(NULL){}
//
//拷贝构造
//
    list(list const& ls):m_head(NULL),m_tail(NULL){
        for(node*pnode=ls.m_head; pnode; pnode=pnode->m_next){
            push_back(pnode->m_data);
        }
    }
//
//析构函数
//
    ~list(){
        clear();
    }
//
//链表判空
//
    bool empty(){
        return m_head==NULL && m_tail==NULL;    
    }
//
//添加头节点
//
    void push_front(T const& data){
        m_head = new node(data,NULL,m_head);
        if(m_head->m_next)
            m_head->m_next->m_prev = m_head;
        else
            m_tail = m_head;
    }
//
//删除头节点
//
    void pop_front(){
        if(empty())
            return;
        node* pnode = m_head->m_next;
        delete(m_head);
        if(pnode)
            pnode->m_prev = NULL;
        else
            m_tail = NULL;
        m_head = pnode;
    }
//
//获取头节点数据
//
    T& front(){
        if(empty())
            throw underflow_error("front():null node");
        return m_head->m_data;
    }
    T const& front()const{
        return const_cast<list*>(this)->front();
    }
//
//添加尾节点
//
    void push_back(T const& data){
        m_tail = new node(data,m_tail,NULL);
        if(m_tail->m_prev)
            m_tail->m_prev->m_next = m_tail;
        else
            m_head = m_tail;
    }
//
//删除尾节点
//
    void pop_back(){
        if(empty())
            return;
        node* pnode = m_tail->m_prev;
        delete(m_tail);
        if(pnode)
            pnode->m_next = NULL;
        else
            m_head = NULL;
        m_tail = pnode;
    }
//
//获取尾节点数据
//
    T& back(){
        if(empty())
            throw underflow_error("back():null node");
        return m_tail->m_data;
    }
    T const& back()const{
        return const_cast<list*>(this)->back();
    }
//
//清空链表
//
    void clear(){
        while(!empty()){
            pop_front();
        }
    }
//
//获取链表大小(节点个数)
//
    size_t size(){
        size_t i = 0;
        for(node*pnode=m_head; pnode; pnode=pnode->m_next){
            ++i;
        }
        return i;
    }
//
//重载输出流运算符
//
    friend ostream& operator<<(ostream& os, list<T>& l){
        for(node*pnode=l.m_head; pnode; pnode=pnode->m_next){
            os << pnode->m_data << ' ';
        }
        return os;
    }
private:
//
//节点类
//
    class node{
    public:
        node(T const& data, node* prev=NULL, node* next=NULL):
                    m_data(data),m_prev(prev),m_next(next){}
        node* m_prev;
        node* m_next;
        T m_data;
    };
    node* m_head;
    node* m_tail;
};

int main(){
    list<int> ls;
    for(int i=0; i<5; i++)
        ls.push_front(10+i);
    for(int i=0; i<5; i++)
        ls.push_back(100-i);
    cout << "添加节点后:" << ls << endl;
    ls.pop_front();
    ls.pop_back();
    cout << "删除头尾节点后:" << ls << endl;
    return 0;
}












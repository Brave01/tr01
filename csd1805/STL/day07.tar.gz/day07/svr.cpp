#include <iostream>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
using namespace std;

int main(int argc, char* argv[]){//通过命令行传端口号
    if(argc<2){
        cout << "a.out用法:[端口号]" << endl;
        return -1;
    }
    int socklisten = socket(AF_INET,SOCK_STREAM,0);
    sockaddr_in addrS;
    addrS.sin_family = AF_INET;
    addrS.sin_port = htons(atoi(argv[1]));
    addrS.sin_addr.s_addr = inet_addr("127.0.0.1");
    bind(socklisten,(sockaddr*)&addrS,sizeof(addrS));
    listen(socklisten,5);
    while(1){
        sockaddr_in addrC;
        size_t len = sizeof(addrC);
        int sockfd = accept(socklisten,(sockaddr*)&addrC,&len);
        char buf[1024] = { 0 };
        recv(sockfd,buf,1023,0);
        cout << "收到客户端发来的请求:" << buf
             << "但我服务器很忙稍后给予响应" << endl;
        sleep(20);
        char buff[] = "hello client";
        send(sockfd,buff,strlen(buff),0);
        close(sockfd);
    }
    close(socklisten);
    return 0;
}











#include <iostream>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/epoll.h>
using namespace std;
void* recvThread(void* arg){
    cout << "线程:" << pthread_self()<<"苦苦等待服务器响应"<<endl;
    int sockfd = (int)arg;
    char buff[1024] = { 0 };
    recv(sockfd,buff,1023,0);
    cout << "线程:" << pthread_self() << "收到服务器发回的响应:"
         << buff << endl;
    close(sockfd);
    cout << "线程:" << pthread_self() << "结束" << endl;
}
int epoll;//接收epoll对象描述符
void* multiThread(void* arg){
    for(;;){
        epoll_event ff[10];
        int fds = epoll_wait(epoll,ff,10,-1);
        for(int i=0; i<fds; i++){
            if(ff[i].events==EPOLLIN || ff[i].events==EPOLLET){
                pthread_t m_tid;
                pthread_create(&m_tid,
                        NULL,recvThread,ff[i].data.ptr);
            }
            epoll_ctl(epoll,EPOLL_CTL_DEL,ff[i].data.fd,NULL);
        }
    }
}
int main(){
    epoll = epoll_create1(0);//创建一个epoll内核对象
    pthread_t m_tid;
    pthread_create(&m_tid,NULL,multiThread,NULL);

    for(int i=0; i<3; i++){
        int sockfd = socket(AF_INET,SOCK_STREAM,0);
        sockaddr_in addrS;
        addrS.sin_family = AF_INET;
        addrS.sin_port = htons(8000+i);
        addrS.sin_addr.s_addr = inet_addr("127.0.0.1");
        connect(sockfd,(sockaddr*)&addrS,sizeof(addrS));
        char buf[] = "hello server";
        send(sockfd,buf,strlen(buf),0);
        epoll_event f;
        f.events = EPOLLIN | EPOLLET;
        f.data.fd = sockfd;
        epoll_ctl(epoll,EPOLL_CTL_ADD,sockfd,&f);

/*
//并发模式
        pthread_t m_tid;
        pthread_create(&m_tid,NULL,recvThread,(void*)sockfd);*/

/*
//应答模式
        char buff[1024] = { 0 };
        recv(sockfd,buff,1023,0);
        cout << "收到服务器发回的响应:" << buff << endl;
        close(sockfd);*/
    }
    getchar();
    return 0;
}








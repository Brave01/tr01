#ifndef _PLUGIN_H
#define _PLUGIN_H
class webcrawler;
class plugin{
public:
    virtual void init(webcrawler* app) = 0;
    virtual void handle(void*arg) = 0;
};

#endif

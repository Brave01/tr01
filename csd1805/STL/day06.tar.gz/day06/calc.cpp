#include "plugin.h"
#include "webcrawler.h"
#include <iostream>
using namespace std;
class calc : public plugin{
public:
    void init(webcrawler*app){
        app->m_pluginMngr.registI(this);
    }
    void handle(void*arg){
        string* pstr = (string*)arg;
        cout << pstr->size() << endl;
    }
};

calc g_calc;

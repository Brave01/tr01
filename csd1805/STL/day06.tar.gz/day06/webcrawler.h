#ifndef _WEBCRAWLER_H
#define _WEBCRAWLER_H
#include "pluginMngr.h"
#include <dlfcn.h>
#include <fstream>
#include "plugin.h"
extern webcrawler* g_app;
class webcrawler{
public:
    void load(){
        ifstream ifs("./webcrawler.cfg");
        string line;
        while(getline(ifs,line)!=0){
            string strPath = "./";
            strPath += line;// ./print  ./calc
            strPath += ".so"; // ./print.so  ./calc.so
            void* handle = dlopen(strPath.c_str(),RTLD_NOW);
            string strVar = "g_";
            strVar += line;  // g_print  g_calc
            plugin* p = (plugin*)dlsym(handle,strVar.c_str());
            p->init(g_app);
        }
    }
    pluginMngr m_pluginMngr;
};

#endif

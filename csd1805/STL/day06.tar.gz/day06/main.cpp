#include "webcrawler.h"
#include <iostream>
using namespace std;
webcrawler* g_app = new webcrawler;

int main(){
    g_app->load();

    string str = "hello world";
    g_app->m_pluginMngr.invokeS(&str);
    cout << "----------------------" << endl;
    g_app->m_pluginMngr.invokeI(&str);
    return 0;
}

#ifndef _PLUGINMNGR_H
#define _PLUGINMNGR_H
#include <vector>
#include "plugin.h"
using namespace std;
class pluginMngr{
public:
    void registS(plugin* p){
        vs.push_back(p);
    }
    void registI(plugin* p){
        vi.push_back(p);
    }
    void invokeS(void* arg){
        typedef vector<plugin*>::iterator IT;
        for(IT it=vs.begin();it!=vs.end();++it){
            (*it)->handle(arg);
        }
    }
    void invokeI(void* arg){
        typedef vector<plugin*>::iterator IT;
        for( IT it=vi.begin(); it!=vi.end(); ++it )
        {
            (*it)->handle(arg);
        }
    }
private:
    vector<plugin*> vs;
    vector<plugin*> vi;
};

#endif

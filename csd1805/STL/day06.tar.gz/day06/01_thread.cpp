#include <iostream>
#include <pthread.h>
#include <stdio.h>
#include <unistd.h>
using namespace std;
class Thread{
public:
    void start(){
        pthread_create(&m_tid,NULL,run,this);
    }
    static void* run(void*arg){
        Thread* p = (Thread*)arg;
        p->run();//虚函数
    }
    virtual void run() = 0;
private:
    pthread_t m_tid;
};
class MyThread : public Thread{
public:
    MyThread(char ch, int sec):m_ch(ch),m_sec(sec){}
    virtual void run(){
        for(;;){
            usleep(1000*m_sec);
            cout << m_ch << flush;
        }
    }
private:
    char m_ch;
    int m_sec;
};
int main(){
    MyThread t1('+',500), t2('-',100);
    t1.start();
    t2.start();
    getchar();
    return 0;
}







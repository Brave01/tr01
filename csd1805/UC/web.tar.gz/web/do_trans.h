#ifndef DO_TRANS_H_
#define DO_TRANS_H_
#include <unistd.h>
#include <string.h>
#include <stdio.h>
//定义请求信息类型
typedef struct request{
    char method[16];
    char path[128];
    char proto[16];
}req_t;

//业务处理
void do_it(int connfd);

#endif 

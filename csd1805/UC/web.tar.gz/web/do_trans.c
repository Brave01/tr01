#include "do_trans.h"
#include <ctype.h>
#include <string.h>

char *work_dir="/home/tarena/uc/web/html";

void get_request(int fd,req_t *req){
    char path[128];
    char buf[1024];
    int r=read(fd,buf,1024);
    sscanf(buf,"%s %s %s\r\n",req->method,req->path,req->proto);
    
    //请求文件到映射文件的路径处理
    if(strcmp(req->path,"/")==0)strcpy(req->path,"/index.html");
    strcpy(path,work_dir);
    strcat(path,req->path);
    strcpy(req->path,path);

    return;
}
void do_it(int fd){
    req_t rq;
    //获取浏览器的请求信息
    get_request(fd,&rq);//函数执行完毕,将请求信息填到rq变量的空间中,返回
    printf("method:%s\tpath:%s\tprotocol:%s\n",\
            rq.method,rq.path,rq.proto);
    //根据浏览器的请求信息,查找相应的请求文件
    //生成回应信息

    //根据回应信息回应浏览器

    return;
}

#include "do_trans.h"
#include <ctype.h>
#include <string.h>

char *work_dir="/home/tarena/uc/web/html";

//获取浏览器的请求信息
static void get_request(int fd,req_t *req){
    char path[128];
    char buf[1024];
    int r=read(fd,buf,1024);
    sscanf(buf,"%s %s %s\r\n",req->method,req->path,req->proto);
    
    //请求文件到映射文件的路径处理
    if(strcmp(req->path,"/")==0)strcpy(req->path,"/index.html");
    strcpy(path,work_dir);
    strcat(path,req->path);
    strcpy(req->path,path);

    return;
}

static char *get_file_type(const char *file){
    if(strcmp(strrchr(file,'.'),".jpg")==0)return  "image/jpg";
    if(strcmp(strrchr(file,'.'),".png")==0)return  "image/png";
    return "text/html";
}

//处理请求信息,获取响应信息
/*
 *协议的版本
 *状态码   200 404
 *文件的类型  text/html  image/jpg  image/jpn
**/
static void org_response(res_t *res){
    res->s_code=access(res->req->path,R_OK)?404:200;
    res->f_type=get_file_type(res->req->path);
    return;
}

void response_b_200(int fd,res_t *res){
    char f_line[128];
    char cont[128];

    sprintf(f_line,"%s %d \r\n",\
            res->req->proto,res->s_code);
    sprintf(cont,"Content-Type: %s\r\n\r\n",res->f_type);
    write(fd,f_line,strlen(f_line));
    write(fd,cont,strlen(cont));
    dup2(fd,1);
    execlp("cat","cat",res->req->path,NULL);
    perror("execlp");
}
void response_b_404(int fd,res_t *res){
    char f_line[128];
    char cont[128];
    char *err_msg="<html><body><h1> file not found...\n</body></html>";

    sprintf(f_line,"%s %d \r\n",\
            res->req->proto,res->s_code);
    strcpy(cont,"Content-Type: text/html\r\n\r\n");
    write(fd,f_line,strlen(f_line));
    write(fd,cont,strlen(cont));
    write(fd,err_msg,strlen(err_msg));
    
}


static void response_b(int fd,res_t *res){
    if(res->s_code==200)
        response_b_200(fd,res);
    if(res->s_code==404)
        response_b_404(fd,res);
    return;
}
void do_it(int fd){
    req_t rq;
    res_t rs;
    //获取浏览器的请求信息
    get_request(fd,&rq);//函数执行完毕,将请求信息填到rq变量的空间中,返回
    printf("method:%s\tpath:%s\tprotocol:%s\n",\
            rq.method,rq.path,rq.proto);
    rs.req=&rq;
    //根据浏览器的请求信息,查找相应的请求文件
    //生成回应信息
    org_response(&rs);
    printf("file:%s\n file_type:%s\t code:%d\n",\
            rs.req->path,rs.f_type,rs.s_code);
    //根据回应信息回应浏览器
    response_b(fd,&rs);
    return;
}

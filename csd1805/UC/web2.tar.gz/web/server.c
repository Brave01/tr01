#include <stdio.h>
#include "t_net.h"
#include "do_trans.h"
#include <stdlib.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
//子进程结束,收尸
void handle(int n){
    waitpid(-1,NULL,WNOHANG);
    return;
}

int main(void){
    SA4 clie;
    socklen_t cli_len;
    signal(SIGCHLD,handle);
    char IP[128];
    int sfd=s_bind(AF_INET,SOCK_STREAM,7007);
    if(sfd==-1){ return -1;}
    listen(sfd,5);
    while(1){
        cli_len=sizeof(clie);
        int cfd=accept(sfd,(SA *)&clie,&cli_len);
        if(cfd==-1){perror("accept");return -1;}
        printf("%s\n",\
            inet_ntop(AF_INET,&clie.sin_addr,IP,128));
        pid_t pid=fork();
        if(pid==-1){ perror("fork");return -1;}
        if(pid==0){
            close(sfd);
            do_it(cfd);
            close(cfd);
            exit(0);
        }else{
            close(cfd);
        }

    }
    return 0;
}

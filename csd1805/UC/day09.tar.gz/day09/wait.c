#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdlib.h>

int main(void){
    int s;
    //创建子进程
    pid_t pid=fork();
    if(pid==-1){
        perror("fork");
        return -1;
    }
    if(pid==0){
        printf("child process...%d\n",getpid());
        getchar();
        exit(-1);
    }else{
        wait(&s);//阻塞，等待子进程的结束
        printf("parent process...\n");
        if(WIFEXITED(s))//返回真说明子进程正常终止
            printf("exit code...%d\n",WEXITSTATUS(s));
        if(WIFSIGNALED(s))//返回真，说明子进程被信号打断
            printf("signum:%d\n",WTERMSIG(s));

    }
    return 0;
}

#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>

int main(void){
    char *ps_argv[]={"ps","-o","pid,ppid,pgrp,comm",NULL};
    //创建子进程
    pid_t pid=fork();
    if(pid==-1){
        perror("fork");
        return -1;
    }
    if(pid==0){//子进程执行的代码
        //使用ps程序的映像替换掉从父进程继承的映像
        //execlp("ps","ps","-o","pid,ppid,pgrp,comm",NULL);
        //execl("/bin/ps","ps","-o","pid,ppid,pgrp,comm",NULL);
        execvp("ps",ps_argv);
        //如果execlp执行成功,一下的代码不执行
        perror("execlp");
        exit(0);
    }else{//父进程执行的代码
        wait(NULL);
    }
    return 0;
}

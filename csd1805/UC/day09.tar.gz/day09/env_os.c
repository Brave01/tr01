#include <stdio.h>
#include <stdlib.h>
int main(void){
#if 0
    char *p=getenv("caption");
    if(p==NULL){
        printf("no match...!\n");
        return -1;
    }
    printf("%s-----------\n",p);
#endif
    //使用setenv改变环境变量的值.
    setenv("caption","beijing",1);
    char *p=getenv("caption");
    if(p==NULL){
        printf("no match...!\n");
        return -1;
    }
    printf("%s--------after\n",p);
    //删除当前环境变量的值
    unsetenv("USER");
    p=getenv("USER");
    if(p==NULL)
        printf("delete USER success...\n");

    return 0;
}

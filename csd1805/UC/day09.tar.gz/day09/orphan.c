#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdlib.h>

int main(void){
    int s;
    //创建子进程
    pid_t pid=fork();
    if(pid==-1){
        perror("fork");
        return -1;
    }
    if(pid==0){
        printf("child process...%d\n",getpid());
        printf("parent process...%d\n",getppid());
        getchar();
        printf("parent process...%d\n",getppid());
    
        exit(-1);
    }else{        
        sleep(1);
    }
    return 0;
}

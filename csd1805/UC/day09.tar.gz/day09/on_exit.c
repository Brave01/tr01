#include <stdlib.h>
#include <stdio.h>
//遗言函数
void doit(int n,void *arg){
    printf("n=%d\targ=%s\n",n,(char *)arg);
    return;
}
int main(void){
    //向进程注册遗言函数
    on_exit(doit,"kkkk");
    getchar();
    exit(-1);
}

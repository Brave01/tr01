#include <stdio.h>

int main(void){
    int var_i=300;
    int *p;//悬空指针
    printf("p=%p\n",p);
    //p=(unsigned int *)0x30000000;
    *p=200;
    printf("hehehe...\n");
    printf("var_i=%d\n",*p);
    //printf("p=%p\n",p);
    return 0;
}

#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <string.h>

int main(void){
    //获取当前进程的pid
    printf("pid:%d\n",getpid());
    char *str1="hello beijing";
    char *str2="hello beijing";
    char buf[]="hello beijing";//在栈段分配了内存空间，然后将代码段中的字符串拷贝到了栈段的内存空间
    char buf1[24];//数组的名字是常量
    //buf1="hello beijing";//error buf1是常量
    strcpy(buf1,"hello beijing");


    //str1的内容和str2的内容是否相同？

    printf("str2 content %p\n",str2);
    //str1的内容在哪里？
    printf("str1 content %p\n",str1);
    //str1的空间分配在哪里？
    printf("str1 address %p\n",&str1); 
    printf("str2 address %p\n",&str2); 
    printf("buf[] address:%p\n",buf);
    printf("buf:%s\n",buf);
    getchar();// 等待任意键结束进程

    return 0;
}

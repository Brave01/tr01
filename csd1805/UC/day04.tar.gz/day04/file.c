#include <stdio.h>
//#include <errno.h>
//#include <string.h>

int main(int argc,char *argv[]){
    //打开文件
    FILE *fp=fopen(argv[1],"r");
    if(fp==NULL){
        //printf("fopen failed...%d\n",errno);
        //errno=-1;
        //printf("%s\n",strerror(errno));
        perror("fopen");
        return -1;
    }
    printf("fopen %s success...\n",argv[1]);
    //关闭文件
    fclose(fp);
    return -1;
}

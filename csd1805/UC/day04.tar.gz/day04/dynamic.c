#include <stdio.h>
#include <dlfcn.h>
typedef int (*f_t)(int,int);
int main(int argc,char *argv[]){
    //打开共享库文件，返回handle。handle指向了动态库加载到内存的位置
    void *handle=dlopen(argv[1],RTLD_NOW);
    if(handle==NULL){
        //只是知道了错误，但不知到错误的原因，找不到错误的根源
        //printf("dlopen error...\n");
        //如何找到错误的原因？
        printf("%s\n",dlerror());
        return -1;
    }
    printf("dlopen success...\n");
    //需要在动态库中找函数的入口地址
    //获取k_sub函数的入口地址
    void *f=dlsym(handle,"k_sub");
    if(f==NULL){//dlsym调用失败
        printf("%s\n",dlerror());
        return -1;
    }
    f_t q=(f_t)f;
    printf("6-2=%d\n",q(6,2));
    //关闭共享库
    dlclose(handle);
    return 0;
}

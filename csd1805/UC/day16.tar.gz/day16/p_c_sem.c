#include <stdio.h>
#include <semaphore.h>
#include <pthread.h>
#include <time.h>
#include <unistd.h>
#include <stdlib.h>

//定义环状队列类型
#define Q_MAX 7
typedef int queue_t[Q_MAX];
queue_t que;//定义一个环状队列
sem_t p,c;//可生产的数量和可消费的数量

//生产者线程
void *product(void *arg){
    int rear=0;
    while(1){
        sem_wait(&p);//p--
        que[rear]=rand()%1000+1;
        printf("p:%d\n",que[rear]);
        rear=(rear+1)%Q_MAX;
        sem_post(&c);
        sleep(rand()%5+1);
    }
}

//消费者线程
void *consume(void *arg){
    int front=0;
    int tmp;
    while(1){
        sem_wait(&c);//c--
        tmp=que[front];
        que[front]=-1;
        printf("c:%d\n",tmp);
        front=(front+1)%Q_MAX;
        sem_post(&p);//p++
        sleep(rand()%5+1);
    
    }
}

int main(void){
    srand(time(NULL));
    //初始化信号量p c
    sem_init(&p,0,Q_MAX);
    sem_init(&c,0,0);

    //创建两个线程分别用于生产者和消费者
    pthread_t pid,cid;
    pthread_create(&pid,NULL,product,NULL);
    pthread_create(&cid,NULL,consume,NULL);
    //阻塞等待两个线程的汇合
    pthread_join(pid,NULL);
    pthread_join(cid,NULL);
    //销毁信号量
    sem_destroy(&p);
    sem_destroy(&c);
    return 0;
}

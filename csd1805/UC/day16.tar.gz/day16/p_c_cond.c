#include <stdio.h>
#include <pthread.h>
#include <time.h>
#include <stdlib.h>
#include <unistd.h>

struct node;
typedef struct node node_t;
typedef node_t *list_t;
//定义链表相关类型
struct node {
    int data;
    node_t *next;
};

list_t head=NULL;//指向链表的头指针
//静态初始化mutex锁
pthread_mutex_t mutex=PTHREAD_MUTEX_INITIALIZER;
//静态初始化一个条件变量
pthread_cond_t cond = PTHREAD_COND_INITIALIZER;
//生产者线程
void *product(void *arg){
    node_t *new;
    while(1){

        //生产一个新的节点
        new=(list_t)malloc(sizeof(node_t));
        new->data=rand()%1000+1;
        new->next=NULL;
        printf("p:%d\n",new->data);
        //加锁
        pthread_mutex_lock(&mutex);
        //将新节点插入到链表的头部
        new->next=head;
        head=new;
        //解锁
        pthread_mutex_unlock(&mutex);
        pthread_cond_signal(&cond);
        sleep(rand()%5+1);
    }
}

//消费者线程
void *consume(void *arg){
    list_t tmp;
    while(1){
        //加锁
        pthread_mutex_lock(&mutex);
        if(head==NULL){
            //阻塞等待生产者生产//解锁 等待 重新获取锁
            pthread_cond_wait(&cond,&mutex);
        }
        
        tmp=head;
        head=head->next;
        //解锁
        pthread_mutex_unlock(&mutex);
        //消费tmp
        printf("c:%d\n",tmp->data);
        free(tmp);
        tmp=NULL;
    
        sleep(rand()%5+1);
    }
}
int main(void){
    srand(time(NULL));
    pthread_t pid,cid;
    //创建两个线程 pid 生产者,cid消费者;
    pthread_create(&pid,NULL,product,NULL);
    pthread_create(&cid,NULL,consume,NULL);
    
    //阻塞等待线程汇合
    pthread_join(pid,NULL);
    pthread_join(cid,NULL);
    //销毁mutex锁
    pthread_mutex_destroy(&mutex);
    //销毁条件变量
    pthread_cond_destroy(&cond);
    return 0;
}

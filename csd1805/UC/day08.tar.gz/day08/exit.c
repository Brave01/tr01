#include <stdlib.h>
int main(void){
    while(1);
    exit(-1);
}

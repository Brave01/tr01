#include <stdio.h>
#include <unistd.h>
int main(void){
    //创建一个子进程
    pid_t pid;
    pid=fork();
    if(pid==-1){
        perror("fork");
        return -1;
    }
    if(pid==0){//子进程执行的代码
        sleep(1);
        printf("child\n");
    }else{//父进程执行的代码
        sleep(3);
        printf("parent\n");
    }
    return 0;
}

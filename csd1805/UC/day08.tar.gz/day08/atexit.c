#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

//遗言函数
void doit(void){
    printf("I die...\n");
    return;
}
void doitu(void){
    printf("U die...\n");
    return;
}

int main(void){
    //向进程注册遗言函数
    atexit(doit);
    atexit(doit);
    atexit(doit);
    atexit(doit);
    atexit(doitu);
    pid_t pid=fork();
    if(pid==-1){perror("fork");return -1;}
    if(pid==0){
    }else{
        getchar();
    }
    return 0;
}

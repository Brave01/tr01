#include <stdio.h>
#include <t_file.h>

int main(int argc,char *argv[]){
    struct flock lock;
    //打开文件，以只读的方式
    int fd=open(argv[1],O_WRONLY);
    if(fd==-1){
        perror("open");
        return -1;
    }
    //对lock变量的成员进行初始化
    lock.l_type=F_WRLCK;//读锁
    lock.l_whence=SEEK_SET;
    lock.l_start=0;
    lock.l_len=6;
    //对文件描述符加读锁
    int fc=fcntl(fd,F_SETLKW,&lock);
    if(fc==-1){
        perror("fcntl");
        return -1;
    }
    //已经加上读锁了
    printf("add WRITE lock success...\n");
    getchar();
    //关闭文件描述符,跟描述符相关的所有的记录锁就移除了
    close(fd);
    return 0;
}

#include <stdio.h>
#include <pthread.h>

int val=0;//临界资源   数据段 10000
//3条指令
//锁是全局变量还是局部变量?
pthread_mutex_t mutex=PTHREAD_MUTEX_INITIALIZER;

//线程执行函数
void *count(void *arg){
    int i;//i是局部变量,在函数的栈帧里
    //加锁的位置和解锁的位置
    for(int j=0;j<5000;j++){
        pthread_mutex_lock(&mutex);
        i=val;
        i++;
        printf("i=%d\t tid:%lu\n",i,pthread_self());
        val=i;
        pthread_mutex_unlock(&mutex);
    }
    return NULL;
}
int main(void){
    //创建两个线程tidA,tidB
    pthread_t tidA,tidB;
    pthread_create(&tidA,NULL,count,NULL);
    pthread_create(&tidB,NULL,count,NULL);
    //阻塞等待线程的汇合
    pthread_join(tidA,NULL);
    pthread_join(tidB,NULL);
    //销毁mutex锁
    pthread_mutex_destroy(&mutex);
    return 0;
}

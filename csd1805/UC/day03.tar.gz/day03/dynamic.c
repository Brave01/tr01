#include <stdio.h>
#include <dlfcn.h>

int main(void){
    //打开共享库文件
    void *handle=dlopen("libtath.so",RTLD_NOW);
    if(handle==NULL){
        printf("dlopen error...\n");
        return -1;
    }
    printf("dlopen success...\n");

    //关闭共享库
    dlclose(handle);
    return 0;
}

#include "kmath.h"

int k_add(int x,int y){
    return (x+y)*x;
}

int k_sub(int x,int y){
    return x-y;
}

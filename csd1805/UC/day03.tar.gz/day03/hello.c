#include <stdio.h>
int main(void){
#if 1
    printf("hello beijing\n");
#endif
    return 0;
}

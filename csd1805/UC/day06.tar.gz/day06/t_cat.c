#include <stdio.h>
#include <t_file.h>

int main(int argc,char *argv[]){
    char buf[128]; int r;
    //打开文件，以只读的方式，文件名argv[1]
    int fd=open(argv[1],O_RDONLY);
    if(fd==-1){
        perror("open");
        return -1;
    }
    //从打开的文件中读取数据，将读取的数据输出到显示器
    while((r=read(fd,buf,128))>0)
            write(1,buf,r);

    //关闭文件描述符
    close(fd);
    return 0;
}

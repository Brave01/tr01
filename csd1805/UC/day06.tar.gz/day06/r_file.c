#include <stdio.h>
#include <t_file.h>

int main(int argc,char *argv[]){
    //打开文件，以只读的方式，argv[1]
    int fd=open(argv[1],O_RDONLY);
    if(fd==-1){
        perror("open");
        return -1;
    }
    printf("file %s open success...\n",argv[1]);
    //关闭文件
    close(fd);
    return 0;
}

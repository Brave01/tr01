#include <stdio.h>
#include <t_file.h>
#include <sys/mman.h>

int main(int argc,char *argv[]){
    //打开文件,以可读可写的方式
    int fd=open(argv[1],O_RDWR);
    if(fd==-1){
        perror("open");
        return -1;
    }

    int prot=PROT_READ|PROT_WRITE;
    int flags=MAP_SHARED;
    //将文件的内容映射到进程的虚拟地址空间
    void *p=mmap(NULL,6,prot,flags,fd,0);
    if(p==MAP_FAILED){
        perror("mmap");
        return -1;
    }
    //映射成功以后，就可以关闭文件
    close(fd);
    //修改映射区间的内容
    *((int *)p)=0x31323334;
    //解除映射
    munmap(p,6);
    return 0;
}

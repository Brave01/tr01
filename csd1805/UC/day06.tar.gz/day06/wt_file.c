#include <stdio.h>
#include <t_file.h>

int main(int argc,char *argv[]){
    //打开文件，以写的方式，argv[1]
    //文件不存在，创建文件，mode 0664
    //文件存在，将文件的内容清空
    int flags=O_WRONLY|O_CREAT|O_TRUNC;
    int fd=open(argv[1],flags,0664);
    if(fd==-1){
        perror("open");
        return -1;
    }
    printf("file %s open success...\n",argv[1]);
    //关闭文件
    close(fd);
    return 0;
}

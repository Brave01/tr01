#include <stdio.h>
#include <t_file.h>

int main(int argc,char *argv[]){
    //打开文件，以只读方式打开文件
    int fd=open(argv[1],O_RDONLY);
    if(fd==-1){
        perror("open");
        return -1;
    }
    //定位到第一个空格
    lseek(fd,6,SEEK_SET);
    //从文件读取四个字节的数据
    int buf;
    read(fd,&buf,sizeof(int));
    //将读取到的数据输出
    char *p=(char *)&buf;
    printf("%c",*p++);
    printf("%c",*p++);
    printf("%c",*p++);
    printf("%c",*p++);
    printf("\n");

    //关闭文件描述符
    close(fd);
    return 0;
}

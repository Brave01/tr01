#include <stdio.h>
#include <t_file.h>
#include <string.h>

int main(int argc,char *argv[]){
    char *msg="I am test...\n";
    int flags=O_WRONLY|O_CREAT|O_TRUNC;
    //打开文件，将标准输出重定向到这个文件。argv[1]
    int fd=open(argv[1],flags,0644);//fd 3
    if(fd==-1){
        perror("open");
        return -1;
    }
    int s_fd=dup(1);//s_fd  4 保存现场

    dup2(3,1);//将文件的描述符定位到标准输出上
    //关闭文件描述符
    close(fd);
    //向标准输出，输出字符串，内容输出到了文件里
    write(1,msg,strlen(msg));
    //恢复现场
    close(1);
    dup(s_fd);
    close(s_fd);
    //输出到显示器 
    write(1,msg,strlen(msg));
    return 0;
}

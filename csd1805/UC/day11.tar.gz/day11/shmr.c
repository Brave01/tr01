#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
int main(void){
    //获取一个键值
    key_t key=ftok(".",33);
    if(key==-1){
        perror("ftok");
        return -1; 
    }
    printf("0x%x\n",key);
    //获取共享内存段的id
    int shmid=shmget(key,1024,IPC_CREAT|0644);
    if(shmid==-1){perror("shmget");return -1;}
    //共享内存段获取成功
    printf("shmid:%d\n",shmid);
    //将共享内存段关联到进程的地址空间
    void *p=shmat(shmid,NULL,0);
    if(p==(void *)-1){perror("shmat");return -1;}
    printf("%s\n",(char *)p);
    getchar();
    //解除关联
    shmdt(p);
    return 0;
}

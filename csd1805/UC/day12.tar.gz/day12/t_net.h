#ifndef T_NET_H_
#define T_NET_H_
#include <sys/types.h>          /* See NOTES */
#include <sys/socket.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
typedef struct sockaddr_in SA4;
typedef struct sockaddr SA;
//函数的声明
int s_bind(int domain, int type,short port);
#endif

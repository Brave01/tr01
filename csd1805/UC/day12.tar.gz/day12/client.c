#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>          /* See NOTES */
#include <sys/socket.h>
#include <arpa/inet.h>

int main(int argc,char *argv[]){
    struct sockaddr_in serv;
    char buf[128];
    char *msg="this is my first net program\n";

    //创建socket,返回socket的文件描述符
    int sfd=socket(AF_INET,SOCK_STREAM,0);
    if(sfd==-1){perror("socket");;return -1;}
    //初始化serv的成员
    serv.sin_family=AF_INET;
    serv.sin_port=htons(7007);
    //serv.sin_addr.s_addr=htonl();
    //直到服务器的ip地址  字符串 127.0.0.1
    inet_pton(AF_INET,argv[1],&serv.sin_addr);
    //在sfd上向服务器发起连接
    int c=connect(sfd,(struct sockaddr *)&serv,\
            sizeof(serv));
    if(c==-1){perror("connect");return -1;}
    //向服务器发送消息
    write(sfd,msg,strlen(msg));
    //阻塞等待接收服务器的响应消息
    int r=read(sfd,buf,128);
    write(1,buf,r);
    //结束本次网络连接
    close(sfd);
    return 0;
}

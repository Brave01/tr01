#include "do_trans.h"
#include <ctype.h>

void do_it(int fd){
    char buf[128];
    int r=read(fd,buf,128);
    //将获取到的数据转换为大写
    for(int i=0;i<r;i++)
        buf[i]=toupper(buf[i]);

    write(fd,buf,r);
    return;
}

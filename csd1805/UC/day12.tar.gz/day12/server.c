#include <stdio.h>
#include "t_net.h"
#include "do_trans.h"
int main(void){
    SA4 clie;
    socklen_t cli_len;
    char IP[128];
    int sfd=s_bind(AF_INET,SOCK_STREAM,7007);
    if(sfd==-1){ return -1;}
    listen(sfd,5);
    while(1){
        cli_len=sizeof(clie);
        int cfd=accept(sfd,(SA *)&clie,&cli_len);
        if(cfd==-1){perror("accept");return -1;}
        printf("%s\n",\
            inet_ntop(AF_INET,&clie.sin_addr,IP,128));
        do_it(cfd);
        close(cfd);
    }
    return 0;
}

#include <stdio.h>
#include <t_file.h>
#include <string.h>

int main(int argc,char *argv[]){
    char *msg="this is a test...\n";
    //打开管道文件
    int fd=open(argv[1],O_WRONLY);
    if(fd==-1){
        perror("open");
        return -1;
    }
    //向管道写入数据
    write(fd,msg,strlen(msg));
    close(fd);
    return 0;
}

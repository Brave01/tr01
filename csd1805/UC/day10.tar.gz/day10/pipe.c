#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>

int main(void){
    int fd[2];
    char buf[128];
    char *msg="this is a test...\n";
    //创建管道
    int p=pipe(fd);
    if(p==-1){perror("pipe");return -1;}
    //创建子进程
    pid_t pid=fork();
    if(pid==-1){perror("fork");return -1;}
    if(pid==0){//子进程的任务,子进程继承了父进程的文件描
        close(fd[1]);
        //读写都是阻塞的,跟文件描述符相关
        int r=read(fd[0],buf,128);
        write(1,buf,r);
        close(fd[0]);
        exit(0);
    }else{//父进程的任务
        close(fd[0]);
        //如果管道里满,数据写不到管道里.阻塞
        write(fd[1],msg,strlen(msg));
        close(fd[1]);
        wait(NULL);
    }
    return 0;
}

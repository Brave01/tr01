#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>

int main(int argc,char *argv[]){
    //创建管道文件
    int f=mkfifo(argv[1],0644);
    if(f==-1){
        perror("mkfifo");
        return -1;
    }
    printf("file %s create success...\n",argv[1]);
    return 0;
}

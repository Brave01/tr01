#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <string.h>

//caller define
typedef struct msgbuf {
    long mtype;       /* message type, must be > 0 */
    char mtext[128];    /* message data */
}msg_t;

int main(void){
    msg_t msg;
    //获取一个键值
    key_t key=ftok(".",23);
    if(key==-1){
        perror("ftok");
        return -1; 
    }
    printf("0x%x\n",key);
    //使用键值获取消息队列的id
    int msqid=msgget(key,IPC_CREAT|0644);
    if(msqid==-1){
        perror("msgget");
        return -1;
    }
    printf("id:%d\n",msqid);
    //初始化具体的消息
    msg.mtype=3;
    strcpy(msg.mtext,"this is a test...\n");

    //向消息队列添加消息
    int snd=msgsnd(msqid,&msg,strlen(msg.mtext),0);
    if(snd==-1){
        perror("msgsnd");
        return -1;
    }
    return 0;
}

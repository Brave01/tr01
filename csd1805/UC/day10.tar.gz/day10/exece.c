#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdlib.h>

int main(void){
    char *ps_envp[]={"name=value",NULL};
    //创建子进程
    pid_t pid=fork();
    if(pid==-1){perror("fork");return -1;}
    if(pid==0){
        setenv("caption","beijing",0);
        //查看自己的环境变量
        execle("./tenv","tenv",NULL,ps_envp);
    }else{wait(NULL);}
    return 0;
}

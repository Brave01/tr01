#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>

int main(void){
    //获取一个键值
    key_t key=ftok(".",23);
    if(key==-1){
        perror("ftok");
        return -1; 
    }
    printf("0x%x\n",key);
    return 0;
}

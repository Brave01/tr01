#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>

int main(void){
    //获取一个键值
    key_t key=ftok(".",23);
    if(key==-1){
        perror("ftok");
        return -1; 
    }
    printf("0x%x\n",key);
    //使用键值获取消息队列的id
    int msqid=msgget(key,IPC_CREAT|0644);
    if(msqid==-1){
        perror("msgget");
        return -1;
    }
    printf("id:%d\n",msqid);
    return 0;
}

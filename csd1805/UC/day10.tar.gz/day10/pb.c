#include <stdio.h>
#include <t_file.h>

int main(int argc,char *argv[]){
    char buf[128];
    //打开管道文件
    int fd=open(argv[1],O_RDONLY);
    if(fd==-1){
        perror("open");
        return -1;
    }
    //从管道读取数据
    int r=read(fd,buf,128);
    write(1,buf,r);
    close(fd);
    return 0;
}

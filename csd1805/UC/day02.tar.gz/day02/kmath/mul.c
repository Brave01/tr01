#include "kmath.h"

int k_div(int x,int y){
    return x/y;
}

int k_mul(int x,int y){
    return x*y;
}

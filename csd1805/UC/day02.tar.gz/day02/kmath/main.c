#include <stdio.h>
#include "kmath.h"

int main(void){
    int a=6,b=2;
    printf("%d+%d=%d\n",a,b,k_add(a,b));
    printf("%d*%d=%d\n",a,b,k_mul(a,b));

    return 0;
}

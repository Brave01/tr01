#ifndef K_MATH_H_
#define K_MATH_H_

/*函数的声明*/
int k_add(int,int);
int k_sub(int,int);
int k_div(int,int);
int k_mul(int,int);

#endif

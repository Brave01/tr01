#include <stdio.h>
#include <signal.h>
#include <unistd.h>

//信号处理函数
void doit(int n){
    printf("recv...%d\n",n);
    return;
}
int main(void){
    sigset_t set,dset;
    signal(2,doit);
    signal(3,doit);
    signal(45,doit);
    //初始化集合为空
    sigemptyset(&set);
    //将2号信号添加到set集合中
    sigaddset(&set,2);
    sigaddset(&set,3);
    sigaddset(&set,45);
    sigaddset(&set,9);

    //设置进程对2号信号阻塞,set和当前信号集合并
    //dset保存原来的信号集
    int b=sigprocmask(SIG_BLOCK,&set,&dset);
    if(b==-1){
        perror("sigprocmask");
        return -1;
    }
    sleep(50);
    //恢复原来的信号掩码集.解除上边设置的信号屏蔽字
    sigprocmask(SIG_SETMASK,&dset,NULL);

    return 0;
}



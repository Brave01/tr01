#include <stdio.h>
#include <pthread.h>
#include <unistd.h>

//线程的执行函数
void *func1(void *arg){
    printf("func1 running....\n");
    sleep(3);
    return (void *)1;
}

void *func2(void *arg){
    printf("func2 running....\n");
    pthread_exit((void *)3);
}
void *func3(void *arg){
    while(1){
        printf("func3 running....\n");
        sleep(1);
    }
}

int main(void){
    pthread_t tid;
    void *ret;
    //创建一个线程
    pthread_create(&tid,NULL,func1,NULL);
    //阻塞等待线程的汇合,接收线程的退出状态码
    pthread_join(tid,&ret);
    printf("func1 exit code %d\n",(int)ret);
    //查看线程的退出状态码
    printf("main...thread\n");
    pthread_create(&tid,NULL,func2,NULL);
    //阻塞等待线程的汇合,接收线程的退出状态码
    pthread_join(tid,&ret);
    printf("func2 exit code %d\n",(int)ret);
    
    pthread_create(&tid,NULL,func3,NULL);
    sleep(3);
    //向tid线程发送取消请求
    pthread_cancel(tid);
    //阻塞等待线程的汇合,接收线程的退出状态码
    pthread_join(tid,&ret);
    if(ret==PTHREAD_CANCELED)
        printf("func3 exit code %d\n",(int)ret);

    return 0;
}

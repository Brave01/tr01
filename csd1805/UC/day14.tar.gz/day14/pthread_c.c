#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/types.h>
#include <unistd.h>

/*线程的执行函数*/
void *pdoit(void *arg){
    printf("%s pid:%d\ttid:%lu\n",(char *)arg,\
            getpid(),pthread_self());
    return NULL;
}

int main(void){
    pthread_t tid;
    //创建一个新的线程
    pthread_create(&tid,NULL,pdoit,"new");
    sleep(1);
    pdoit("main");

    return 0;
}

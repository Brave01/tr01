#include <sys/types.h>
#include <signal.h>
#include <stdlib.h>

int main(int argc,char *argv[]){
    int signum=atoi(argv[1]);
    int pid=atoi(argv[2]);
    kill(pid,signum);
    //kill(getpid(),signum);//给当前进程发送信号
    return 0;
}

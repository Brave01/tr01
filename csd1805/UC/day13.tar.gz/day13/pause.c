#include <unistd.h>
#include <stdio.h>
#include <signal.h>

void doit(int n){
    printf("recv...%d\n",n);
    return;
}

int main(void){
    signal(2,doit);
    //signal(2,SIG_IGN);
    printf("%d\n",pause());
    return 0;
}

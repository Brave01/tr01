#include <signal.h>
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>

//自定义信号处理函数
void doit(int n){
    printf("recv...%d\n",n);
    return;
}

int main(void){
    signal(2,doit);
    signal(3,doit);
    signal(9,SIG_IGN);
    pid_t pid=fork();
    if(pid==-1){perror("fork");return -1;}
    if(pid==0){
        printf("child pid:%d\n",getpid());
        while(1);
    }else{
        wait(NULL);
    }
    return 0;
}

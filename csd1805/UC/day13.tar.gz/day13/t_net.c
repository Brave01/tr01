#include <stdio.h>
#include <string.h>
#include "t_net.h"

int s_bind(int domain,int type,short port){
    SA4 serv;//存放服务器的ip地址和端口号
    
    //创建socket,返回该设备的文件描述符.TCP/IPV4
    int sfd=socket(domain,type,0);
    if(sfd==-1){
        perror("socket");
        return -1;
    }
    
    //初始化serv的成员
    serv.sin_family=domain;
    //7777
    serv.sin_port=htons(port);
    serv.sin_addr.s_addr=htonl(INADDR_ANY);
    
    //绑定sfd到服务器的地址家族
    int b=bind(sfd,(SA *)&serv,sizeof(serv));
    if(b==-1){perror("bind"); return -1;}
    return sfd;
}

#include "t_net.h"
#include <stdio.h>
#include <unistd.h>
#include <ctype.h>
int main(void){
    char buf[128];
    SA4 clie;
    socklen_t cli_len;

    //创建socket,并将socket绑定本地地址
    int fd=s_bind(AF_INET,SOCK_DGRAM,6006);
    if(fd==-1)return -1;

    while(1){
        cli_len=sizeof(clie);
        //阻塞等待接收客户端的消息
        int rcv=recvfrom(fd,buf,128,0,\
                (SA *)&clie,&cli_len);
        if(rcv==-1){
            perror("recvfrom");
            return -1;
        }
        //已经收到客户的消息,处理消息
        for(int i=0;i<rcv;i++)
            buf[i]=toupper(buf[i]);
        //将处理后的结果发送给客户端
        sendto(fd,buf,rcv,0,(SA *)&clie,sizeof(clie));
    }
    return 0;
}

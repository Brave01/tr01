#ifndef DO_TRANS_H_
#define DO_TRANS_H_
#include <unistd.h>
#include <string.h>
//业务处理
void do_it(int connfd);

#endif 

#include <stdio.h>
#include <unistd.h>

int main(void){
    alarm(5);
    for(int i=1;i<500000;i++)
        printf("i=%d\n",i);
    int r=alarm(0);//取消原来的闹钟,将闹钟没有执行的时间存到r变量里
    printf("r=%d\n",r);
    return 0;
}

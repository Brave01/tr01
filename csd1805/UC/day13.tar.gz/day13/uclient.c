#include "t_net.h"
#include <stdio.h>
#include <string.h>
int main(int argc,char *argv[]){
    SA4 serv;
    char buf[128];
    char *msg="this is a test...\n";
    //创建socket,返回文件描述符
    int fd=socket(AF_INET,SOCK_DGRAM,0);
    if(fd==-1){perror("socket");return -1;}
    //初始化serv的成员值
    serv.sin_family=AF_INET;
    serv.sin_port=htons(6006);
    //将ip地址从text---->binary,argv[1]
    inet_pton(AF_INET,argv[1],&serv.sin_addr);
    //使用fd向服务器发送消息
    int s=sendto(fd,msg,strlen(msg),\
            0,(SA *)&serv,sizeof(serv));
    if(s==-1){perror("sendto");return -1;}
    //阻塞等待服务器的响应消息
    int rcv=recvfrom(fd,buf,128,0,NULL,NULL);
    if(rcv==-1){perror("recvfrom");return -1;}
    close(fd);
    write(1,buf,rcv);
    return 0;
}

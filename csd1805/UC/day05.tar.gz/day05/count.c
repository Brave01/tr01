#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

//const 修饰的变量，当通过这个变量名访问变量内存的时候，内存是只读的。
const int var_s=342;//代码段

//声明变量
extern int var_g;
void count(void){
    static int i=1;//作用域只是当前函数，生命周期是进程
    printf("i=%d\t&i=%p\n",i++,&i);
    printf("var_g address =%p\n",&var_g);
    return;
}
int var_g=567;//作用域从当前开始到这个文件的结束，生命周期是进程

int main(void){
    int j;//作用域是当前函数，生命周期是栈帧
    printf("PID:%d\n",getpid());
    const int var_p=345;//空间分配到栈帧里，rw.但是你使用var_p变量的名字访问这块内存的时候，是只读的。
    //var_p=456;
    int *q=&var_p;
    *q=456;

    printf("&var_p=%p\n",&var_p);
    printf("var_p=%d\n",var_p);

#if 0
    int *q=&var_s;
    *q=567;
    printf("var_s=%d\n",var_s);
#endif
    printf("var_s address %p\n",&var_s);
    for(j=0;j<5;j++)
        count();
    printf("&var_g=%p\n",&var_g);
    char *mp=(char *)malloc(1024);
    printf("mp content...%p\n",mp);
    strcpy(mp,"good moring...");
    printf("%s\n",mp);
    getchar();
    free(mp);//mp到此结束了
    mp=NULL;
    //printf("after ...%s\n",mp);
    return 0;
}

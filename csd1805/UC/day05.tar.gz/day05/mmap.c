#include <stdio.h>
#include <sys/mman.h>
#include <string.h>

int main(void){
    int prot=PROT_WRITE|PROT_READ;
    int flags=MAP_PRIVATE|MAP_ANONYMOUS;
    //有操作系统选择一块物理地址，将其映射到进程的虚拟地址空间
    void *p=mmap(NULL,1024,prot,flags,-1,0);
    if(p==MAP_FAILED){
        perror("mmap");
        return -1;
    }
    //映射成功,p指向的地址就可以被使用了。
    strcpy((char *)p,"world cup");
    printf("%s\n",(char *)p);
    //解除映射
    munmap(p,1024);
    return 0;
}

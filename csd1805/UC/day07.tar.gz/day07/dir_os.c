#include <stdio.h>
#include <sys/types.h>
#include <dirent.h>
int main(int argc,char *argv[]){
    struct dirent *p;
    //打开文件夹，名字argv[1]
    DIR *dir=opendir(argv[1]);
    if(dir==NULL){
        perror("opendir");
        return -1;
    }
    //文件夹打开成功
    //读取文件夹的内荣
    while((p=readdir(dir)))
        printf("file:%s\tinode:%lu\n",p->d_name,p->d_ino);

    //关闭文件夹
    closedir(dir);
    return 0;
}


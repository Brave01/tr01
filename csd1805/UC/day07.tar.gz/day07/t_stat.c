#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <pwd.h>
#include <grp.h>
#include <time.h>

int main(int argc,char *argv[]){
    struct stat sbuf;

    //获取文件的元数据 argv[1]
    //将文件的元数据存放到sbuf变量的空间里了
    int s=stat(argv[1],&sbuf);
    if(s==-1){
        perror("stat");
        return -1;
    }
    printf("hard_link:%u\n",sbuf.st_nlink);
    printf("inode num:%lu\n",sbuf.st_ino);
    printf("file size:%ld\n",sbuf.st_size);
    printf("uid:%u\tusername:%s\n",sbuf.st_uid,\
            (getpwuid(sbuf.st_uid))->pw_name);
    printf("gid:%u\tgroup:%s\n",sbuf.st_gid,\
            (getgrgid(sbuf.st_gid))->gr_name);
    printf("access time:%ld\n",sbuf.st_atim.tv_sec);
    printf("access time:%s",\
            ctime(&sbuf.st_atime));
    printf("mode:%o\n",sbuf.st_mode);
    
    switch(sbuf.st_mode&S_IFMT){
        case S_IFSOCK:
            printf("s");
            break;
        case S_IFREG:
            printf("-");
            break;
        case S_IFDIR:
            printf("d");
            break;
        default:
            break;
    }
    //owner mode
    char f=(sbuf.st_mode&S_IRUSR)? 'r':'-';
    printf("%c",f);
    f=(sbuf.st_mode&S_IWUSR)? 'w':'-';
    printf("%c",f);
    f=(sbuf.st_mode&S_IXUSR)? 'x':'-';
    printf("%c",f);

    printf("\n");
    return 0;
}

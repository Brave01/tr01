#include "CalculatorDialog.h"
#include "ui_CalculatorDialog.h"

CalculatorDialog::CalculatorDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::CalculatorDialog)
{
    ui->setupUi(this);
    ui->m_editX->setValidator(
        new QDoubleValidator(this));
    ui->m_editY->setValidator(
        new QDoubleValidator(this));
    connect(
      ui->m_editX,SIGNAL(textChanged(QString)),
      this,SLOT(enableCalcButton()));
    connect(
      ui->m_editY,SIGNAL(textChanged(QString)),
      this,SLOT(enableCalcButton()));
    connect(ui->m_button,SIGNAL(clicked()),
      this,SLOT(calcButton()));
}

CalculatorDialog::~CalculatorDialog()
{
    delete ui;
}
void CalculatorDialog::enableCalcButton()
{
    bool bXOk,bYOk;
    ui->m_editX->text().toDouble(&bXOk);
    ui->m_editY->text().toDouble(&bYOk);
    ui->m_button->setEnabled(bXOk && bYOk);
}
void CalculatorDialog::calcButton()
{
    double res = ui->m_editX->text().toDouble()
              + ui->m_editY->text().toDouble();
    QString str = QString::number(res);
    ui->m_editZ->setText(str);
}













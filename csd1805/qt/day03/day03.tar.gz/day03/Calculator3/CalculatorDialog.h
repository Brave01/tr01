#ifndef CALCULATORDIALOG_H
#define CALCULATORDIALOG_H

#include <QDialog>

//#include "ui_CalculatorDialog.h"
namespace Ui {
class CalculatorDialog;//短视声明
}

class CalculatorDialog : public QDialog
{
    Q_OBJECT

public:
    explicit CalculatorDialog(QWidget *parent = 0);
    ~CalculatorDialog();
public slots:
    void enableCalcButton();
    void calcButton();

private:
    //可以使用ui去访问界面类中的代码
    //eg:ui->m_editX
    Ui::CalculatorDialog *ui;
};

#endif // CALCULATORDIALOG_H




#ifndef __CALCULATORDIALOG_H
#define __CALCULATORDIALOG_H

#include "ui_CalculatorDialog.h"

class CalculatorDialog
    :public QDialog,
     public Ui::CalculatorDialog{
    Q_OBJECT
public:
    CalculatorDialog();
public slots:
    //使能等号按钮的槽函数
    void enableCalcButton();
    //计算和显示结果的槽函数
    void calcClicked();
};
#endif//__CALCULATORDIALOG_H





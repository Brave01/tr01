#include "LoginDialog.h"
//构造函数
LoginDialog::LoginDialog()
{
    //界面初始化
    setupUi(this);
    //信号和槽连接
    //点击Ok按钮发送信号accepted
    connect(m_btnBox,SIGNAL(accepted()),
            this,SLOT(onAccepted()));
    //点击Cancel按钮发送信号rejected
    connect(m_btnBox,SIGNAL(rejected()),
            this,SLOT(onRejected()));
}
//自定义的槽函数:处理Ok按钮
void LoginDialog::onAccepted()
{
    //检查输入的用户名和密码,如果是tarena和
    //123456,则打印登录成功,否则提示登录失败
    if(m_editUserName->text()=="tarena" &&
        m_editPassword->text()=="123456"){
        qDebug("登录成功");
        qDebug() << "Login Success";
        close();//关闭登录对话框
    }
    else{
        //参数:
        //1)提示框的图标
        //2)提示框标题
        //3)提示消息
        //4)按钮
        //5)父窗口指针
        QMessageBox msgBox(
            QMessageBox::Critical,
            windowTitle(),
            "用户名或密码错误,请重试!",
            QMessageBox::Ok,
            this);
        //显示消息提示框,并进入事件循环
        //点击上面按钮时会退出事件循环
        msgBox.exec();
    }
}
//处理Cancel按钮
void LoginDialog::onRejected()
{
    QMessageBox msgBox(
        QMessageBox::Question,
        windowTitle(),
        "确定要退出吗?",
        QMessageBox::No|QMessageBox::Yes,
        this);
    /* 显示消息提示框,并进入事件循环,点击上
     * 面任何按钮都会退出事件循环,但是返
     * 回结果不同,如果点"Yes"才真的退出*/
    if(msgBox.exec()==QMessageBox::Yes){
        close();//关闭登录对话框
    }
}













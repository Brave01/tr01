#ifndef __TIMEDIALOG_H
#define __TIMEDIALOG_H
#include <QDialog>
#include <QLabel>
#include <QPushButton>
#include <QVBoxLayout>
#include <QTime>
class TimeDialog:public QDialog{
    Q_OBJECT
public:
    TimeDialog();
public slots:
    void timeClicked();
private:
    QLabel* m_label;
    QPushButton* m_button;
};
#endif//__TIMEDIALOG_H


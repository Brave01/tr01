#include "TimeDialog.h"

TimeDialog::TimeDialog(void)
{
    setWindowTitle("系统时间");
    //显示时间的label
    m_label = new QLabel(this);
    //设置label边框的图形效果:凹陷的面板
    m_label->setFrameStyle(
        QFrame::Panel|QFrame::Sunken);
    //设置label显示的文本居中
    m_label->setAlignment(
        Qt::AlignHCenter|Qt::AlignVCenter);
    //获取时间的button
    m_button = new QPushButton(
            "获取系统时间",this);
    //创建垂直布局器
    QVBoxLayout* layout = 
        new QVBoxLayout(this);
    //将组件按垂直方向依次添加到布局器
    layout->addWidget(m_label);
    layout->addWidget(m_button);
    //设置布局器
    setLayout(layout);

    //信号和槽连接
    connect(m_button,SIGNAL(clicked()),
            this,SLOT(timeClicked()));
}
void TimeDialog::timeClicked(void)
{
    //获取系统时间
    QTime time = QTime::currentTime();
    //转换为QString
    QString str = time.toString("hh:mm:ss");
    //显示时间
    m_label->setText(str);
}









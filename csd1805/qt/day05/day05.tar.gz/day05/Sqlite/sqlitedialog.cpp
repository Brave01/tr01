#include "sqlitedialog.h"
#include "ui_sqlitedialog.h"

SqliteDialog::SqliteDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::SqliteDialog)
{
    ui->setupUi(this);
    creatDB();
    creatTable();
    queryTable();
}
SqliteDialog::~SqliteDialog()
{
    delete ui;
}
//创建数据库
void SqliteDialog::creatDB(void)
{
    //添加数据库驱动
    db=QSqlDatabase::addDatabase("QSQLITE");
    //设置数据库名字
    db.setDatabaseName("student.db");
    //打开数据库
    if(db.open() == false){
        qDebug() << db.lastError().text();
    }
}
//创建数据表
void SqliteDialog::creatTable(void)
{
    QSqlQuery query;//用于执行sql语句
    //准备要执行的sql语句字符串
    QString str = QString(
        "CREATE TABLE student ("
        "ID INT PRIMARY KEY NOT NULL,"
        "Name TEXT NOT NULL,"
        "Score REAL NOT NULL)");
    //执行sql语句
    if(query.exec(str)==false){
        qDebug() << str;
    }
    else{
        qDebug() << "创建数据表成功!";
    }
}
//查询和显示
void SqliteDialog::queryTable(void)
{
    QString str = QString(
        "SELECT * FROM student");
    //执行查询操作,并保存结果集到model
    model.setQuery(str);
    //显示查询结果
    ui->tableView->setModel(&model);
}
//排序查询
void SqliteDialog::on_sortButton_clicked()
{
    //获取排序时列名ID/Score
    QString value =
        ui->valueComBox->currentText();
    //获取排序方式:升序/降序
    QString condition;
    if(ui->condComBox->currentIndex()){
        condition = "DESC";
    }
    else{
        condition = "ASC";
    }
    QString str = QString(
        "SELECT * FROM student ORDER BY "
        "%1 %2").arg(value).arg(condition);
    model.setQuery(str);
    ui->tableView->setModel(&model);
}
//插入
void SqliteDialog::on_insertButton_clicked()
{
    QSqlQuery query;
    //获取用户输入的ID,Name,Score
    int id = ui->idEdit->text().toInt();
    QString name = ui->nameEdit->text();
    double score =
        ui->scoreEdit->text().toDouble();
    QString str = QString(
        "INSERT INTO student "
        "VALUES(%1,'%2',%3)"
        ).arg(id).arg(name).arg(score);
    if(query.exec(str)==false){
        qDebug() << str;
    }
    else{
        qDebug() << "插入操作成功" << endl;
    }
    //重新查询和显示
    queryTable();
}
//删除,根据ID删除一条数据
void SqliteDialog::on_deleteButton_clicked()
{
    QSqlQuery query;
    int id = ui->idEdit->text().toInt();
    QString str = QString(
        "DELETE FROM student "
        "WHERE id=%1").arg(id);
    if(query.exec(str)==false){
        qDebug() << str;
    }
    else{
        qDebug() << "删除成功";
    }
    queryTable();
}
//修改,根据id修改成绩
void SqliteDialog::on_updateButton_clicked()
{
    QSqlQuery query;
    int id = ui->idEdit->text().toInt();
    double score =
        ui->scoreEdit->text().toDouble();
    QString str = QString(
        "UPDATE student SET score=%1 "
        "WHERE id=%2").arg(score).arg(id);
    if(query.exec(str)==false){
        qDebug() << str;
    }
    else{
        qDebug() << "修改成功";
    }
    queryTable();
}






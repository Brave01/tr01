#ifndef SQLITEDIALOG_H
#define SQLITEDIALOG_H

#include <QDialog>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlQueryModel>
#include <QDebug>
#include <QSqlError>

namespace Ui {
class SqliteDialog;
}

class SqliteDialog : public QDialog
{
    Q_OBJECT

public:
    explicit SqliteDialog(QWidget *parent = 0);
    ~SqliteDialog();

private:
    //创建数据库
    void creatDB(void);
    //创建数据表
    void creatTable(void);
    //查询和显示
    void queryTable(void);
private slots:
    void on_sortButton_clicked();
    void on_insertButton_clicked();
    void on_deleteButton_clicked();
    void on_updateButton_clicked();

private:
    Ui::SqliteDialog *ui;
    QSqlDatabase db;
    QSqlQueryModel model;
};

#endif // SQLITEDIALOG_H



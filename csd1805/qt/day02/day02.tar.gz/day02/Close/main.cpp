#include <QApplication>
#include <QPushButton>
#include <QLabel>
int main(int argc,char** argv)
{
    QApplication app(argc,argv);
    QPushButton button("关闭标签");
    QLabel label("请关闭我");
    button.show();
    label.show();
    //连接信号和槽
    QObject::connect(
        &button,SIGNAL(clicked()),
        &label,SLOT(close()));
    //练习:实现点击信号,关闭应用程序
    QObject::connect(
        &button,SIGNAL(clicked()),
        //&app,SLOT(closeAllWindows()));
        &app,SLOT(quit()));
    /*QObject::connect(
        &button,SIGNAL(clicked()),
        &button,SLOT(close()));*/
    
    return app.exec();
}









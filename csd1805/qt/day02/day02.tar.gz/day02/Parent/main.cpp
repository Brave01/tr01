#include <QApplication>
#include <QLabel>
#include <QPushButton>
#include <QWidget>
#include <QMainWindow>
#include <QDialog>
int main(int argc,char** argv)
{
    QApplication app(argc,argv);
    //创建父窗口
    //QWidget parent;
    //QMainWindow parent;
    QDialog parent;
    parent.resize(500,500);

    //创建label组件并停靠在父窗口上面
    //QLabel label("我是标签",&parent);
    //label.move(50,50);
    
    //new的对象如果指定了父窗口,当父窗口对象
    //销毁时,将会自动被delete,不需要再单独写
    //delete语句.
    QLabel* label = new QLabel(
            "我是标签",&parent);
    label->move(50,50);

    //创建button组件并停靠在父窗口上面
    QPushButton button("我是按钮",&parent);
    button.move(50,200);
    button.resize(150,150);

    //显示父窗口,上面包含的组件也会一起显示
    parent.show();
    return app.exec();
}









#include "CalculatorDialog.h"
//构造函数
CalculatorDialog::CalculatorDialog()
{
    //1)界面初始化
    setWindowTitle("加法计算器");
    //左操作数
    //this指向当前父窗口,即父窗口指针
    m_editX = new QLineEdit(this);
    //设置文本对齐方式:右对齐
    m_editX->setAlignment(Qt::AlignRight);
    //设置验证器:只能输入数字
    m_editX->setValidator(
            new QDoubleValidator(this));
    //右操作数
    m_editY = new QLineEdit(this);
    m_editY->setAlignment(Qt::AlignRight);
    m_editY->setValidator(
            new QDoubleValidator(this));
    //显示结果
    m_editZ = new QLineEdit(this);
    m_editZ->setAlignment(Qt::AlignRight);
    m_editZ->setReadOnly(true);//设置只读
    //"+"
    m_label = new QLabel("+",this);
    //"="
    m_button = new QPushButton("=",this);
    m_button->setEnabled(false);//设置禁用
    //创建布局器:自动调整每个组件的大小位置
    QHBoxLayout *layout = 
        new QHBoxLayout(this);
    //按水平方向,将图形组件依次添加到布局器
    layout->addWidget(m_editX);
    layout->addWidget(m_label);
    layout->addWidget(m_editY);
    layout->addWidget(m_button);
    layout->addWidget(m_editZ);
    //设置布局器
    setLayout(layout);

    //2)信号和槽连接
    //当左右操作数输入文本时,发送textChanged
    //如果连接的槽是在当前父窗口中自定义的,
    //那么第三个参数一定是this.
    connect(
      m_editX,SIGNAL(textChanged(QString)),
      this,SLOT(enableCalcButton()));
    connect(
      m_editY,SIGNAL(textChanged(QString)),
      this,SLOT(enableCalcButton()));
    //当点击等号按钮,发送信号clicked
    connect(m_button,SIGNAL(clicked()),
        this,SLOT(calcClicked()));
}
//自定义槽函数
void CalculatorDialog::enableCalcButton()
{
    bool bXOk;
    bool bYOk;
    //1)检查左右操作数是否输入了有效数据
    //text():获取输入文本(QString)
    //toDouble():将QString转换为double,参数
    //保存转换成功或失败的结果
    m_editX->text().toDouble(&bXOk);
    m_editY->text().toDouble(&bYOk);
    //2)如果左右操作数都输入了有效数据,则
    //  使能等号按钮
    m_button->setEnabled(bXOk && bYOk);
}
void CalculatorDialog::calcClicked()
{
    //1)获取左右操作数的数据,并计算
    double res = m_editX->text().toDouble()
               + m_editY->text().toDouble();
    //2)显示计算的结果
    //number(double):将double转换为QString
    //setText(QString):设置组件显示的内容
    m_editZ->setText(QString::number(res));
}









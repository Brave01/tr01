#ifndef __CALCULATORDIALOG_H
#define __CALCULATORDIALOG_H

#include <QDialog>
#include <QLabel>
#include <QPushButton>
#include <QLineEdit>
#include <QDoubleValidator>//数字验证器
#include <QHBoxLayout>//水平布局器

class CalculatorDialog:public QDialog{
    Q_OBJECT
public:
    CalculatorDialog();
public slots:
    //使能等号按钮的槽函数
    void enableCalcButton();
    //计算和显示结果的槽函数
    void calcClicked();
private:
    QLineEdit* m_editX;//左操作数
    QLineEdit* m_editY;//右操作数
    QLineEdit* m_editZ;//显示计算的结果
    QLabel* m_label;//"+"
    QPushButton* m_button;//"="
};
#endif//__CALCULATORDIALOG_H





#include <QApplication>
#include <QDialog>
#include <QSlider>
#include <QSpinBox>
int main(int argc,char** argv)
{
    QApplication app(argc,argv);

    QDialog parent;
    parent.resize(200,100);

    //创建水平的滑块并停靠在父窗口上
    QSlider slider(Qt::Horizontal,&parent);
    slider.move(20,20);
    slider.setRange(0,147);

    //创建选值框并停靠在父窗口上
    QSpinBox spin(&parent);
    spin.move(120,20);
    spin.setRange(0,147);
    //显示父窗口,它上包含的组件也会一起显示
    parent.show();
    //滑块滑动时,选值框数值随之改变
    QObject::connect(
        &slider,SIGNAL(valueChanged(int)),
        &spin,SLOT(setValue(int)));
    //选值框值改变时,滑块也随之滑动
    QObject::connect(
        &spin,SIGNAL(valueChanged(int)),
        &slider,SLOT(setValue(int)));

    return app.exec();
}










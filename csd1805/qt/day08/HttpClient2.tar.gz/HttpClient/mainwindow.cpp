#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "logindialog.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    //点击菜单栏时发送信号triggered
    connect(ui->menuBar,
      SIGNAL(triggered(QAction*)),
      this,SLOT(onTriggered(QAction*)));
    //点击文件的下拉菜单发送信号triggered
    connect(ui->menuFile,
      SIGNAL(triggered(QAction*)),
      this,SLOT(onTriggered(QAction*)));
    //隐藏下载进度条
    ui->progressBar->hide();

    //创建manager对象,用于管理通信过程
    manager=new QNetworkAccessManager(this);
    //创建和初始化请求
    request = new QNetworkRequest(
        QUrl("http://code.tarena.com.cn/"));
    //向服务器发送请求
    sendRequest();
}
MainWindow::~MainWindow()
{
    delete ui;
}
//处理菜单栏的槽函数
void MainWindow::onTriggered(
        QAction* action){
    //在状态栏显示选择的菜单选项
    ui->statusBar->showMessage(
                action->text());
    //如果选择Full则窗口全屏
    if(action->menu() == ui->menuFull){
        showFullScreen();
    }
    //如果选择Normal则恢复窗口
    else if(action->menu()==ui->menuNormal){
        showNormal();
    }
}
//向服务器发送请求
void MainWindow::sendRequest(void)
{
    reply = manager->get(*request);
    //如果服务器需要登录认证,将会发送信号
    //authenticationRequired
    connect(manager,SIGNAL(
      authenticationRequired(
        QNetworkReply*,QAuthenticator*)),
      this,SLOT(onAuthenticationRequest(
        QNetworkReply*,QAuthenticator*)));
    //如果认证成功,服务器会发送响应数据,对应信号
    //readyRead
    connect(reply,SIGNAL(readyRead()),
            this,SLOT(onReadyRead()));
    //响应数据接收结束.发送信号finished
    connect(reply,SIGNAL(finished()),
            this,SLOT(onFinished()));
}
//验证登录用户名和密码的槽函数
void MainWindow::onAuthenticationRequest(
     QNetworkReply*,QAuthenticator* authe){
    qDebug("onAuthenticationRequest");
    //练习:增加登录对话框,用户名和密码要求从登录
    //对话框中获取
    LoginDialog login(this);
    if(login.exec() == QDialog::Accepted){
        authe->setUser(login.getUsername());
        authe->setPassword(login.getPassword());
    }
}
//接收响应数据的槽函数
void MainWindow::onReadyRead()
{
    qDebug("onReadyRead");
    //接收数据
    QString buf = reply->readAll();
    //显示数据到界面
    ui->textBrowser->setText(buf);
    //保存当前url地址
    currentUrl = reply->url();
}
//接收响应数据结束后执行的槽函数
void MainWindow::onFinished()
{
    qDebug("onFinished");
    reply->deleteLater();
    reply = NULL;
}





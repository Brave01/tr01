#include "logindialog.h"
#include "ui_logindialog.h"

LoginDialog::LoginDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::LoginDialog)
{
    ui->setupUi(this);
}

LoginDialog::~LoginDialog()
{
    delete ui;
}
//ok按钮的槽函数
void LoginDialog::on_m_btnBox_accepted()
{
    username = ui->m_usernameEdit->text();
    password = ui->m_passwordEdit->text();
    accept();//返回QDialog::Accepted
}
//cancel按钮的槽函数
void LoginDialog::on_m_btnBox_rejected()
{
    reject();//返回QDialog::Rejected
}




#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "logindialog.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    //点击菜单栏时发送信号triggered
    connect(ui->menuBar,
      SIGNAL(triggered(QAction*)),
      this,SLOT(onTriggered(QAction*)));
    //点击文件的下拉菜单发送信号triggered
    connect(ui->menuFile,
      SIGNAL(triggered(QAction*)),
      this,SLOT(onTriggered(QAction*)));
    //隐藏下载进度条
    ui->progressBar->hide();

    //创建manager对象,用于管理通信过程
    manager=new QNetworkAccessManager(this);
    //创建和初始化请求
    request = new QNetworkRequest(
        QUrl("http://code.tarena.com.cn/"));
    //向服务器发送请求
    sendRequest();

    //点击界面上链接时,发送信号anchorClicked
    connect(ui->textBrowser,
        SIGNAL(anchorClicked(QUrl)),
        this,SLOT(onAnchorClicked(QUrl)));

    //向容器添加支持下载的文件类型(后缀)
    fileType << ".tar" << ".bz2" << ".xz";
    fileType << ".zip" << ".rar" << ".7z";
    fileType << ".doc" << ".txt" << ".pdf";
    fileType << ".c" << ".h" << ".ui";
    fileType << ".png" << ".jpg" << ".bmp";
}
MainWindow::~MainWindow()
{
    delete ui;
}
//处理菜单栏的槽函数
void MainWindow::onTriggered(
        QAction* action){
    //在状态栏显示选择的菜单选项
    ui->statusBar->showMessage(
                action->text());
    //如果选择Full则窗口全屏
    if(action->menu() == ui->menuFull){
        showFullScreen();
    }
    //如果选择Normal则恢复窗口
    else if(action->menu()==ui->menuNormal){
        showNormal();
    }
}
//向服务器发送请求
void MainWindow::sendRequest(void)
{
    reply = manager->get(*request);
    //如果服务器需要登录认证,将会发送信号
    //authenticationRequired
    connect(manager,SIGNAL(
      authenticationRequired(
        QNetworkReply*,QAuthenticator*)),
      this,SLOT(onAuthenticationRequest(
        QNetworkReply*,QAuthenticator*)));
    //如果认证成功,服务器会发送响应数据,对应信号
    //readyRead
    connect(reply,SIGNAL(readyRead()),
            this,SLOT(onReadyRead()));
    //响应数据接收结束.发送信号finished
    connect(reply,SIGNAL(finished()),
            this,SLOT(onFinished()));
}
//验证登录用户名和密码的槽函数
void MainWindow::onAuthenticationRequest(
     QNetworkReply*,QAuthenticator* authe){
    //qDebug("onAuthenticationRequest");
    //练习:增加登录对话框,用户名和密码要求从登录
    //对话框中获取
    LoginDialog login(this);
    if(login.exec() == QDialog::Accepted){
        authe->setUser(login.getUsername());
        authe->setPassword(login.getPassword());
    }
}
//接收响应数据的槽函数
void MainWindow::onReadyRead()
{
    //qDebug("onReadyRead");
    //接收数据
    QString buf = reply->readAll();
    //显示数据到界面
    ui->textBrowser->setText(buf);
    //保存当前url地址
    currentUrl = reply->url();
}
//接收响应数据结束后执行的槽函数
void MainWindow::onFinished()
{
    //qDebug("onFinished");
    reply->deleteLater();
    reply = NULL;
}
//处理子目录链接的槽函数,参数表示当前点击的网址
void MainWindow::onAnchorClicked(
        const QUrl& url)
{
    //"http://code.tarena.com.cn/"
    qDebug() << "当前的url" <<
                currentUrl.toString();
    //"CSDCode/"
    qDebug() << "点击的url" <<
                url.toString();

    QUrl newUrl;
    //如果当前点击的不是"../"
    //子目录链接网址=当前网址+点击网址
    //http://code.tarena.com.cn/CSDCode/
    if(url.toString() != "../"){
        newUrl = currentUrl.toString() +
            url.toString();
    }
    else{//处理"../"的目录链接
        //如果当前在顶层链接目录下,不处理
        if(currentUrl.toString() ==
            "http://code.tarena.com.cn/"){
            return;
        }
        //如果不在顶层链接目录下,则去掉最后一级路径
        //当前url:"http://xx/CSDCode/csd1805/"
        //新的url:"http://xx/CSDCode/"
        else{
            //查找倒数第二次"/"的位置
            int pos = currentUrl.toString(
                    ).lastIndexOf("/",-2);
            //截断字符串,去掉最后一级路径
            newUrl = currentUrl.toString(
                    ).mid(0,pos+1);
        }
    }

    //检查新的链接网址是否为要下载的文件,如果是
    //则执行文件下载操作
    //"http://xx/CSDCode/c++/day01.txt"
    foreach(QString type,fileType){
        int res =
          url.toString().lastIndexOf(type);
        if(res >= 0){
            qDebug() << "下载文件...";
            return;
        }
    }
    //设置请求为新的链接网址
    request->setUrl(newUrl);
    //发送新的链接请求
    sendRequest();
}













#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "logindialog.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    //点击菜单栏时发送信号triggered
    connect(ui->menuBar,
      SIGNAL(triggered(QAction*)),
      this,SLOT(onTriggered(QAction*)));
    //点击文件的下拉菜单发送信号triggered
    connect(ui->menuFile,
      SIGNAL(triggered(QAction*)),
      this,SLOT(onTriggered(QAction*)));
    //隐藏下载进度条
    ui->progressBar->hide();

    //创建manager对象,用于管理通信过程
    manager=new QNetworkAccessManager(this);
    //创建和初始化请求
    request = new QNetworkRequest(
        QUrl("http://code.tarena.com.cn/"));
    //向服务器发送请求
    sendRequest();

    //点击界面上链接时,发送信号anchorClicked
    connect(ui->textBrowser,
        SIGNAL(anchorClicked(QUrl)),
        this,SLOT(onAnchorClicked(QUrl)));

    //向容器添加支持下载的文件类型(后缀)
    fileType << ".tar" << ".bz2" << ".xz";
    fileType << ".zip" << ".rar" << ".7z";
    fileType << ".doc" << ".txt" << ".pdf";
    fileType << ".c" << ".h" << ".ui";
    fileType << ".png" << ".jpg" << ".bmp";
}
MainWindow::~MainWindow()
{
    delete ui;
}
//处理菜单栏的槽函数
void MainWindow::onTriggered(
        QAction* action){
    //在状态栏显示选择的菜单选项
    ui->statusBar->showMessage(
                action->text());
    //如果选择Full则窗口全屏
    if(action->menu() == ui->menuFull){
        showFullScreen();
    }
    //如果选择Normal则恢复窗口
    else if(action->menu()==ui->menuNormal){
        showNormal();
    }
}
//向服务器发送请求
void MainWindow::sendRequest(void)
{
    reply = manager->get(*request);
    //如果服务器需要登录认证,将会发送信号
    //authenticationRequired
    connect(manager,SIGNAL(
      authenticationRequired(
        QNetworkReply*,QAuthenticator*)),
      this,SLOT(onAuthenticationRequest(
        QNetworkReply*,QAuthenticator*)));
    //如果认证成功,服务器会发送响应数据,对应信号
    //readyRead
    connect(reply,SIGNAL(readyRead()),
            this,SLOT(onReadyRead()));
    //响应数据接收结束.发送信号finished
    connect(reply,SIGNAL(finished()),
            this,SLOT(onFinished()));
}
//验证登录用户名和密码的槽函数
void MainWindow::onAuthenticationRequest(
     QNetworkReply*,QAuthenticator* authe){
    //qDebug("onAuthenticationRequest");
    //练习:增加登录对话框,用户名和密码要求从登录
    //对话框中获取
    LoginDialog login(this);
    if(login.exec() == QDialog::Accepted){
        authe->setUser(login.getUsername());
        authe->setPassword(login.getPassword());
    }
}
//接收响应数据的槽函数
void MainWindow::onReadyRead()
{
    //qDebug("onReadyRead");
    //接收数据
    QString buf = reply->readAll();
    //显示数据到界面
    ui->textBrowser->setText(buf);
    //保存当前url地址
    currentUrl = reply->url();
}
//接收响应数据结束后执行的槽函数
void MainWindow::onFinished()
{
    //qDebug("onFinished");
    reply->deleteLater();
    reply = NULL;
}
//处理子目录链接的槽函数,参数表示当前点击的网址
void MainWindow::onAnchorClicked(
        const QUrl& url)
{
    //"http://code.tarena.com.cn/"
    //qDebug() << "当前的url" <<
    //            currentUrl.toString();
    //"CSDCode/"
    //qDebug() << "点击的url" <<
    //            url.toString();

    QUrl newUrl;
    //如果当前点击的不是"../"
    //子目录链接网址=当前网址+点击网址
    //http://code.tarena.com.cn/CSDCode/
    if(url.toString() != "../"){
        newUrl = currentUrl.toString() +
            url.toString();
    }
    else{//处理"../"的目录链接
        //如果当前在顶层链接目录下,不处理
        if(currentUrl.toString() ==
            "http://code.tarena.com.cn/"){
            return;
        }
        //如果不在顶层链接目录下,则去掉最后一级路径
        //当前url:"http://xx/CSDCode/csd1805/"
        //新的url:"http://xx/CSDCode/"
        else{
            //查找倒数第二次"/"的位置
            int pos = currentUrl.toString(
                    ).lastIndexOf("/",-2);
            //截断字符串,去掉最后一级路径
            newUrl = currentUrl.toString(
                    ).mid(0,pos+1);
        }
    }

    //检查新的链接网址是否为要下载的文件,如果是
    //则执行文件下载操作
    //"http://xx/CSDCode/c++/day01.txt"
    foreach(QString type,fileType){
        int res =
          url.toString().lastIndexOf(type);
        if(res >= 0){
            //qDebug() << "下载文件...";
            downloadFile(newUrl);
            return;
        }
    }
    //设置请求为新的链接网址
    request->setUrl(newUrl);
    //发送新的链接请求
    sendRequest();
}
//下载文件
void MainWindow::downloadFile(
        const QUrl& fileUrl)
{
    //根据网址获取文件名
    //"http://xx/CSDCode/c++/day01.txt"
    QFileInfo fileInfo(fileUrl.path());
    QString fileName(fileInfo.fileName());
    //在本地创建同名的文件
    file = new QFile(fileName,this);
    file->open(QIODevice::WriteOnly);

    //发送获取文件数据的连接请求
    request->setUrl(fileUrl);
    reply = manager->get(*request);

    //响应数据(文件内容)到来,发送信号readyRead
    connect(reply,SIGNAL(readyRead()),
        this,SLOT(receiveFile()));

    //文件下载完成,发送信号finished
    connect(reply,SIGNAL(finished()),
        this,SLOT(receiveFileFinished()));

    //伴随文件下载,发送表示文件下载进度的信号:
    //downloadProgress
    connect(reply,SIGNAL(
        downloadProgress(qint64,qint64)),
        this,SLOT(updateDownloadPregress(
                     qint64,qint64)));
    //显示下载进度条
    ui->progressBar->setValue(0);
    ui->progressBar->show();
}
//接收文件内容的槽函数
void MainWindow::receiveFile()
{
    qDebug("正在下载文件...");
    //下载文件内容并保存
    file->write(reply->readAll());
}
//文件下载完成时槽函数
void MainWindow::receiveFileFinished()
{
    qDebug("文件下载完成!");
    file->flush();//刷新文件流
    file->close();//关闭文件

    reply->deleteLater();
    reply = NULL;

    //隐藏下载进度条
    ui->progressBar->hide();
}

//更新显示文件下载进度的槽函数
//参数:已经接收的字节数/总字节数
void MainWindow::updateDownloadPregress(
     qint64 bytesRead,qint64 bytesTotal){
    ui->progressBar->setMaximum(bytesTotal);
    ui->progressBar->setValue(bytesRead);
}








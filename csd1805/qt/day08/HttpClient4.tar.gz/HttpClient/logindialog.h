#ifndef LOGINDIALOG_H
#define LOGINDIALOG_H

#include <QDialog>

namespace Ui {
class LoginDialog;
}

class LoginDialog : public QDialog
{
    Q_OBJECT

public:
    explicit LoginDialog(QWidget *parent = 0);
    ~LoginDialog();

private slots:
    void on_m_btnBox_accepted();
    void on_m_btnBox_rejected();
public:
    const QString& getUsername(){
        return username;
    }
    const QString& getPassword(){
        return password;
    }
private:
    Ui::LoginDialog *ui;
    QString username;
    QString password;
};

#endif // LOGINDIALOG_H






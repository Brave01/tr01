#include <QApplication>
#include <QLabel>
#include <QPushButton>
#include <QTextCodec>
int main(int argc,char** argv)
{
    QApplication app(argc,argv);
    QTextCodec* coder = 
        QTextCodec::codecForName("GBK");
    
    /*QString str1 = 
        coder->toUnicode("���Ǳ�ǩ");
    QString str2 = 
        coder->toUnicode("���ǰ�ť");*/
    QLabel label(
            coder->toUnicode("���Ǳ�ǩ"));
    QPushButton button(
            coder->toUnicode("���ǰ�ť"));

    label.show();
    button.show();

    return app.exec();
}


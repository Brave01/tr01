#ifndef WORKERTHREAD_H
#define WORKERTHREAD_H

#include <QThread>

//1)继承QThread
class WorkerThread:public QThread
{
public:
    WorkerThread();
    ~WorkerThread();
protected:
    //2)重写线程的入口函数
    void run(void);
};

#endif // WORKERTHREAD_H




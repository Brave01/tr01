#include "workerthread.h"

WorkerThread::WorkerThread()
{
}
WorkerThread::~WorkerThread()
{
}
void WorkerThread::run(void)
{
    //获取线程的ID
    unsigned long threadId =
        (unsigned long)currentThreadId();
    while(1){
        for(int i=1;i<100;i++){
            qDebug("id=%lu,i=%d",
                   threadId,i);
            msleep(300);
        }
    }
}











#include "threaddialog.h"
#include "ui_threaddialog.h"

ThreadDialog::ThreadDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ThreadDialog)
{
    ui->setupUi(this);
}

ThreadDialog::~ThreadDialog()
{
    delete ui;
}
//开始按钮对应的槽函数
void ThreadDialog::on_startButton_clicked()
{
    //开启线程,run函数将在子线程中执行
    threadA.start();
    threadB.start();
    ui->startButton->setEnabled(false);
    ui->stopButton->setEnabled(true);
}
//停止按钮对应的槽函数
void ThreadDialog::on_stopButton_clicked()
{
    //终止正在执行的子线程
    threadA.terminate();
    threadA.wait();//回收线程资源
    threadB.terminate();
    threadB.wait();
    ui->startButton->setEnabled(true);
    ui->stopButton->setEnabled(false);
}







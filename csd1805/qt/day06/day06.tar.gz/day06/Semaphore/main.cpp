//生产者和消费者
#include <QThread>
#include <QCoreApplication>
#include <QSemaphore>

const int DataSize = 20;//要生产的产品总量
const int BufferSize = 5;//仓库大小
int buf[BufferSize];//仓库
//控制生产者的信号量
QSemaphore freeSpace(BufferSize);
//控制消费者的信号量
QSemaphore usedSpace(0);
//生产者线程
class threadProducer:public QThread{
protected:
    void run(){
        for(int i=0;i<DataSize;i++){
            freeSpace.acquire();//P:-1
            buf[i%BufferSize] = i+1;
            qDebug("producer:%d",
                   buf[i%BufferSize]);
            usedSpace.release();//V:+1
        }
    }
};
//消费者线程
class threadConsumer:public QThread{
protected:
    void run(void){
        for(int i=0;i<DataSize;i++){
            usedSpace.acquire();//P:-1
            qDebug("consumer:%d",
                   buf[i%BufferSize]);
            freeSpace.release();//V:+1
            msleep(100);
        }
    }
};
int main(int argc,char** argv)
{
    //创建无gui界面的应用程序
    QCoreApplication app(argc,argv);

    threadProducer producer;
    threadConsumer consumer;
    producer.start();
    consumer.start();

    producer.wait();
    consumer.wait();

    return 0;
}










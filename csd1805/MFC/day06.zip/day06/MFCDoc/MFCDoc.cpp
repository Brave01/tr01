#include <afxwin.h>
#include <afxext.h>
#include "resource.h"

// �ĵ���
class CMyDoc:public CDocument
{
public:
	CMyDoc()
	{
		m_strData="Hello World";
	}
	CString m_strData;
	DECLARE_MESSAGE_MAP()
protected:
	afx_msg void OnTest();
};
BEGIN_MESSAGE_MAP(CMyDoc,CDocument)
	ON_COMMAND(ID_TEST,OnTest)
END_MESSAGE_MAP()
void CMyDoc::OnTest()
{
	AfxMessageBox("CMyDoc::OnTest");
}
// ��ͼ��(֧�ֶ�̬����)
class CMyView:public CEditView
{
	DECLARE_DYNCREATE(CMyView)
public:
	virtual void OnInitialUpdate( );

};
void CMyView::OnInitialUpdate()
{
	// 1 ��ȡ����ͼ�������ĵ�
	CMyDoc * pDoc=(CMyDoc*)GetDocument();
	// 2 ���ĵ������ݷŵ���ͼ��������ʾ
	SetWindowText(pDoc->m_strData);

}

IMPLEMENT_DYNCREATE(CMyView,CEditView)

class CMyFrameWnd:public CFrameWnd
{
};
class CMyWinApp:public CWinApp
{
public:
	virtual BOOL InitInstance();
};
CMyWinApp theApp;
BOOL CMyWinApp::InitInstance()
{
	CMyFrameWnd* pFrame=new CMyFrameWnd;
	CCreateContext cxt;
	cxt.m_pCurrentDoc = new CMyDoc;
	cxt.m_pNewViewClass = RUNTIME_CLASS(CMyView);
	pFrame->LoadFrame(IDR_MENU1,WS_OVERLAPPEDWINDOW,NULL,&cxt);
	pFrame->InitialUpdateFrame(NULL,TRUE);
	m_pMainWnd = pFrame;
	m_pMainWnd->ShowWindow(SW_SHOW);
	m_pMainWnd->UpdateWindow();
	return TRUE;
	
}
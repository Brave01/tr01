#include <stdio.h>
#include <afxwin.h>

// �ļ���д����
void TestFile()
{
	CFile file;
	try
	{
		// 1 �½����ߴ��ļ�
		file.Open("d:/mfcFile.txt",CFile::modeCreate|CFile::modeReadWrite);
		// 2 д����
		char szWrite[]="Hello World";
		file.Write(szWrite,strlen(szWrite));
		// ������
		file.SeekToBegin();
		char szRead[256]={0};
		int nRead=file.Read(szRead,256);
		printf("%d,%s\n",nRead,szRead);

		// 3 �ر�
		file.Close();
	}
	catch (CFileException* e)
	{
		// �쳣����
	}

}
// �ļ�����
void UseFileFind(CString strPath)
{
	CFileFind find;
	BOOL bRet=find.FindFile(strPath+"/*.*");
	while (bRet)
	{
		bRet = find.FindNextFile();
		strPath=find.GetFilePath();
		if(!find.IsDots())
		{
			if (find.IsDirectory())
			{
				printf("[%s]\n",strPath);
				UseFileFind(strPath);
			} 
			else
			{
				printf("%s\n",strPath);
			}
		}
	}
	// ��������
	find.Close();

}


int main()
{
	//TestFile();
	UseFileFind("e:/mfc");
	return 0;
}
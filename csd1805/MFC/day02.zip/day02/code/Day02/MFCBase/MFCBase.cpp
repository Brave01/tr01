#include <afxwin.h>
// 2.��ܴ�����
class CMyFrameWnd:public CFrameWnd
{
protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs );
	virtual LRESULT WindowProc(UINT message,WPARAM wParam,LPARAM lParam );
};
LRESULT CMyFrameWnd::WindowProc(UINT message,WPARAM wParam,LPARAM lParam )
{
	switch(message)
	{
	case WM_CREATE:
		AfxMessageBox("OnCreate");
		break;
	case WM_PAINT:
		PAINTSTRUCT ps = {0};
		HDC hdc = ::BeginPaint(m_hWnd,&ps);
		::TextOut(hdc,100,100,"Hello",5);
		::EndPaint(m_hWnd,&ps);
		break;
	}
	return CFrameWnd::WindowProc(message,wParam,lParam);
}
BOOL CMyFrameWnd::PreCreateWindow(CREATESTRUCT& cs )
{
	cs.x = 10;
	cs.y = 10;
	cs.cx = 500;
	cs.cy = 300;
	return CFrameWnd::PreCreateWindow(cs);
}
// 1.Ӧ�ó�����
class CMyWinApp:public CWinApp
{
public:
	virtual BOOL InitInstance();
};
CMyWinApp theApp;
BOOL CMyWinApp::InitInstance()
{
	CMyFrameWnd* pFrame = new CMyFrameWnd;
	pFrame->Create(NULL,"MFCBase");
	m_pMainWnd = pFrame;
	m_pMainWnd->ShowWindow(SW_SHOW);
	m_pMainWnd->UpdateWindow();
	return true;
}
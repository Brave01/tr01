#include <afxwin.h>
// 2. ��ܴ�����
class CMyFrameWnd:public CFrameWnd
{
protected:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnTest();
	afx_msg void OnTestRange(UINT nID);
	afx_msg void OnEnChange();
DECLARE_MESSAGE_MAP()
};
BEGIN_MESSAGE_MAP(CMyFrameWnd,CFrameWnd)
	ON_WM_CREATE()
	ON_COMMAND(1000,OnTest)
	ON_COMMAND_RANGE(1001,1003,OnTestRange)
	ON_EN_CHANGE(1005,OnEnChange)
END_MESSAGE_MAP()
void CMyFrameWnd::OnEnChange()
{
	CWnd* pWnd = GetDlgItem(1005);
	CString strText;
	pWnd->GetWindowTextA(strText);
	AfxMessageBox(strText);
}
void CMyFrameWnd::OnTestRange(UINT nID)
{
	CString strID;
	strID.Format("%d\n",nID);
	AfxMessageBox(strID);
}
void CMyFrameWnd::OnTest()
{
	AfxMessageBox("������˲��԰�ť");
}
int CMyFrameWnd::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	::CreateWindow("BUTTON","����",WS_CHILD|WS_VISIBLE,
		100,100,100,40,m_hWnd,(HMENU)1000,AfxGetInstanceHandle(),NULL);
	
	::CreateWindow("BUTTON","����1",WS_CHILD|WS_VISIBLE,
		100,200,100,40,m_hWnd,(HMENU)1001,AfxGetInstanceHandle(),NULL);
	::CreateWindow("BUTTON","����2",WS_CHILD|WS_VISIBLE,
		100,300,100,40,m_hWnd,(HMENU)1002,AfxGetInstanceHandle(),NULL);
	::CreateWindow("BUTTON","����3",WS_CHILD|WS_VISIBLE,
		100,400,100,40,m_hWnd,(HMENU)1003,AfxGetInstanceHandle(),NULL);

	::CreateWindow("EDIT","",WS_CHILD|WS_VISIBLE|WS_BORDER,
		300,100,100,100,m_hWnd,(HMENU)1005,AfxGetInstanceHandle(),NULL);
	return 0;
}
// 1. Ӧ�ó�����
class CMyWinApp:public CWinApp
{
public:
	virtual BOOL InitInstance();
};
CMyWinApp theApp;
BOOL CMyWinApp::InitInstance()
{
	CMyFrameWnd* pFrame = new CMyFrameWnd;
	pFrame->Create(NULL,"MFCMsgProc");
	m_pMainWnd = pFrame;
	m_pMainWnd->ShowWindow(SW_SHOW);
	m_pMainWnd->UpdateWindow();
	return TRUE;
}
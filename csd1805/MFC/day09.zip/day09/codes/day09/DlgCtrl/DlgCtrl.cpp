#include <afxwin.h>
#include "resource.h"


class CMyDlg:public CDialog
{
public:
	CMyDlg():CDialog(IDD_DIALOG1){}
	virtual BOOL OnInitDialog( );
	virtual void DoDataExchange( CDataExchange* pDX );
	virtual void OnOK();
	CWnd m_wndOK;
	CString m_strEdit;
};
void CMyDlg::OnOK()
{
	UpdateData(TRUE);
	AfxMessageBox(m_strEdit);
}
void CMyDlg::DoDataExchange( CDataExchange* pDX )
{
	DDX_Control(pDX,IDOK,m_wndOK);
	DDX_Text(pDX,IDC_EDIT1,m_strEdit);
}
BOOL CMyDlg::OnInitDialog()
{
	// ���ȵ��ø���ĳ�ʼ������
	CDialog::OnInitDialog();
	
	// �ؼ��ĳ�ʼ��
	/*
	CWnd* pWnd=GetDlgItem(IDOK);
	pWnd->SetWindowText("����");
	pWnd->MoveWindow(0,0,100,100);
	*/
	m_wndOK.SetWindowText("����");
	m_wndOK.MoveWindow(0,0,100,40);

	m_strEdit="Hello World";
	UpdateData(FALSE);



	return TRUE;
}
class CMyWinApp:public CWinApp
{
public:
	virtual BOOL InitInstance();
};
CMyWinApp theApp;
BOOL CMyWinApp::InitInstance()
{
	CMyDlg dlg;
	m_pMainWnd=&dlg;
	dlg.DoModal();
	return TRUE;
}
/*
   [练习]
      输入一个成绩   0 - 100
             100 - 80  等级A
             79  - 60  等级B
             59  - 0   等级C
      输出等级,最好考虑输入错误成绩的情况
[练习]
       健康指数  healthRate = w 70kg /(h*h)  1.80
       18<=h<=25    好身材
       25< h<=30    有点小胖
       30< h<=35    少吃点,减肥
       35< h<=40    中午别吃了
       40< h        拨120

  输入 0 -100 的成绩 如果 用户输入不对,重新输入,直到输对为止
*/
#include <stdio.h>
int main(){
    int score = 0;
    //1. 输入一个成绩
    printf("输入一个成绩:");
    scanf("%d",&score);

    if(score <0 || score>100)
    {
        printf("成绩不对\n");
    }
    else if(score >= 80)
    {
        printf("A\n"); 
    }
    else if(score >= 60)

    {
        printf("B\n"); 
    }
    else
    {
        printf("C\n"); 
    }

    return 0;
}

/*
 * 输入一个整数 输出其绝对值
 * |2| = 2
 * |-2| = 2
 * [练习]
 *     输入一个字母(大/小)  
 *     输出该字母的大写
 */
#include <stdio.h>
int main(){
    int num = 0;

    printf("请输入一个数:");
    scanf("%d",&num);

    if(num < 0)
    {
        num = -num ;
    }

    printf("|num| = %d\n",num);
    return 0;
}

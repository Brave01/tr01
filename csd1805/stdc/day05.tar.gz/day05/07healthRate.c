/*
[练习]
       健康指数  healthRate = w 70kg /(h*h)  1.80
       18<=h<=25    好身材
       25< h<=30    有点小胖
       30< h<=35    少吃点,减肥
       35< h<=40    中午别吃了
       40< h        拨120
*/
#include <stdio.h>
int main(){

    float w = 0;
    float h = 0;

    //1. 输入身高体重
    printf("输入身高:");
    scanf("%f",&h);

    printf("输入体重:");
    scanf("%f",&w);

    float healthRate = w /(h*h);

    if(healthRate <=25)
    {
        printf("身材不错!\n");
    }
    else if(healthRate <=30)
    {
        printf("有点小胖\n"); 
    }
    else if(healthRate <=35)
    {
        printf("少吃点,减肥\n"); 
    }
    else if(healthRate <=40)
    {
        printf("中午别吃了\n"); 
    }

   else
    {
        printf("拨120\n"); 
    }

    return 0;
}

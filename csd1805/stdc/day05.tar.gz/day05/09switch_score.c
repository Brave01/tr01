/*
 * 用switch case 实现判断 成绩的等级
 */
#include <stdio.h>
int main(){
    int score = 0;
    printf("输入一个成绩");
    scanf("%d",&score);

    switch(score/10)
    {
        case 10 : 
        case  9: 
        case  8: 
            printf("A\n");
            break;

        case  7: 
        case  6: 
            printf("B\n");
            break;

        default:
            printf("C\n");
            break;



    
    }
    return 0;
}

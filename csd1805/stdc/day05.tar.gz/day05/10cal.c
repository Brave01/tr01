/*
 *  [练习 计算器] 可以实现 + - * / %
             输入 一个  表达式   20+4  
             程序输出表达式的 结果 24 
*/

#include <stdio.h>

int main(){
    int a = 0;
    char op = 0;
    int b = 0;
    printf("输入表达式:");
    scanf("%d%c%d",&a,&op,&b);

    switch(op)
    {
    
        case '+':
            printf("%d %c %d = %d\n",a,op,b,a+b);
            break;

        default:
            printf("运算符不对\n");
            break;
    }
    return 0;
}

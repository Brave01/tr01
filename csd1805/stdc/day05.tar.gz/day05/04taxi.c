/*
 * [练习]
 *    已知北京出租车计费方式如下:
 *        前3公里     10元
 *        3公里后每增加1公里  2元
 *
 *        编程 实现输入公里数(int)  输出出租车费
 */
#include <stdio.h>

int main(){

    int mileage = 0;
    int money = 0;

    //1. 输入乘车里程
    printf("输入乘车里程:");
    scanf("%d",&mileage);

    if(mileage<=3) //起步价
    {
        money = 10;
    }
    else  //大于3公里
    {
        money =  (mileage - 3)*2 + 10;
    }

    printf("出租车费是%d\n",money);

    return 0;
}




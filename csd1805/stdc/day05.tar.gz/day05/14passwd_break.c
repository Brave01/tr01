/*
 * 要求用户输入密码
 * 直到输对为止
 * [练习] 编码实现 i从1 一直往上加,直到加到和大于1000,
 * 打印出i是哪个数
 */

#include <stdio.h>

int main(){
    int passwd = 0;


    for(;;) //死循环
    {
        printf("请输入密码:");
        scanf("%d",&passwd);

        if(passwd == 123456)
            break;
    }

    printf("密码正确\n");
    return 0;
}

/*
 * [练习]
 *     打印输出 a-z  每行输出一个字符
 */

#include<stdio.h>

int main(){
    
    for(char c='a';c<='z';c++)
    {
        printf("%c\n",c); 
    
    }
    return 0;
}





/*
 * 输入数字 1 - 7
 * 输出 对应的星期几调休
 */
#include <stdio.h>

int main(){

    int num = 0;
    //输入数字
    printf("输入调休的数字:");
    scanf("%d",&num);

    switch(num)
    {
        case 1:
            printf("周一休息\n");    
            break;

        case 2:
            printf("周二休息\n");    
            break;

        case 3:
            printf("周三休息\n");    
            //break;

        case 4:
            printf("周四休息\n");    
            //break;

        case 5:
            printf("周五休息\n");    
            //break;

        case 6:
            printf("周六休息\n");    
            break;

        case 7:
            printf("周日休息\n");    
           // break;

        default:
            printf("你输入的数字不对\n");
            break;
    }
    return 0;
}





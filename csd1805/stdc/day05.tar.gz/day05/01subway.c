/*
 * 根据公交卡余额
 * 执行分支语句
 * [练习]
 *    已知北京出租车计费方式如下:
 *        前3公里     10元
 *        3公里后每增加1公里  2元
 *
 *        编程 实现输入公里数(int)  输出出租车费
 *
 */
#include <stdio.h>

int main(){

    int money = 0;
    //1. 输入公交卡的余额
    printf("输入您现在公交卡的余额:");
    scanf("%d",&money);

    //money>=3?printf("打开闸机\n"):printf("请充值\n");
    if(money>=3)
    {
         printf("打开闸机\n");
    }
    else
    {
        printf("请充值\n");
    }

    return 0;
}

/*
 * 要求用户输入密码
 * 直到输对为止
 * [练习] 编码实现 i从1 一直往上加,直到加到和大于1000,打印出i是哪个数
 * 1+2+3+4+5+6.....+n>=1000 结束循环
 * 输出n  是哪个数字
 */

#include <stdio.h>

int main(){
    int sum = 0;
    int i = 1;

    //for(;;) //死循环
    for(i=1;sum<1000;i++) //死循环
    {
        sum =sum + i;
    }

    printf("i = %d\n",i);
    return 0;
}

/*
 * [练习]
 *     输入一个字母(大/小)  
 *     输出该字母的大写
 */
#include <stdio.h>
int main(){
    char c = 0;

    printf("请输入一个字符:");
    scanf("%c",&c);

    //if(c>=97 && c <= 122)
    if(c>='a' && c <= 'z')
    {
        c = c -32;
    }

    printf("大写字母为 = %c\n",c);
    return 0;
}

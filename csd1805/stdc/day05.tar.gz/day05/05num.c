/*

   输入一个数 判断这个数 是 
           0  负数  正数
   [练习]
      输入一个成绩   0 - 100
             100 - 80  等级A
             79  - 60  等级B
             59  - 0   等级C
      输出等级,最好考虑输入错误成绩的情况
*/
#include <stdio.h>
int main(){
    int num = 0;

    //1. 输入一个数
    printf("输入一个数:");
    scanf("%d",&num);

    if(num >0)
    {
        printf("num 是正数\n"); 
    }
    else
    {
        if(num == 0)
        {
            printf("num 是0\n"); 
        }
        else
        {
            printf("num 是负数\n"); 
        }
    }

    return 0;
}

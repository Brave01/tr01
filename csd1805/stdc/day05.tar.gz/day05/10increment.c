/*
 * ++ -- 运算
 * 打印10-1000
 * [练习]
 *       输出 1-20 的平方(循环)
 */
#include <stdio.h>
int main(){

    int i = 10;
    for(i = 10;i<101;)
    {
        printf("i = %d\n",i++); //10
    }
    return 0;
}

/*
   [练习]
      输入一个成绩   0 - 100
             100 - 80  等级A
             79  - 60  等级B
             59  - 0   等级C
      输出等级,最好考虑输入错误成绩的情况
  输入 0 -100 的成绩 如果 用户输入不对,重新输入,直到输对为止
*/
#include <stdio.h>
int main(){
    int score = 0;
    //1. 输入一个成绩
    for(score = -1;score <0 || score >100;)
    {
        printf("输入一个成绩:");
        scanf("%d",&score);
    }

    if(score >= 80)
    {
        printf("A\n"); 
    }
    else if(score >= 60)

    {
        printf("B\n"); 
    }
    else
    {
        printf("C\n"); 
    }

    return 0;
}

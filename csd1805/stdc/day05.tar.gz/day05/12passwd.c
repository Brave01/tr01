/*
 * 要求用户输入密码
 * 直到输对为止
 */

#include <stdio.h>

int main(){
    int passwd = 0;

    for(;passwd != 123456;)
    {
        printf("请输入密码:");
        scanf("%d",&passwd);
    }

    printf("密码正确\n");
    return 0;
}

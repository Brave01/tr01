/*
 * 输入秒数 输出时间
 */
#include <stdio.h>

int main(){

    int hour = 0;
    int min = 0;
    int sec = 0;

    int second = 0;
    printf("请输入一个秒数:");
    scanf("%d",&second);

    hour = second / 3600;
    min = (second -hour*3600)/60;  //运算优先级
    sec = second % 60; 

    printf("%d:%2d:%2d\n",hour,min,sec); //0:2:30
    return 0;
}








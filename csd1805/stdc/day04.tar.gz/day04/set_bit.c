/*
 * 在某一些嵌入式设备中
 * 对一个bit 位置1 
 * 可以输出高电平
 */

#include <stdio.h>

int main(){
    int reg = 0xaaaaaa0f;

    //其他bit不变
    //设置 bit[6] = 1; 第七个引脚输出高电平
    //reg = reg | 0x40;//0100 0000
    //                   1011->b
    reg = reg | 1<<6;
    printf("reg = 0x%x\n",reg); //0x4f


    //将bit[6] = 0 ；第七个引脚输出低电平
    reg = reg & 0xffffffbf;
    reg = reg & ~(1<<6);   //0100 0000
                    //11111111011 1111
    printf("reg = 0x%x\n",reg); //0x0f
    return 0;
}










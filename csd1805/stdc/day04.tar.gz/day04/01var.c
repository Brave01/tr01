/*
 * 类型不一致的赋值
 */

#include <stdio.h>

int main(){
    //int i = 0xfff1f210; 
    int i = 300; 
    char c = 0x1;
   

    printf("i = 0x%x\n",i);
    printf("c = 0x%x\n",c);

    //  c = i;  //大小不一致
    i = 3.14;

    printf("i = 0x%x\n",i); //0xffff ff10
    printf("c = 0x%x\n",c); //0x10?0xff


    return 0;
}

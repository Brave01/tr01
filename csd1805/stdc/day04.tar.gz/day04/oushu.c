/*
 * 输入一个整数
 * 如果是偶数 输出0
 * 如果是奇数 输出1
 * [输入一个0-100之间的数,如该用户输入不对，提示用户输入错误，如果是0-100输出 正确]
 */
#include <stdio.h>

int main(){
    int r = 0;
    int num = 0;
    printf("输入一个整数:");
    scanf("%d",&num);
    //r = num%2?1:0;
    //printf("偶数0,奇数1 r=%d\n",r);
    //num%2?printf("奇数\n"):printf("偶数\n");

    num>=0 && num<=100?printf("正确\n"):printf("错误\n");
    return 0;
}







/*面试题
 */
#include <stdio.h>
int main(){

    int i = 10; 
    i+=i-=100;
    //i+=i-=100;==>i = i - 100;i = -90
    //i+=i; //i=i+i; 
    printf("i = %d\n",i);
    return 0;
 }   //i = ?



/*
 * ++ -- 运算
 * 打印10-100
 */
#include <stdio.h>
int main(){

    int i = 10;

    printf("i = %d\n",i++); //11 i = i+1
    printf("i = %d\n",i++); //10
    //10++; //10 = 10 + 1; ++ 运算对能变量操作

    printf("i = %d\n",i++); //12
    printf("i = %d\n",i++); //13
    printf("i = %d\n",i++); //14
    printf("i = %d\n",i++); //15

    return 0;
}

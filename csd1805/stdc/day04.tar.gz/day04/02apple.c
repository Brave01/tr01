/*
 * 分苹果
 */
#include <stdio.h>

int main()
{
    int num = 0;
    //1.输入苹果数
    printf("输入苹果数:");
    scanf("%d",&num);

    //2.开始计算
    int average = 0;
    average = num / 7;

    int left = 0;
    left = num % 7;

    
    //3.输出结果
    printf("平均每个小朋友分 %d\n",average);
    printf("还剩下%d\n",left);

    return 0;
}









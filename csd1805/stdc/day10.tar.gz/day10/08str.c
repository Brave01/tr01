/*
 * 字符串比较运算   > < =
 *  strcmp
 *  [练习]
 *     1.在主函数中声明一个 passwd 字符数组,用来存储用户的密码.
 *     char passwd[12] = {0};
 *
 *     2.编写一个void setPasswd(char *passwd);
 *     传入的参数 是主函数中保存密码的字符数组passwd
 *     功能  设置用户密码
 *
 *     3.编写一个int login(const char *passwd)
 *           传入的参数 char *passwd  是主函数保存密码的数组
 *           功能   三次输入机会  输入正确返回1
 *                   错误返回 0
 *     4.主函数 先调用设置密码的函数
 *              再调用登录login函数
 */

#include <stdio.h>
#include <string.h>
int main(){

    char *pa = "abcd";
    char *pb = "ABCD";

    int a = strcmp(pa,pb);  //pa == pb 返回 0
                            //pa > pb  返回 1
                            //pa < pb  返回 -1
    printf("a = %d\n",a);

    return 0;
}

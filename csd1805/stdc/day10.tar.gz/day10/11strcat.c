/*
 * strcat 将第二个参数的字符串　连接到第一个指针指向的内存中
 */
#include <stdio.h>
#include <string.h>

int main(){
   char pa[20]="hello";
   char pb[] = "world";

   strcat(pa," ");
   strcat(pa, pb);
   printf("pa = [%s]\n",pa);

   memset(pa,0,20);  //对pa的20个元素设置为0

   printf("pa = [%s]\n",pa); 
    return 0;
}

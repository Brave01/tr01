/*
 * const  变量
 */
#include <stdio.h>

int main(){
    //写法1
    //const int i = 0;  //i变量只读
    //写法2
    int const i = 0;  //i变量只读
    int const pi = 3.1415927;  //i变量只读

    s=pi*r1*r1;   //
    s=pi*r2*r2;


    i = 5;
    printf("i = %d\n",i); //5
    return 0;
}

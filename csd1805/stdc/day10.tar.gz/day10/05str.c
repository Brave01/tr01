/*
 * 字符串 常量
 */

#include<stdio.h>

int main(){

    char *str ="abcdef"; //将字符串常量的地址赋值给字符指针str
                         //str 指向字符串起始位
    char a[13]="hello world!";
    /*
    while(*str != 0)
    {
        //printf("*str = %c\n",*str);
        printf("%c",*str);
        str++;
    }
    printf("\n");
    */
   //*str = 'A'; 

    for(int i = 0;i<13;i++)
    {
        printf("%c",a[i]); 
    }
    printf("\n");

    a[0] = 'H';
    
    for(int i = 0;i<13;i++)
    {
        printf("%c",a[i]); 
    }
    printf("\n");


    return 0;
}

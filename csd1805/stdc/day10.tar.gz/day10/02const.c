/*
 *  const  常指针
 */

#include<stdio.h>

int main(){
    int a[5] = {5,4,3,2,1};
    int b = 30;
    int c = 0;

    int * const pb = &b;//pb 永远指向b, pb 声明为只读
    //pb = &c;  //常指针 不能赋值
    //pb++;     //pb = pb + 1;
    int* pa = a; //pa  指向 a数组
    //pa++;
    a++;   //a = a+1;  指针变量与数组第一个区别: 数组名  是一个常指针  
    
    //printf("*pa = %d\n",*pa); //4

    //printf("*(pb+1) = %d\n",*(pb+1));


    return 0;
}

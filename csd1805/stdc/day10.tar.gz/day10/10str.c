/*
 * strlen 计算字符串长度
 * 只打印字符的个数,不包括\0
 *
 * 谈一谈　strlen  和　sizeof 的区别
 */

#include<stdio.h>
#include <string.h>

int main(){
    char * str = "hello world!";
    printf("strlen(str) = %d\n",strlen(str));
    return 0;
}

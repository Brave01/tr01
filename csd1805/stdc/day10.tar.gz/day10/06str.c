/*
 * 字符串 输入输出
 */

#include<stdio.h>

int main(){

    char *str ="abcdef"; //将字符串常量的地址赋值给字符指针str
                         //str 指向字符串起始位
                         //字符串常量  后面默认加\0
    char a[]="hello world!"; //初始化 系统会加\0
    str = a;
    
    printf("str = %s\n",str);
    printf("a = %s\n",a);
    printf("sizeof(a) = %d\n",sizeof(a)); //13

    /*
    scanf("%s",str); // 
    printf("str = %s\n",str);
    */
   
    //scanf("%s",a); // 输入字符串 遇到有 空格 或者 回车会结束
    gets(a); //不要超过数组长度
    printf("a = %s\n",a);

    return 0;
}

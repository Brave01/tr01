/*
 * 字符串 "赋值"
 */
#include <string.h>
#include <stdio.h>

int main(){

    char a[20] = {"01234567899abcdef"}; //20元素都是0
    char *pa = "hello world!";
    char *pb = NULL;

    pb = pa; //pa  pb  都指向 字符串常量的地址
    //a = pa;   //数组名不能修改

    /*
    int i = 0;
    while(pa[i])
    {
        a[i]  = pa[i];
        i++;
    }
    */
    strcpy(a,pa); //将pa指向的字符串 赋值到a数组
    //strcpy(pa,a);// 不可以,pa指向字符串常量的地址
    printf("pa = %s\n",pa);
    printf("a = %s\n",a); 
    /*
    for(int i = 0;i<20;i++)
    {
        printf("%c",a[i]);
    }
    printf("\n");
    */
    return 0;
}




/*
 *  const  指针
 *    作用 : 防止通过指针变量 修改 指向变量的内容
 *           仅用于读指向的内容
 */

#include<stdio.h>

int main(){
    int a[5] = {5,4,3,2,1}; //a 永远不变
    int b = 30;
    int c = 20;

    //int * const pb = &b;//pb 永远指向b, pb 声明为只读
    
    //const int * pb = &b; //pb指向变量的值不可修改
                         //不能通过pb 间接修改 b的值
    int const * pb = &b; //pb指向变量的值不可修改,跟上面代码同

    //const int * const pb = &b;
  
    printf("*pb = %d\n",*pb); //30


    //*pb = 50; //不能修改 ,编译错误,不允许通过pb修改变量b的值
    b = 50;   //可以赋值成功
    //pb = &c;
    printf("*pb = %d\n",*pb); //30

    return 0;
}

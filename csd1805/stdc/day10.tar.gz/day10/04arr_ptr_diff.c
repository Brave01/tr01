/*
 * 数组名 和指针的区别
 *     1. 数组名 是常指针,不可修改
 *     2. sizeof 计算数组名 为数组的所有字节数
 *        sizeof 计算指针变量 为机器字宽度
 *     3. 指针可以作为 函数的返回值类型,数组不行
 */

#include <stdio.h>

int * func(){


}
int main(){

    int a[5]={0};
    int *pa = a;
  //20
  printf("sizeof(a) = %d\n",sizeof(a));

  //4
  printf("sizeof(pa) = %d\n",sizeof(pa));


    return 0;
}

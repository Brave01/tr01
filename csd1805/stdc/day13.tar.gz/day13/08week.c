/*
 * 输入数字 1 - 7
 * 输出 对应的星期几调休
 */
#include <stdio.h>
enum WEEK {MON = 1,TUE,WED,THU,FRI,SAT,SUN};

int main(){

    //int num = 0;
    enum WEEK  num = 0;
    //输入数字
    printf("输入调休的数字:");
    scanf("%d",(int *)&num);

    switch(num)
    {
        case MON:
            printf("周一休息\n");    
            break;

        case TUE:
            printf("周二休息\n");    
            break;

        case WED:
            printf("周三休息\n");    
            break;

        case THU:
            printf("周四休息\n");    
            break;

        case FRI:
            printf("周五休息\n");    
            break;

        case SAT:
            printf("周六休息\n");    
            break;

        case SUN:
            printf("周日休息\n");    
            break;

        default:
            printf("你输入的数字不对\n");
            break;
    }
    return 0;
}





/*
 * 结构体 里的成员是结构体
 */

#include <stdio.h>

int main(){
    struct Score{
        int stdc;
        int unixc;
        int cpp;
        char qt;
    };


typedef struct student{
        char name[8]; 
        struct Score score;
        //struct student s;  //结构体里不能放该结构体的变量,
        struct student* s; //可以是该结构体类型的指针
        int age;
    }Student;


    Student s;

    printf("sizeof(s) = %d\n",sizeof(s)); //24

    s.score.stdc = 90;
    s.score.unixc = 92;
    s.score.cpp = 93;

    printf("stdc = %d\n",s.score.stdc);
    printf("unixc = %d\n",s.score.unixc);
    printf("cpp = %d\n",s.score.cpp);


    return 0;
}

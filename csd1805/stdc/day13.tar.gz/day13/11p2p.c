/*
 * 二级指针的作用
 */

#include <stdio.h>
void func(int* i)
{
    *i = 30;
}
void func2(int** pi)
{
    *pi = NULL;
}

int main(){
    int i = 20;
    int *pi = &i;
#if 0
    func(&i); //scanf("%d",&i);
    printf("i = %d\n",i); //30
#endif

    printf("pi = %p\n",pi);

    func2(&pi); //func2 功能将pi 指向NULL
               //如果要修改传入变量的内容,必须是该变量的指针

    printf("pi = %p\n",pi);


    return 0;
}

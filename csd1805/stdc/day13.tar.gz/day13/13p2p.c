/*
 *  二级指针使用案例
 *  操作字符串数组
 *
 *  写一个程序,预测一下世界杯冠军
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main(){
    int i = 0;
    char *str[5] = {"巴西","葡萄牙","比利时","法国","德国"};
    char **pstr = str;

    for(i = 0;i<5;i++)
    {
        printf("%s\n",*(pstr+i));
    }

    srand(time(0));
    i = rand()%5;

    printf("我预测的世界杯冠军是 %s\n", *(pstr+i));
    return 0;
}

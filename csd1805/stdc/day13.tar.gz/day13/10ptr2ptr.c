/*
 * 指向指针的指针
 * 二级指针
 */

#include <stdio.h>

int main(){
    int a = 20;
    int *pa = &a; //pa 指向 a变量  pa 保存a 变量的地址
    int **ppa = &pa; //ppa 是二级指针,包保存指针变量pa的地址


    printf("*pa = %d\n",*pa); //通过pa 间接访问 a的值
    printf("**ppa = %d\n",*(*ppa)); //通过ppa 间接访问 a的值

    return 0;
}

/*
 * 指针回顾
 */

#include <stdio.h>

int main(){
    int arr[5];
    char *pc = (char *)arr;
    int *pa = arr;

    printf("arr 地址 = %p\n",arr);
    //printf("arr++ 地址 = %p\n",arr++);

    printf("pc 保存的地址 = %p\n",pc);
    pc++; //pc 为char +1个字节
    printf("pc++ 保存的地址 = %p\n",pc);

    printf("pa 保存的地址 = %p\n",pa);
    pa++; //pa 为int  +4个字节
    printf("pa++ 保存的地址 = %p\n",pa);



    return 0;
}

/*
 * 结构体数组
 */

#include <stdio.h>

int main(){

typedef struct {
        char name[8]; 
        int score;
        int age;
    }Student;

    Student s;
    Student as[20];

    printf("sizeof(s) = %d\n",sizeof(s)); //16

    printf("&as[4] = %p\n",&as[4]);
    printf("&as[5] = %p\n",&as[5]);


    return 0;
}




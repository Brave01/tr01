/*
 * 枚举类型的使用
 */
#include <stdio.h>
int main(){
  
   enum   SEASON{Spring =6,Summer,Autumn=10,Winter};
                 // 6        7      10        11
   enum SEASON s; //定义一个枚举变量s

   //s = Summer;
   s = 0;  //c 主要是代码易读,C++ 更严格 

   if(Summer == s)
   {
        printf("现在是夏天\n"); 
   }

   printf("Spring = %d\n",Spring);
   printf("Summer = %d\n",Summer);
   printf("Autumn = %d\n",Autumn);
   printf("Winter = %d\n",Winter);

   return 0;
}

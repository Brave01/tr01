#ifndef __SCORE_H__
#define __SCORE_H__
typedef enum {A,B,C}LEVEL;
typedef enum {LEV,INT,DOUBLE}SCORE_TYPE;

typedef union  {
    LEVEL  lev_score;
    int   i_score;
    double d_score;
}UN_SCORE;

typedef struct{
    SCORE_TYPE st; 
    UN_SCORE   us;
}Score;  //成绩的类型

void score_scan(Score *s);
void score_print(Score s);

#endif //__SCORE_H__

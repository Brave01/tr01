/*
 * 二级指针练习
 * [练习]
 *     从键盘上输入两个整数,分别保存在a,b变量中,编写一个func函数,通过调用函数实现pmax 指针指向 保存较大值的变量
 */
#include <stdio.h>
void func(int *pa,int *pb,int **ppmax);
void func(int *pa,int *pb,int **ppmax)
{
    if(*pa>*pb) //if(a>b)
        *ppmax = pa;
    else
        *ppmax = pb;

}

int main(){
    int a = 0;
    int b = 0;
    int *pmax = NULL;

    printf("请输入两个数");
    scanf("%d%d",&a,&b);

    func(&a,&b,&pmax); //注意func 函数原型应该怎么写

    printf("*pmax = %d\n",*pmax);
    return 0;
}

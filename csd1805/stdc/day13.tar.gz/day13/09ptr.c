/*
 * 悬空指针
 */

#include <stdio.h>

int * func()
{
    static int b = 20;
    int *pb = &b;
    return pb; //pb 是悬空的指针,所指向的b 在函数结束后,已经被释放了,b的存储空间 可以被其他函数使用
               //pb 之所以悬空 因为 b 是auto 变量
               // 可以返回 字符串常量 的地址

}
int main(){
    
    int a = 10;
    int *pa = NULL;

    pa = func();
    printf("a = %d\n",a); //该函数调用 使用了原来b的位置
    printf("*pa = %d\n",*pa);

    return 0;
}

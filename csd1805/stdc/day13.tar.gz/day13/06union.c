/*
 * 联合的使用
 */
#include <stdio.h>
int main(){

typedef union Score { //定义了一个联合类型 Score
        char level;
        int  i_score;
        double d_score;
      }Score;

     //union Score s;
     Score s;

    printf("sizeof(s) = %d\n",sizeof(s)); //8  即double类型的大小

     s.level = 'A'; // 或者
     printf("当前成绩是%c\n",s.level);
     printf("&s.level = %p\n",&s.level);

     s.i_score = 80;
     printf("当前成绩是%d\n",s.i_score);
     printf("&s.i_score = %p\n",&s.i_score);

     s.d_score = 80.8;
     printf("当前成绩是%lf\n",s.d_score);
     volatile
     printf("&s.d_score = %p\n",&s.d_score);

     return 0;
}

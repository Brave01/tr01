#include <stdio.h>

int main(){
    printf("祝大家六一快乐\n");
    return 0; 
}

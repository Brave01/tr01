/*
 * 在屏幕上打印一个三角形
 */
#include <stdio.h>

int main()
{
    /*
    printf("*\n");
    printf("* *\n");
    printf("* * *\n");
    printf("* * * *\n");
    printf("* * * * *\n");
    */
    printf("*\n* *\n* * *\n* * * *\n* * * * *\n");
    return 0;
}

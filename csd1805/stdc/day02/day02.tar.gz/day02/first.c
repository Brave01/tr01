#include <stdio.h>
int main(){
    printf("hello\n"); //   \n换行
    return 0; //返回 整数0
}

/*
 * printf 格式化输出
 */
#include <stdio.h>
int main()
{
    printf("%d\n",2+3); //%d  十进制格式转换
    return 0;
}

/*
 * 局部变量的 作用域
 */

#include<stdio.h>

int func();
int func()
{
    int a = 3;
    printf("func a = %d\n",a);
    return a;
}

int main(){
    int a = 5;
    int b = 6;

    printf("func() 返回值=%d\n",func());
    printf("main a=%d\n",a);

    if(a)
    {
        //int b = 4;
        printf("if b = %d\n",b);  //4
    }

    printf("b = %d\n",b+1);  //7
    return 0;
}

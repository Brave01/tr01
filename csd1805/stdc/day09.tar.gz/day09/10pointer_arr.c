/*
    数组  
    [练习]
        定义一个int a[5];  char c[5];
        分别用 打印出每个元素的地址 &a[0]

        int  *pa=a;
        char *pc=c;
              a[0],a[1],a[2],a[3],a[4]
        打印出  pa,pa+1,pa+2,pa+3,pa+4 的地址

              c[0],c[1],c[2],c[3],c[4]
        打印出  pc,pc+1,pc+2,pc+3,pc+4 的地址

        对照一下 指针打印的地址 跟用数据元素取地址打印的地址 是否一致

 */

#include <stdio.h>

void func(int b[]);
void func(int b[])
{
    for(int i = 0;i<5;i++)
    {
        b[i]  = i;
    } 
}

 int main(){
    int a[5] = {10,20,30,40,50};
    int *pa = a;

    for(int i = 0;i<5;i++)
    {
        //printf("*pa++=%d\n",*pa++); 
        //printf("*(pa+%d)=%d\n",i,*(pa+i)); //注意优先级
        //printf("pa[%d] = %d\n",i,pa[i]);
        //printf("*(a++)=%d\n",*(a++)); 
        //printf("*(a+%d)=%d\n",i,*(a+i)); 
        
    } 
   return 0; 
 }   





/*
 * 指针 的作用
 *        修改作用域范围外的的变量值
 *
 *  编写 一个  void swap(int *a,int *b);
 *      功能  实现 调用函数中两个局部变量值的交换
 *      用  main 函数调用测试
 *  printf("%d",i);
 *
 *  int i;
 *  scanf("%d",&i);
 */
#include <stdio.h>
void func(int *p);
void func(int *p)
{
     int *p2 = p; //将p1 传递过来的i变量地址赋值给p2;
                  //p2 保存着main 函数i变量的地址
    *p2 = 30;
    printf("*p2 = %d\n",*p2);
}
int main(){
    int *p1;  //p1 指向哪一个变量 不确定
    *p1 = 40; //有没有问题? 野指针
              //声明指针变量时进行初始化
              //初始化赋值为NULL
    int i = 20;
    //int *p1 = &i      //初始化为指向具体某个变量的地址
    //int *p1 = NULL;  // 赋初值 为 NULL

    p1 = &i; //p1 保存i变量的地址
    printf(" main func调用前 i = %d\n",i); //20
    func(p1);
    printf(" main func调用后 i = %d\n",i); //30
    return 0;
}







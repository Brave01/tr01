/*
 *  编写 一个  void swap(int *a,int *b);
 *      功能  实现 调用函数中两个局部变量值的交换
 *      用  main 函数调用测试
 *  printf("%d",i);
 *  scanf("%d",&i);
 */
#include <stdio.h>
//void swap(int a,int b);
void swap(int *a,int *b);
void swap(int *a,int *b) //a,b 是一个整形的指针变量
{
    int d = 0;
    int *c = &d; //定义一个c 整形指针变量 ,没有指向确定的变量
    *c = *a;
    *a = *b;
    *b = *c;

}
int main(){
    int a = 2;
    int b = 3;

    printf("a = %d,b = %d\n",a,b);
    swap(&a,&b);
    printf("a = %d,b = %d\n",a,b);
    return 0;
}







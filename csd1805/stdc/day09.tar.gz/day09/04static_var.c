/*
 * 静态变量
 *    声明局部变量 前加static 关键字
 *    静态变量的作用域 限定在当前代码块
 *    生命周期  整个程序结束
 *
 *  [练习]
 *        实现一个swap函数  void swap();
 *        功能 实现全局变量 a b 的交换
 *        int a = 20;
 *        int b = 30;
 *        在main函数中调用测试
 *
 */
#include <stdio.h>

int i = 0;

void func()
{
   //static  int i = 0;   //计数程序调用次数
   i++;
   printf("该函数调用了%d次\n",i);
   printf("static i 地址%p\n",&i);
}

int main(){

    func();  //1 只对静态局部变量初始化一次
    func();  //2
    func();  //3
    func();  //4

    return 0;
}

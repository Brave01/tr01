/*
 * 指针
 */
#include <stdio.h>
int main(){
    int i = 20;
    int c = 30;
    int b = 40;
    printf("i地址是%p\n",&i); //& 取i变量的地址

    int *p = &i; //声明一个整形指针变量,存储i变量的地址
    printf("p=0x%x\n",p); //将p里面的值进行十六进制输出

    //通过指针访问变量i里面的值
    printf("i = %d\n",*p); //* 取指针变量所指向的内存的值
                           //*p 等价于 变量名i
    //通过指针变量p 修改i的值

   
   c = *p;  //c = i; //对i变量的读 
   printf("c = %d\n",c); //* 取指针变量所指向的内存的值

   *p = b;  //i = b; //对i变量的写
   printf("*p = %d\n",i); //* 取指针变量所指向的内存的值

    return 0;
}







/*
 * 指针的运算
 *    &i   取变量地址的运算
 *    *p   取指针指向变量的运算
 *
 *   int *p = &i;  
 */
#include <stdio.h>
 int main(){
 
    int a = 1;
    char b = 2;
    int c = 3;

    int* pa = &a; 
    //int * pb 
    char *pb = &b;
       
    printf("&a = %p\n",&a);
    printf("&b = %p\n",&b);
    printf("&c = %p\n",&c);

    printf("pb+1 = %p\n",pb+1);

    printf("sizeof(pa) = %d\n",sizeof(pa)); //4
    printf("sizeof(pb) = %d\n",sizeof(pb)); //1

    return 0; 
 }   





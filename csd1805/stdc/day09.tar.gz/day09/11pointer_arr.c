/*
    [练习]
           在main 函数中声明一个 5个int元素的数组
 编写  void input(int a[],int len); 从键盘上输入5个成绩到数组中
 编写  int max(int a[],int len); 返回 数组中最大元素的值
 编写  void output(int a[],int len); 打印数组的内容
 编写  float avg(int a[],int len);  返回  数组的平均值
     在main函数中  调用上面的函数

     int  main(){
         int a[5];

        //输入5个学员成绩
        input(a,5)

        //输入5个学员成绩
        output(a,5)

       //最高分
       printf("max = %d\n",max(a,5));

       //平均成绩
      printf("avg = %f\n",avg(a,5));

      return 0;
     }
 */

#include <stdio.h>

void func(int b[]);
void func(int b[])
{
    for(int i = 0;i<5;i++)
    {
        b[i]  = i;
    } 
}

 int main(){
    int a[5] = {10,20,30,40,50};
    func(a);
    for(int i = 0;i<5;i++)
    {
         printf("a[%d] = %d\n",i,a[i]);      
    } 
   return 0; 
 }   





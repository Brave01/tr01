/*
 *   不要返回一个局部变量的地址 
 * */
#include <stdio.h>
int* func();
int* func() /*//a,b 是一个整形的指针变量*/
{
    int d = 0;
    printf("&d = %p\n",&d);
    return &d;   
}
int main(){
    int a = 2;
    int b = 3;

    /*
    //printf("a = %d,b = %d\n",a,b);

    //printf("*pd = %d\n",*pd);
    //int *pd = func(); 
    */
    printf("pd = %p\n",func());


    return 0;
}







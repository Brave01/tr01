/*
 *
 * 全局变量  作用域 及生命周期
 */

#include <stdio.h>
int g_i = 0; //如果不初始化 全局变量也是0
int func();
int func2();
//int func2 = 0; //函数名 和全局变量名不能重名 
int func2(){
    int g_i;
    g_i=5;
    return 0;
}

int func(){

    g_i++;
    return 0;
}
int main(){


    printf("g_i = %d\n",g_i); //0
    func();
    printf("g_i = %d\n",g_i); //1
    func2();
    printf("g_i = %d\n",g_i); //1
    return 0;
}


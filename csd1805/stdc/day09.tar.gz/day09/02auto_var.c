/*
 * 局部变量的生命周期
 */
#include <stdio.h>
int func2()
{
    int i = 0;
    printf("i的地址是%p\n",&i);
    return 0;
}
int func1()
{
    int b = 0;
    int c = 0;
    func2();
    return 0;
}
int main(){
    int a=1;
    func2(); // i变量的地址
    func1(); // i 地址
    return 0;
}

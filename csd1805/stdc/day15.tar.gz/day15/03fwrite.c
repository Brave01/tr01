/*
 * 打开文件,并写入内容
 */

#include <stdio.h>
#include <string.h>

typedef struct{
    char name[20];
    int score ;
    int age;
} Student;

int main(){

    char c = 'a';
    int  b = 97; 
    Student s;
    strcpy(s.name,"如花");
    s.score = 80;
    s.age= 12;
    Student a[10] = {0};

    FILE *fp=fopen("day16.txt","r+");
    if(NULL == fp)
    {
        printf("打开文件失败\n"); 
        return -1;
    }

    printf("文件打开成功\n");
    //fwrite(&c,1,1,fp);  //写入一个字符 a 到文件day16.txt中
    //fwrite(&b,sizeof(int),1,fp);  //写入一个整数 0x31 到文件day16.txt中
#if 0
    int i =fwrite(&s,sizeof(s),1,fp);//写入一个学员信息 到文件day16.txt中
    printf("i = %d\n",i);
#endif

#if 1
    fread(&a[0],sizeof(s),1,fp);


    printf("name = %s\n",a[0].name);
    printf("score = %d\n",a[0].score);
    printf("age = %d\n",a[0].age);
#endif

    //关闭文件
    fclose(fp);
    fp = NULL; //防止野指针

    return 0;
}

/*
 * getc
 * putc
 *
 *[练习]
     使用上两个函数 实现文件的复制
     扩展:带参数main  实现任意文件名的复制
 */

#include<stdio.h>

int main(){

    FILE *fp = fopen("123.txt","r+");
    FILE *fp1 = fopen("abc.txt","w");
    if(!fp)
    {
        printf("文件打开失败\n"); 
        return -1;
    }
    char c = 0;
    while((c = getc(fp)) != EOF)
    {
        //printf("c = %c\n",c);
        putc(c,fp1);
    }

    return 0;
}

/*
 * sprintf
 * 实现strcat
 */

#include <stdio.h>
#include <string.h>
int main(){

    char *pc = "123";
    char *str1 = "hello";
    char *str2 = "world";
    int i = 30;
    //string
    //char a1[20] = {0};
    char *a2 = (char *)malloc(20);
   //pc 不可以作为sprintf的第一个参数 
   //a1,a2 都可以

    sprintf(a2,"%s",str1);
    sprintf(a2+strlen(str1),"%s",str2);

    printf("a =[%s]\n",a);

    free(a2);
    return 0;
}

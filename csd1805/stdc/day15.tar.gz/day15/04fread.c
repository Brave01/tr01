/*
 * 打开文件,并写/读内容
 *  
 *  文件流指针,记录对文件进行操作的位置
 *  文件开始位置
 *  文件末尾的位置
 */

#include <stdio.h>
#include <string.h>

typedef struct{
    char name[20];
    int score ;
    int age;
} Student;

int main(){

    char c = 'a';
    int  b = 97; 
    Student s;
    strcpy(s.name,"如花");
    s.score = 80;
    s.age= 12;
    Student a[10] = {0};

    FILE *fp=fopen("day16.txt","r+");
    //文件流指针  在开始的位置
    if(NULL == fp)
    {
        printf("打开文件失败\n"); 
        return -1;
    }

    printf("文件打开成功\n");

    //写入一个学员信息 到文件day16.txt中
    //写在最开始的位置
    printf("写前文件流指针 = %ld\n",ftell(fp));
    int i =fwrite(&s,sizeof(s),1,fp);

    //文件流指针  在文件末尾
    printf("write i = %d\n",i);

    printf("写后文件流指针 = %ld\n",ftell(fp));

    rewind(fp);
    printf("rewind后文件流指针 = %ld\n",ftell(fp));
    //从末尾开始读 sizeof(s)*1
    i = fread(&a[0],sizeof(s),1,fp);
    printf("read i = %d\n",i);

    printf("读后文件流指针 = %ld\n",ftell(fp));

    printf("name = %s\n",a[0].name);
    printf("score = %d\n",a[0].score);
    printf("age = %d\n",a[0].age);


    b = 0;
    //fseek(fp,-8,SEEK_END);
    //fseek(fp,-8,SEEK_CUR); //文件流指针在末尾
    fseek(fp,20,SEEK_SET); //文件流指针在末尾
    i = fread(&b,sizeof(int),1,fp);
    printf("b = %d\n",b);

    //练习,修改学员的年龄,其他信息不修改,通过文件流指针
    b = 10;
    fwrite(&b,sizeof(int),1,fp);

    rewind(fp);
    i = fread(&a[1],sizeof(s),1,fp);
    printf("name = %s\n",a[1].name);
    printf("score = %d\n",a[1].score);
    printf("age = %d\n",a[1].age);

    //关闭文件
    fclose(fp);
    fp = NULL; //防止野指针




    return 0;
}

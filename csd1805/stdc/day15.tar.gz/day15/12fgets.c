/*
 * fgets
 */
#include <stdio.h>
#include <stdlib.h>

int main(){
    
    char *buf = (char *)malloc(30);
    if(!buf)
    {
        printf("内存分配失败\n"); 
        return -1;
    }
#if 0
    FILE *fp = fopen("123.txt","r");
    if(!fp) 
    {
        printf("打开文件失败\n"); 
        return -1;
    }
#endif

   //fgets(buf,13,fp);  //不再从文件读取
   fgets(buf,8,stdin);  //标准输入设备

   printf("buf = %s\n",buf);

  // fclose(fp);
   free(buf);
   return 0;
}

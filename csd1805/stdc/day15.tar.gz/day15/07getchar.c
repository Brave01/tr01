/*
 * getchar
 * putchar
 */

#include <stdio.h>

int main(){

    char c = 0;
    c = getchar();

    //printf("c = %c\n",c);
    putchar(c);
   // putchar('\n');
    return 0;
}

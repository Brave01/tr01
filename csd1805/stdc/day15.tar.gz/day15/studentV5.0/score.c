#include "score.h"
#include <stdio.h>
void score_scan(Score *s)
{
    int i;
    printf("选择输入成绩的类型 0:等级成绩\n");
    printf("                   1:整数成绩\n");
    printf("                   2:小数成绩\n");
    scanf("%d",&i);
    if(i == LEV)
    {
        s->st=LEV;

        printf("请输入等级:0-->A;1-->B;2-->C\n"); 
        scanf("%d",(int *)&(s->us.lev_score));
    }

    else if(i == INT)
    {
        s->st=INT;

        printf("请输入整数成绩:\n"); 
        scanf("%d",&(s->us.i_score));
    }
    else
    {
        s->st=DOUBLE;

        printf("请输入小数成绩:\n"); 
        scanf("%lf",&(s->us.d_score));
    }

}

void score_print(Score s)
{
    if(s.st == LEV)
    {
        if(s.us.lev_score == A) 
        {
            printf("A\t"); 
        }
        else if(s.us.lev_score == B)
        {
            printf("B\t"); 
        }
        else
        {
            printf("C\t"); 
        
        }
    }
    else if(s.st == INT)
    {
        printf("%d\t",s.us.i_score); 
    }
    else
    {
        printf("%.1lf\t",s.us.d_score); 
    
    }

}

//测试
#if 0

int main(){
    Score s;
    score_scan(&s);
    score_print(s);
    return 0;
}
#endif

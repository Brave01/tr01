/*
编写  void input(int a[],int len); 从键盘上输入5个成绩到数组中
编写  int max(int a[],int len); 返回 数组中最大元素的值
编写  void output(int a[],int len); 打印数组的内容
编写  float avg(int a[],int len);  返回  数组的平均值
      int find(Student a[],int len);    根据姓名能查成绩    
      int delete(Student a[],len);       能够根据姓名删除学员信息 

*/
#include <stdio.h>
#include <string.h>
#include "student.h"
extern int student_max;
extern int student_count;
//录入学员成绩
//void input(Student a[],int len)
//int input(Student a[],int len)
int input(Student *a,int len)
{
    //for(int i = 0;i<len;i++)
    int i = len;
    char c = 0;
    do{
        printf("请输入学员的姓名:"); 
        scanf("%s",a[i].name);

       // printf("请输入学员的成绩:"); 
       // scanf("%d",&a[i].score);
       score_scan(&(a[i].score));

        printf("请输入学员的年龄:"); 
        scanf("%d",&a[i].age);

       // scanf("%*[^\n]");  //下面录入学员性别是一个字符,先清缓冲区
       // scanf("%*c");
       // printf("请输入学员的性别:"); 
       // scanf("%c",&a[i].gender);
       gender_scan(&(a[i].gender));
       
       scanf("%*[^\n]");  //输入一个字符,先清缓冲区
       scanf("%*c");

       printf("是否继续输入(Y/N):");
       scanf("%c",&c);

       i++;
       if(i >= student_max)
       {
           printf("内存空间已满\n");
           return i;
       }

    }while(c == 'y' || c == 'Y');
    return i;

}

#if 0
//输出最高成绩
int max(Student a[],int len)
{
    int max_index = 0;  //该变量用于记录最高分数的下标
    int max = 0;
    for(int i = 0;i<len;i++)
    {
        if(i == 0) //假设第一个学员成绩最高
        {
            max = a[i].score;
            max_index = 0;
        }
        else
        {
            if(max < a[i].score)
            {
                max = a[i].score;
                max_index = i;
            }
        }
    }
    printf("最高分:%d,学员具体信息如下:\n",max);
    printf("姓名\t成绩\t年龄\t性别\n");

    //输出姓名
    printf("%s\t",a[max_index].name);
    //输出成绩
    //printf("%d\t",a[max_index].score);
    score_print(a[max_index].score);
    //输出年龄
    printf("%d\t",a[max_index].age);
    //输出性别
    //printf("%c\n",a[i].gender);
    gender_print(a[max_index].gender);


    //printf("%s\t%d\t%d\t%c\n",a[max_index].name,\
            a[max_index].score,a[max_index].age,a[max_index].gender);

    return max_index; //可以返回 最高成绩的下标
}
#endif

//输出所有学员成绩
void output(Student a[],int len)
{

    printf("学员的成绩:\n"); 
    printf("姓名\t成绩\t年龄\t性别\n");
    for(int i = 0;i<len;i++)
    {
        if(strlen(a[i].name))
        {
            //输出姓名
            printf("%s\t",a[i].name);
            //输出成绩
            //printf("%d\t",a[i].score);
            score_print(a[i].score);
            
            //输出年龄
            printf("%d\t",a[i].age);
            //输出性别
            //printf("%c\n",a[i].gender);
            gender_print(a[i].gender);
        }
    }

}
#if 0
//计算所有学员平均成绩
float avg(Student a[],int len)
{
    float s = sum(a,len);

    return s/len;

}

//计算所有学员总成绩
static int sum(Student a[],int len)
{
    int sum = 0;
    for(int i = 0;i<len;i++)
    {
        sum = sum + a[i].score;
    }

    return sum;
}
#endif

int find(Student a[],int len)   // 根据姓名能查成绩    
{
    char find_name[20];
    printf("输入要查找的姓名:");
    scanf("%s",find_name);
    for(int i = 0;i<len;i++)
    {
        if(strcmp(find_name,a[i].name) == 0)
        {
            printf("姓名\t成绩\t年龄\t性别\n");
            //输出姓名
            printf("%s\t",a[i].name);
            //输出成绩
            //printf("%d\t",a[i].score);
            score_print(a[i].score);
            //输出年龄
            printf("%d\t",a[i].age);
            //输出性别
            //printf("%c\n",a[i].gender);
            gender_print(a[i].gender);

           // printf("%s\t%d\t%d\t%c\n",a[i].name,a[i].score,a[i].age,a[i].gender);
            return i;
        }
    }
    printf("查无此人\n");
    return -1;
}

int delete(Student a[],int len)     //  能够根据姓名删除学员信息 
{
    char find_name[20];
    printf("输入要删除学员的姓名:");
    scanf("%s",find_name);
    for(int i = 0;i<len;i++)
    {
        if(strcmp(find_name,a[i].name) == 0)
        {
            printf("姓名\t成绩\t年龄\t性别\n");
            //printf("%s\t%d\t%d\t%c\n",a[i].name,a[i].score,a[i].age,a[i].gender);
            
            printf("%s\t",a[i].name);
            //输出成绩
            //printf("%d\t",a[i].score);
            score_print(a[i].score);
            //输出年龄
            printf("%d\t",a[i].age);
            //输出性别
            //printf("%c\n",a[i].gender);
            gender_print(a[i].gender);

            printf("找到该学员正在删除中...\n");

            for(int j = i;j<len-1;j++)
            {
                a[j] = a[j+1];
            }

            memset(&a[len-1] ,0,sizeof(Student));

            student_count--;
            return i;
        }
    }
    printf("查无此人\n");
    return -1;


}
#if 0   //main 仅用于测试
int main(){
    int a[5] = {0};
    input(a,5);
    output(a,5);
    printf("max = %d\n",max(a,5));
    printf("avg = %f\n",avg(a,5));
}
#endif

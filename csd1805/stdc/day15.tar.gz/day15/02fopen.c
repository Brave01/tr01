/*
 * 打开文件
 */

#include <stdio.h>

int main(){

    //打开文件   以只读的方式
    //FILE *fp=fopen("day16.txt","r"); //ok

    //day16文件不存在   以只读的方式
    //FILE *fp=fopen("day16.txt","r");//打开文件失败
    
    //day16文件不存在   以只写的方式,文件内容被清掉
    //FILE *fp=fopen("day16.txt","w"); 

    //day16文件不存在   以追加的方式,文件内容没有清掉
    FILE *fp=fopen("day16.txt","a");
    if(NULL == fp)
    {
        printf("打开文件失败\n"); 
        return -1;
    }
    printf("文件打开成功\n");

    //关闭文件
    fclose(fp);
    fp = NULL; //防止野指针

    return 0;
}

/*
 * sscanf
 */

typedef struct{
    char name[20];
    int score ;
    int age;
} Student;


#include <stdio.h>

int main(){
    Student s;    

    char *pc = "如花 80 20";
    printf("pc = %s\n",pc);

    sscanf(pc,"%s%d%d",s.name,&s.score,&s.age);

    printf("s.name = %s\n",s.name);
    printf("s.score= %d\n",s.score);
    printf("s.age  = %d\n",s.age);

    return 0;
}

/*
 * fscanf
 */


#include <stdio.h>
#include <string.h>

typedef struct{
    char name[20];
    int score ;
    int age;
} Student;


int main(){


    Student s;
#if 0
    strcpy(s.name,"如花");
    s.score = 80;
    s.age= 12;
    Student a[10] = {0};
#endif 
    FILE * fp = fopen("123.txt","r");
    if(!fp)
    //if(fp == NULL)
    {
        printf("打开文件失败\n"); 
        return -1;
    }
    printf("文件打开成功\n");

    //fprintf(); 比printf 多一个参数,指定输出的文件结构体指针
    //fprintf(fp,"hello world!");
    //fprintf(fp,"%s,%d,%d",s.name,s.score,s.age);

    Student s2;
    fscanf(fp,"%s%d%d",s2.name,&s2.score,&s2.age);

    printf("s2.name = %s\n",s2.name);
    printf("s2.score= %d\n",s2.score);
    printf("s2.age= %d\n",s2.age);

    fclose(fp);
    return 0;
}







#include <stdio.h>
#include "login.h"
#include "student.h"
/*
 *  [练习]
 *     将01student 项目  用结构体数组重构一遍,不仅仅能处理学员的分数
 *     将学员数组声明为 Student 类型
 *
 *     int student[10];
 typedef struct student{  //student 可以省略
    char name[20];  //姓名
    int  score;      //分数
    int  age;        //年龄
    char gender;     //性别
}Student;   //struct student stu1  ==>Student stu1

      添加 2个功能
             根据姓名能查成绩    
             能够根据姓名删除学员信息 
             函数写在 
             student.c
*/ 

int menu(Student a[],int len){
    int cmd = 0;
    printf("+------------------+\n");
    printf("|   学员管理菜单   |\n");
    printf("+------------------+\n");
    printf("|                  |\n");
    printf("|   1.录入学员     |\n");
    printf("|   2.打印成绩     |\n");
 //   printf("|   3.打印最高成绩 |\n");
 //   printf("|   4.打印平均成绩 |\n");
    printf("|   5.查找学员成绩 |\n");
    printf("|   6.删除学员信息 |\n");
    printf("|   0.退出系统     |\n");
    printf("|                  |\n");
    printf("+------------------+\n");
    printf("选择您的操作:"); 
    scanf("%d",&cmd);
    switch(cmd)
    {
        case 1:  
            printf("输入成绩\n");
            input(a,len);
            break;

        case 2:
            printf("打印成绩\n");
            output(a,len);
            break;

        case 3:
           // printf("最高成绩是第%d个学员\n",max(a,len)+1);

            break;

        case 4:
           // printf("平均成绩=%f\n",avg(a,len));
            break;

        case 5:
            printf("查找学员信息\n");
            find(a,len);
            break;

        case 6:
            printf("删除学员信息\n");
            delete(a,len);
            break;


        case 0:
            printf("退出系统\n");
            return 0;

        default:
            printf("操作数错误\n");
            break;
    }
    return 1;
}

int main(){
    Student student[3];
    int cmd = 0;
    char passwd[13]; //只能存12个字符 + \0 
    int flag = 1;
    while(flag)
    {
        printf("+------------------+\n");
        printf("|      登录菜单    |\n");
        printf("+------------------+\n");
        printf("|                  |\n");
        printf("|   1.设置密码     |\n");
        printf("|   2.登录系统     |\n");
        printf("|   0.退出系统     |\n");
        printf("|                  |\n");
        printf("+------------------+\n");
        printf("选择您的操作:"); 
        scanf("%d",&cmd);
        switch(cmd)
        {
            case 1:  
                setPasswd(passwd);
                break;
            case 2:
                if(login(passwd)) //1
                {
                    //登录成功的代码
                    //printf("登录成功\n");
                    while(menu(student,3));
                }
                else
                {
                    printf("密码错误,登录失败\n"); 
                }
                flag = 0;
                break;
            case 0:
                printf("退出系统\n");
                flag = 0;
                break;

            default:
                printf("操作数错误\n");
                break;
        }

    }
    return 0;
}

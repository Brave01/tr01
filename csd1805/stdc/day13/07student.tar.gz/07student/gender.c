#include<stdio.h>
#include "gender.h"
void gender_scan(GENDER *gender)
{
    int i;
    printf("输入0表示女性，非0表示男性:\n");
    scanf("%d",&i);

    if(i)
    {
        *gender =  MALE;
    }
    else
    {
        *gender =  FEMALE;
    }
    

}
void gender_print(GENDER gender)
{
    if(gender)
    {
        printf("男\n"); 
    }
    else
        printf("女\n");
}

//测试
#if 0
int main(){

    GENDER g;
    gender_scan(&g);
    gender_print(g);
    return 0;
}
#endif

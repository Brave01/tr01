#ifndef __STUDENT_H__
#define __STUDENT_H__
#include "gender.h"
#include "score.h"

typedef struct {
    char name[20];
    Score score;
    int age;
    GENDER gender;
}Student;
void input(Student a[],int len);
//int max(Student a[],int len);
void output(Student a[],int len);
//float avg(Student a[],int len);
//static int sum(Student a[],int len);
int find(Student a[],int len);   // 根据姓名能查成绩    
int delete(Student a[],int len);     //  能够根据姓名删除学员信息 


#endif //__STUDENT_H__

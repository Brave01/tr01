void setPasswd(char *passwd);
int login(const char *passwd);


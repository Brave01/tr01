/*
[练习]
    1. 声明两个char 数组
    char a[]={'H','e','l','l','o',' ','W','o','r','l','d','!'};

*/

#include <stdio.h>

int main(){

    char a[]={'H','e','l','l','o',' ','W','o','r','l','d','!'};
    int b[] = {0,1,2,3,4,5,6,7};
    int j = 0;


    //sizeof(j)  = 4
    //数组名的 字节数
    printf("sizeof(b) = %d\n",sizeof(b)); //20
    printf("sizeof(a) = %d\n",sizeof(a)); //12?

    //计算数组元素个数
    printf("元素个数 = %d\n",sizeof(b)/sizeof(b[0])); //20

    return 0;
}








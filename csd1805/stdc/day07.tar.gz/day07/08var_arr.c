/*
 * C99 支持的可变长数组
 * [练习] 使用可变数组
 *      先输入 学员个数n
 *      为这n学员 申请 n个数组元素 存放录入他们的成绩
 *
 *      录入完后 打印 他们的成绩 和平均 成绩(考虑是小数)
 */
#include <stdio.h>

int  main(){

    int n = 0;
    //int a[n] = {0};  不能初始化

    //printf("数组元素个数:%d\n",sizeof(a)/sizeof(a[0]));

    printf("输入新n值:");
    scanf("%d",&n); //0  5

    int a[n];// {0};   一般是局部变量
    printf("数组元素个数:%d\n",sizeof(a)/sizeof(a[0]));

    for(int i = 0;i<n;i++)
    {
        printf("输入一个学员的成绩:");
        scanf("%d",&a[i]); //a[5]  
        //printf("a[%d] = %d\n",i,a[i]);
    }

    float sum  = 0;
    for(int i = 0;i<n;i++)
    {
        sum = sum + a[i];
        printf("a[%d] = %d\n",i,a[i]);
    }

    printf("平均成绩= %f\n",sum/n);
    return 0;
}








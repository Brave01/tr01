/*
[练习]
    1. 声明两个char 数组
    char a[]={'H','e','l','l','o',' ','W','o','r','l','d','!'};

    char b[12] 能存放a的大小

    将a  内容 复制 到 b
    输出 b

    将数组a中的空格去掉,空格后的内容往前移
      1. 数组a 复制到b 中 空格跳过不复制,再把b 赋值给a
      2. 对a进行遍历移除
*/

#include <stdio.h>

int main(){

    char c = ' ';

    char a[]={'H','e','l','l','o',' ','W','o','r','l','d','!'};
    char b[12] = {0};

    for(int i =0;i<12;i++)
    {
        b[i] = a[i]; 
    }

    for(int i =0;i<12;i++)
    {
       printf("%c",b[i]);  
    }
    printf("\n");
    printf("%d\n",c);
    return 0;
}








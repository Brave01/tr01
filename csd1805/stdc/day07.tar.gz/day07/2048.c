/*
 *
 * [练习]
 *      1.声明一个int 4*4 二维数组
 *      int a[4][4] = {0}; //初始化整个数组为0
 *
 *      2.在数组的随机一个位置赋值2
 *         y =  rand()%4  -->0 - 3
 *         x =  rand()%4  -->0 - 3
 *         a[y][x]  = 2;
 *
 *      3. 打印出a 数组
 *
 *      4. 绘制输出内容
 *
 */

#include <stdio.h>
#include <time.h>
#include <stdlib.h>

int main(){
    //1.
    int a[4][4] = {0};

    //2.
    srand(time(0));
    int x = rand()%4;
    int y = rand()%4;
    a[y][x] = 2;

    while(1)
    {
        system("clear");
        //3.
        //  4.1  增加表格框
        printf("+----+----+----+----+\n");
        for(int i = 0; i<4;i++)
        {
            for(int j = 0; j<4;j++)
            {
                if(a[i][j] == 0)  //0 用空格替换
                {
                    printf("|    "); 
                }
                else
                {
                    printf("|%4d",a[i][j]);  //4.0   %4d  占用4个宽度
                }
            }
            printf("|\n");
            printf("+----+----+----+----+\n");
        }
        printf("|    k              |\n");
        printf("|h<--+-->l          |\n");
        printf("|    j              |\n");
        printf("+----+----+----+----+\n");
        
        char cmd = 0; 
        scanf("%c",&cmd);

        scanf("%*[^\n]");
        scanf("%*c");

        switch(cmd)
        {
            case  'k' :
                printf("上移动\n");
                for(int i = 3;i>0;i--)
                {
                    for(int j = 0;j<4;j++)
                    {
                            if(a[i-1][j] == 0)    
                            {
                                a[i-1][j] =a[i][j];
                                a[i][j]  = 0;
                            }
                            else
                            {
                                if(a[i-1][j] == a[i][j]) 
                                {
                                    a[i-1][j]  = 2*a[i][j];
                                    a[i][j] = 0;
                                }
                            
                            }
                    }
                }

                do{
                 x = rand()%4;
                 y = rand()%4;
                }while(a[y][x] != 0);

                a[y][x] = 2;
                break;

            case  'h' :
                printf("左移动\n");
                break;
            case  'j' :
                printf("下移动\n");
                break;

            case  'l' :
                printf("右移动\n");
                break;

            default :
                printf("输入错误\n");
                break;

        }

    }
    return 0;
}

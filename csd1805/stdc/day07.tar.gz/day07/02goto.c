/*
 * 彩票
 *   去重复相同的数字
 */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main(){

    int a[7];
    srand(time(0));
start:
    for(int i = 0;i<7;i++)
    {
        a[i] = rand()%32+1;  //1 - 32 
    }

    for(int i = 0;i<7;i++)
    {
        printf("a[%d] = %d\n",i,a[i]);  //1 - 32 
    }

    for(int j = 0;j<7;j++)
    {
        for(int i =j+1;i<7;i++)
        {
            if(a[j]  == a [i])
            {
                printf("数字重复\n"); 
                goto start;
            }
        }
    }

    return 0;
}



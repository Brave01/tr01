/*
 * 查看数组的地址
*/

#include <stdio.h>

int main(){
    int a[5] = {0};

    printf("a = %p\n",&a);
    printf("a[0] = %p\n",&a[0]);
    printf("a[1] = %p\n",&a[1]);
    printf("a[2] = %p\n",&a[2]);
    printf("a[3] = %p\n",&a[3]);
    printf("a[4] = %p\n",&a[4]);

    return 0;
}








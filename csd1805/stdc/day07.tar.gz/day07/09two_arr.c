
/*
 * 二维数组的定义
 * 初始化
 */
/*
 *    1   2   3
 *    2   4   6
 *    3   6   9
 */
 /*
    a[0][0]  a[0][1]  a[0][2]
    a[1][0]  a[1][1]  a[1][2]
    a[2][0]  a[2][1]  a[2][2]
    */

/*
 * 练习
 *      已知 数组 a[3][3] 所有元素赋初始值 3
 *      已知 数组 b[3][3] 所有元素赋初始值 4
 *      a = a*b
 *      a[0][0] = b[0][0]  * a[0][0];
 *      a[0][1] = b[0][1]  * a[0][1];
 *
 *      打印a数组的值
 */

#include <stdio.h>
#include <unistd.h>
int main(){
    int a[3][3];   //3*3 9个元素
    for(int j = 0;j<3;j++) //j 表示 第几排
    {
        for(int i=0;i<3;i++) 
        {
            a[j][i] =  (j+1) * (i+1);
            printf("a[%d][%d]=%d*%d=%d\t",j,i,j+1,i+1,(j+1)*(i+1));
            a[j][i]  = 0;
            fflush(stdout);
            sleep(2);
           // a[j][i] =  j+1;
        }
        printf("\n");
    }

    for(int j = 0;j<3;j++) //j 表示 第几排
    {
        for(int i=0;i<3;i++) 
        {
            printf("a[%d][%d] = %d ",j,i,a[j][i]);
        }
        printf("\n");
    }

    return 0;
}

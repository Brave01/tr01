/*
[练习]
    1. 声明两个char 数组
    char a[]={'H','e','l','l','o',' ','W','o','r','l','d','!'};

    char b[12] 能存放a的大小
    将数组a中的空格去掉,空格后的内容往前移
      1. 数组a 复制到b 中 空格跳过不复制,再把b 赋值给a

  a[] 0   1  2  3  4  5  6  7  8  9  10  11
      H   e  l  l  o     W  o  r  l  d   !

  b[] H   e  l  l  o  W  o  r  l  d  !


      2. 对a进行遍历移除
      思考题
*/

#include <stdio.h>

int main(){

    char a[]={'H','e','l','l','o',' ','W','o','r','l','d','!'};
    char b[12] = {0};
    int j = 0;

    for(int i =0;i<12;i++)
    {
        if(a[i] != ' ')
        {
            b[j++] = a[i]; 
        }
    }

    //a = b;
    for(int i =0;i<12;i++)
    {
       a[i] = b[i];  
    }


    for(int i =0;i<12;i++)
    {
       printf("%c",a[i]);  
    }

    printf("\n");
    return 0;
}








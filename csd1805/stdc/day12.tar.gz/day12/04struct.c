/*
 *   结构体变量的初始化
 *
 *   结构体变量 结构体指针
 *   [练习]
 *       声明一个Student 类型 (typedef)
 *       再声明 一个Student 结构体变量 s  指针变量ps   ps指向s
 *       通过ps 对 s变量进行赋值 并打印输出s的内容
 *
 *       sizeof(ps)  结果是多少?
 *       sizeof(s)   结果是多少? 为什么?
 *       name成员将20改为19后
 *       sizeof(s)   是多少?
 */

#include<stdio.h>
#include <string.h>

int main(){
typedef struct student{  //student 可以省略
      char name[20];
      int  score;
      int  age;
   }Student;   //struct student stu1  ==>Student stu1

   int i = 0; //声明i变量并初始化
   int* p = &i; //声明指针变量并初始化指向i
   //能不能定义结构体变量是对其进行初始化 
   Student stu1 ={"李辉",0,80};
   Student * ps = &stu1; //声明一个结构体指针变量 指向stu1

   printf("该学员的姓名=%s\n",stu1.name);
   printf("该学员的成绩=%d\n",stu1.score);
   printf("该学员的年龄=%d\n",stu1.age);

   ps->score = 90;
   printf("ps->name姓名=%s\n",ps->name);
   printf("ps->score成绩=%d\n",ps->score);
   printf("ps->age年龄=%d\n",ps->age);


    return 0;
}





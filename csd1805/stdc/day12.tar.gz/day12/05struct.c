/*
 *   结构体变量 结构体指针
 *   [练习]
 *       声明一个Student 类型 (typedef)
 *       再声明 一个Student 结构体变量 s  指针变量ps   ps指向s
 *       通过ps 对 s变量进行赋值 并打印输出s的内容
 *
 *       sizeof(ps)  结果是多少?
 *       sizeof(s)   结果是多少? 为什么?  
 *          结构体变量字节数=所有成员字节数之和?
 *
 *          四字节补齐 ==>4的整数倍  
 *
 *       name成员将20改为19后
 *       sizeof(s)   是多少?
 */

#include<stdio.h>
#include <string.h>

int main(){
    typedef struct student{  //student 可以省略
       // char name[20];
        //char name[12];
        char c1;
        char c2;
        int  score;
        int  age;
    }Student;   //struct student stu1  ==>Student stu1

    Student stu1;
    Student * ps = &stu1; //声明一个结构体指针变量 指向stu1


    printf("sizeof(ps) = %d\n",sizeof(ps)); //4
    printf("sizeof(stu1) = %d\n",sizeof(stu1)); //28

    printf("sizeof(int) = %d\n",sizeof(int)); //4
    printf("sizeof(Student) = %d\n",sizeof(Student)); //28

#if 0
    printf("输入姓名:");
    //scanf("%s",stu1.name);
    scanf("%s",ps->name);

    printf("输入成绩:");
    //scanf("%d",&(stu1.score));
    scanf("%d",&(ps->score));


    printf("输入年龄:");
    scanf("%d",&(ps->age));


    printf("ps->name姓名=%s\n",ps->name);
    printf("ps->score成绩=%d\n",ps->score);
    printf("ps->age年龄=%d\n",ps->age);
#endif

    return 0;
}





/*
 *   结构体应用
 *        结构体作为函数的参数, 
 *        值传递,而不是指针,跟基本类型变量一样
 *        跟指针,数组 不一样
 *        如果要修改传入的结构体,应该传指针
 *
 *
 *        结构体作为函数的返回值
 *            跟普通基本类型一样
 *
 */

#include<stdio.h>
#include <string.h>

typedef struct student{  //student 可以省略
     char name[20];
    int  score;
    int  age;
}Student;   //struct student stu1  ==>Student stu1

#if 0
void func (Student s);
void func (Student s)
{
    s.age = 18;

    //return 0;
}

void func (Student* s);
void func (Student* s)
{
    s->age = 18;

    //return 0;
}
#endif
#if 0
Student  func (Student s);
Student  func (Student s)
{
    s.age = 18;
    return s;
}
#endif

Student*  func (Student s);
Student*  func (Student s)
{
    s.age = 18;
    return &s;
}

int main(){

    //Student stu2 ={0};
    Student stu1 ={"李辉",30,30};

    //stu1 = func(stu1);
    Student *ps = func(stu1);

    printf("ps->name姓名=%s\n",ps->name);
    printf("ps->score成绩=%d\n",ps->score);
    printf("ps->age年龄=%d\n",ps->age);

#if 0
    printf("姓名=%s\n",stu1.name);
    printf("成绩=%d\n",stu1.score);
    printf("年龄=%d\n",stu1.age);


    printf("输入姓名:");
    //scanf("%s",stu1.name);
    scanf("%s",ps->name);

    printf("输入成绩:");
    //scanf("%d",&(stu1.score));
    scanf("%d",&(ps->score));


    printf("输入年龄:");
    scanf("%d",&(ps->age));


    printf("ps->name姓名=%s\n",ps->name);
    printf("ps->score成绩=%d\n",ps->score);
    printf("ps->age年龄=%d\n",ps->age);
#endif

    return 0;
}





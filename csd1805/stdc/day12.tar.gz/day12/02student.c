/*
 * 描述一个学员信
 */

#include<stdio.h>
#include <string.h>

int main(){
#if 0
    //1.定义student 类型
   struct student{
      char name[20];
      int  score;
      int  age;
   }stu2,stu3;  //声明了2个student 类型的 变量stu2,stu3
#endif
typedef struct student{  //student 可以省略
      char name[20];
      int  score;
      int  age;
   }Student;   //struct student stu1  ==>Student stu1



   //用student 类型 声明变量stu1
   // struct student stu1; 
   Student stu1; 

   //使用结构体 
   //[练习]给该学员 赋值姓名 和年龄 然后打印
   //字符串赋值  strcpy
    stu1.score = 80;
    //stu1.name = "李辉"; //不可这么赋值  strcpy
    //strcpy("李辉",stu1.name); 不可以
    strcpy(stu1.name,"李辉");
    stu1.age = 18;

    printf("该学员的姓名=%s\n",stu1.name);
    printf("该学员的成绩=%d\n",stu1.score);
    printf("该学员的年龄=%d\n",stu1.age);
    return 0;
}





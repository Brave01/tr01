/*
 *   结构体应用
 *       结构体的数组
 *       int a[5];
 *  [练习]
 *     将01student 项目  用结构体数组重构一遍,不仅仅能处理学员的分数
 *     将学员数组声明为 Student 类型
 *
 *     int student[10];
 typedef struct student{  //student 可以省略
    char name[20];  //姓名
    int  score;      //分数
    int  age;        //年龄
    char gender;     //性别
}Student;   //struct student stu1  ==>Student stu1

      添加 2个功能
             根据姓名能查成绩    
             能够根据姓名删除学员信息 
             函数写在 
             student.c
                 

*
 *
 */

#include<stdio.h>
#include <string.h>

typedef struct student{  //student 可以省略
     char name[20];
    int  score;
    int  age;
}Student;   //struct student stu1  ==>Student stu1



//void func (Student s[],int len);
void input (Student *s,int len); //跟上面是一样的
void input (Student* s,int len)
{
    for(int i = 0;i<len;i++)
    {
        printf("输入姓名:");
        scanf("%s",s[i].name);

        printf("输入成绩:");
        scanf("%d",&(s[i].score));


        printf("输入年龄:");
        scanf("%d",&(s[i].age));
    
    }


    //return 0;
}

void output (Student *s,int len); //跟上面是一样的
void output (Student* s,int len)
{
    for(int i = 0;i<len;i++)
    {
        printf("第%d个姓名:%s\n",i+1,s[i].name);
        printf("第%d个成绩:%d\n",i+1,s[i].score);
        printf("第%d个年龄:%d\n",i+1,s[i].age);

    }

    //return 0;
}

int main(){

    Student stu1 ={"李辉",30,30};

    Student  s[10];  //声明10个Student 结构体的数组

    input(s,3);

    output(s,3);

    return 0;
}





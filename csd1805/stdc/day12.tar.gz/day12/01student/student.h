#ifndef __STUDENT_H__
#define __STUDENT_H__

void input(int a[],int len);
int max(int a[],int len);
void output(int a[],int len);
float avg(int a[],int len);
static int sum(int a[],int len);

#endif //__STUDENT_H__

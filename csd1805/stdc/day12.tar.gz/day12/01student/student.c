/*
编写  void input(int a[],int len); 从键盘上输入5个成绩到数组中
编写  int max(int a[],int len); 返回 数组中最大元素的值
编写  void output(int a[],int len); 打印数组的内容
编写  float avg(int a[],int len);  返回  数组的平均值
*/
#include <stdio.h>
#include "student.h"
//录入学员成绩
void input(int a[],int len)
{
    for(int i = 0;i<len;i++)
    {
        printf("请输入学员的成绩:"); 
        scanf("%d",&a[i]);
    }

}

//输出最高成绩
int max(int a[],int len)
{
    int max = 0;
    for(int i = 0;i<len;i++)
    {
        if(i == 0)
        {
            max = a[i];
        }
        else
        {
            if(max < a[i])
                max = a[i];
        }
        
    }
    return max;
}

//输出所有学员成绩
void output(int a[],int len)
{

    printf("学员的成绩:\n"); 
    for(int i = 0;i<len;i++)
    {
        printf("第%d个学员成绩= %d\n",i,a[i]); 
    }

}

//计算所有学员平均成绩
float avg(int a[],int len)
{
    float s = sum(a,len);

    return s/len;

}

//计算所有学员总成绩
static int sum(int a[],int len)
{
    int sum = 0;
    for(int i = 0;i<len;i++)
    {
        sum = sum + a[i];
    }

    return sum;
}
#if 0   //main 仅用于测试
int main(){
    int a[5] = {0};
    input(a,5);
    output(a,5);
    printf("max = %d\n",max(a,5));
    printf("avg = %f\n",avg(a,5));
}
#endif

/*
 * typedef  类型的别名
 */
#include <stdio.h>
//typedef int   INT;
typedef unsigned int  uint32 ;

int main(){

    INT       i =  0;
    uint32  i32 = 0;

    printf("sizeof(INT) = %d\n",sizeof(INT));

    return 0;
}

/*
 * 双重循环 循环控制变量演示
 * [应用]
 *     已知  i + j = 40
 *           2i + 4j = 100
 *
 *     请输出 i j 的取值
 *     鸡兔同笼   头40个   共100个脚
 *
 *     早饭 20圆   有若干2圆  若5圆  1圆的若干 
 *     输出  付费方案
 *     输出  共有几种
 */

#include <stdio.h>
#include <unistd.h>

int main(){

    int x = 0;
    for(int k = 0;k<=20;k++)
    {
        for(int i=0;i<=10;i++)    //i 代表2圆的张数
        {
            for(int j=0;j<=4;j++) //j 代表5圆的张数
            {
                if(i*2+j*5+ k== 20)   
                {
                    x++;
                    printf("1圆=%d 2圆的张数=%d 5圆的张数=%d\n",k,i,j); 
                    goto  over;
                }
            }
        }
    }
over:
    printf("共%d种方案\n",x);
    return 0;
}

/*
 * 双重循环 循环控制变量演示
 * [应用]
 *     已知  i + j = 40
 *           2i + 4j = 100
 *
 *     请输出 i j 的取值
 *     鸡兔同笼   头40个   共100个脚
 *
 *     早饭 20圆   有若干2圆  若5圆  
 *     输出  付费方案
 *     输出  共有几种
 */

#include <stdio.h>
#include <unistd.h>

int main(){

    for(int i=0;i<=40;i++)
    {
        for(int j=0;j<=40;j++)
        {
               if((i+j == 40)&&(2*i+4*j)==100)   
               {
                    printf("i = %d  j = %d\n",i,j); 
               }
        }
    }
    return 0;
}


/*
 * 计算机的秒数
 */
#include <stdio.h>
#include <time.h>
#include <unistd.h>
int main(){
    
    for(;;)
    {
        printf("sec = %lu\n",time(0));
        sleep(1);
    }
    return 0;
}

/*
 * 随机数 产生函数 rand()
 * 设置随机的种子   srand();
 * 把系统的秒数  设置为随机数的种子 srand(time(0));
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main(){

    srand(time(0));

    for(int i = 0;i<7;i++)
    {
        //printf("%d\n",rand()%10);  //0 - 9
        printf("%d\n",rand()%32+1);  //0 - 31 
    }
    return 0;
}






/*
 * 输入一个数,输出其二进制
 */
#include <stdio.h>

int main(){

    int j=0;
    int c = 0x53; //0101 0011
    printf("输入一个数:");
    scanf("%x",&c);
    for(int i = 31;i>=0;i--)
    {
        if(c & 0x1<<i)  //1<<7   0000 0001 <<
        {                    //1000 0000
            printf("1"); 
            j++;
        }
        else
        {
            printf("0"); 
        }
    }

    printf("\n");
    printf("1的个数%d\n",j);
    return 0;
}

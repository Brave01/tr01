/*
 *  数组
 *    [练习]
 *       输入 5 个整数 , 
 *       打印他们的和
 *       然后 再输出这5个数
 *
 *    [练习]
 *       1. 生成一组32 选 7 的 彩票 
 *
 *       2. 如果生成的 一组有相同的数字
 *        重新生成,直到没有相同数字为止
 *        
 *   */
#include <stdio.h>
#include <unistd.h>

int main(){
    int a[5] ;
    int i=0;
    for(i = 0;i<5;i++)
    {
        printf("输入一个数:");
        scanf("%d",&a[i]);
    }

    printf("i = %d\n",i);  //5

    int sum = 0;
    for(i = 0;i<5;i++)
    {
       sum = sum + a[i];
    }
    printf("sum = %d\n",sum);

    for(i = 0;i<5;i++)
    {
        printf("%d\n",a[i]);
    }
    
    return 0;
}







/*
 *
 * while 语句
 */

#include <stdio.h>

int main(){

    int score = -1;
    //for(;;) //带次数的循环 用for
    //循环次数不确定的用 while
    /*
    while(score<0 || score>100)
    {
        printf("输入成绩:"); 
        scanf("%d",&score);
    }
    */
    while(1) //死循环
    {
        printf("输入成绩:"); 
        scanf("%d",&score);
        if(score >=0 && score <=100)
        {
            break;
        }
    }

    return 0;
}

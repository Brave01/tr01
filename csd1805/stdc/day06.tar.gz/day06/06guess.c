/*
 * 随机数 产生函数 rand()
 * 设置随机的种子   srand();
 * 把系统的秒数  设置为随机数的种子 srand(time(0));
 * 随机生产一部iphone 手机的价格 
 * 8000 - 9000
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main(){
    int price = 0;
    int guess = 0;

    srand(time(0));
    price = rand()%100*10+8000;       //8000 - 8990
   //printf("%d\n",price);//打印随机价格,仅用于测试 

    //编写下面代码
    //实现让用户不断猜这个价格,直到用户猜对为止
    //如果猜的数,大于价格,提示用户 "猜高了"
    //如果猜的数,小于价格,提示用户 "猜低了"
    for(;;)    
    {
        printf("输入您猜的价格:");
        scanf("%d",&guess);

        if(guess == price)
        {
            printf("猜对了\n"); 
            break;
        }
        if(guess > price)
        {
            printf("猜高了\n"); 
            continue; 
        }

        else
        {
            printf("猜低了\n"); 
        }
    }

    return 0;
}




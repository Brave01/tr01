/*
 *  内核 有输出缓冲区
 *  1. \n  会将 缓冲区内容 推送到屏幕
 *  2. 程序结束,缓冲区内容 推送到屏幕
 *  3. 缓冲区满
 *  4. fflush(stdout);
 */

#include <stdio.h>
#include <unistd.h>

int main(){
    int x = 0;
    for(int i=0;i<5;i++)
    {
        printf("i=%d ",i);
        fflush(stdout);
        sleep(1);
    }
    return 0;
}

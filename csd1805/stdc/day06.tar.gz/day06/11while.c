/*
 *
 * while 语句
 */

#include <stdio.h>

int main(){

    //for(int i = 0;i<5;i++)
    int i = 0;
    while(i<5)
    {
        printf("hello\n"); 
        i++;
    }
    return 0;
}

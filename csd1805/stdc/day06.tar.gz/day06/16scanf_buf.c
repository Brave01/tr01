/*
 *  输入缓冲区
 *   
 *   */
#include <stdio.h>
#include <unistd.h>

int main(){
    char c = 0;
    for(int i=0;i<5;i++)
    {
        printf("输入一个字符:");
        scanf("%c",&c);
        printf("c = %c\n",c);

        //清输入缓冲区
        scanf("%*[^\n]"); //清\n前的内容
        scanf("%*c");     //清\n

        sleep(1);
    }
    return 0;
}







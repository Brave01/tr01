/*
 * do  while 语句  注意后面的分号
 * 跟 if for  while  区别 先执行循环体
 * 再判断循环条件
 */

#include <stdio.h>

int main(){

    int score = 80;
    do 
    {
        printf("输入成绩:"); 
        scanf("%d",&score);
    }while(score<0 || score>100);

    return 0;
}

/*
 *    从键盘上输入一个单词 (多个字符) hello
 *       输出该单词
 *  数组
 *    [练习]
 *       输入 5 个整数 , 
 *       打印他们的和
 *       然后 再输出这5个数
 *   
 *   */
#include <stdio.h>
#include <unistd.h>

int main(){
    char c[5] ;
    for(int i = 0;i<1000;i++)
    {
        printf("输入一个字符:");
        scanf("%c",&c[i]);

        //清输入缓冲区
        scanf("%*[^\n]"); //清\n前的内容
        scanf("%*c");     //清\n
    }

    for(i = 0;i<5;i++)
    {
        printf("%c",c[i]);
    }
    printf("\n");
    return 0;
}








/*
 * break 语句使用
 *
 */
#include <stdio.h>
#include <unistd.h>
int  main(){

    int sec = 10;
    for(;;)
    {
        //printf("%d\n",sec); 
        sleep(1);
        sec--;
        if(sec %3 == 0)
        {
            continue;  //3的整数倍
        }
        printf("sec=%d\n",sec); // 
    }
        
    return 0;
}

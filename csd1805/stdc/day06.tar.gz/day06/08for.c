/*
 * 双重循环 循环控制变量演示
 */

#include <stdio.h>
#include <unistd.h>

int main(){

    for(int i=0;i<5;i++)
    {
        printf("     i=%d",i);
        sleep(1);
    }
    return 0;
}

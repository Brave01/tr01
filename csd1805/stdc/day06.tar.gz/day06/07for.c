/*
 * 循环嵌套
 * 1                     
 * 1 2 
 * 1 2 3 
 * 1 2 3 4 
 * 1 2 3 4 5
 * 1 2 3 4 5 6
 * 1 2 3 4 5 6 7
 * 1 2 3 4 5 6 7 8
 *
 *     *
 *     * *
 *     * * * 
 *     * * * *
 *     * * * * *
 *
 *     1x1=1
 *     1x2=2 2x2=4
 *     1x3=3 2x3=6 3x3=9
 *     1x4=4 2x4=8 3x4=12 4x4=16
 *
 */
#include <stdio.h>
int main(){
    int i = 1;
    //int j=1;

    for(;i<9;i++)
    {
        for(int j=1;j<=i;j++)
        {
            printf("%dX%d=%d  ",j,i,j*i); 
        }
        printf("\n");
    }
    return 0;
}



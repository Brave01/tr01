/*
 * 带参数的main函数
 * [练习]
 *      在理解下面程序的基础上 实现 打印任意多个参数的可执行程序
 *      实现多个数(参数)和的加法命令
 */
#include <stdio.h>
#include <stdlib.h>
int  main(int argc,char*argv[]){

    int sum = 0;
    printf("argc = %d\n",argc);
    for(int i = 1;i<argc;i++)
    {
        sum = sum + atoi(argv[i]);
        //printf("argv[%d] = %s\n",i,argv[i]);
    }
    printf("sum = %d\n",sum);
    return 0;
}

/*
 * 程序的编译过程
 */
#include <stdio.h>     //没有分号
//#include "day11.txt"
#define PI 3.14159    //没有分号  const
#define R  3

#define DOUBLE(n)     (n+n)

#define N 3
#define Y(n)  ((N+1)*n)

int main(){

    int i = 2*(N + Y(5+1)); //78 32 9  45
    //        2*( (24)) // 48

    printf("i = %d\n",i);

    printf("面积=%f\n",PI*R*R);
    int s = DOUBLE(5)*10;
    printf("s = %d\n",s); //100

    s = DOUBLE(9)*2;
    printf("s = %d\n",s); //36



    return 0;
}

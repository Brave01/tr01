#include <stdio.h>
 void printa()
{
    printf("我是main.c的print函数\n");
}




#include <stdio.h>
#include "add.h"
#include "print.h"
//static

int main(){
    
    //printa();
    printf("sum = %d\n",add(12,5));
    return 0;
}

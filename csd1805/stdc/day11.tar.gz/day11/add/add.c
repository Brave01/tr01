#include "add.h"
#include <stdio.h>
int add(int a,int b){
    print();
    return a+b;
}

//static 
void print(){
    printf("我是add.c的print函数\n");
}

#ifndef __PRINT_H__ //防止头文件交叉引用
#define __PRINT_H__ //头文件卫士

#include "add.h"
void printa();

#endif

#ifndef __ADD_H__
#define __ADD_H__

#include "print.h"
int add(int a,int b);
static void print();

#endif

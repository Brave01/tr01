/*
 * 内置 宏
 *  __FILE__      当前.C 文件名
    __LINE__      文件的行号
    __DATE__      文件的编译日期
    __TIME__      文件的编译时间
*/
#include <stdio.h>
#include <03hello.c>
int main(){
    printf("当前.c文件的文件名=%s\n",__FILE__);

    printf("当前代码的行号 %d\n",__LINE__);
    printf("当前可执行文件编译日期 %s\n",__DATE__);
    printf("当前可执行文件编译时间 %s\n",__TIME__);
    printf("使用的C编译器吗 %d\n",__STDC__);
    return 0;
}


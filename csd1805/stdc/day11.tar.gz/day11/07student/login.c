/*
 * 字符串比较运算   > < =
 *  strcmp
 *  [练习]
 *     1.在主函数中声明一个 passwd 字符数组,用来存储用户的密码.
 *     char passwd[12] = {0};
 *
 *     2.编写一个void setPasswd(char *passwd);
 *     传入的参数 是主函数中保存密码的字符数组passwd
 *     功能  设置用户密码
 *
 *     3.编写一个int login(const char *passwd)
 *           传入的参数 char *passwd  是主函数保存密码的数组
 *           功能   三次输入机会  输入正确返回1
 *                   错误返回 0
 *     4.主函数 先调用设置密码的函数
 *              再调用登录login函数
 */

#include <stdio.h>
#include <string.h>
#include "login.h"
void setPasswd(char *passwd)
{

    printf("输入设置的密码:");
    scanf("%s",passwd);
    //scanf("%s",passwd);
    //gets(passwd);
}

int login(const char *passwd)
{
    char input[13] = {0};
    //char *input; //指针变量  指向不确定,有可能执行 当前进程其他内存位置,导致系统不安全
    //char *input=NULL; //指针变量 赋值为NULL  指向0地址 0地址不可用,通过段错误可以结束程序

    //input 一定要指向一块有效的内存 -->局部变量 全局变量  
    //char a[13] = {0};
    //input = a;
    for(int i = 0;i<3;i++)
    {
        printf("请输入密码:");
        scanf("%s",input);
        if(strcmp(input,passwd)==0)
        {
            printf("passwd ok\n");
            return 1; 
        }

    }
    return 0;
}


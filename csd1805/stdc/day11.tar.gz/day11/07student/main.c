#include <stdio.h>
#include "login.h"
int menu(int a[],int len){
    int cmd = 0;
    printf("+------------------+\n");
    printf("|   学员管理菜单   |\n");
    printf("+------------------+\n");
    printf("|                  |\n");
    printf("|   1.录入学员     |\n");
    printf("|   2.打印成绩     |\n");
    printf("|   3.打印最高成绩 |\n");
    printf("|   4.打印平均成绩 |\n");
    printf("|   0.退出系统     |\n");
    printf("|                  |\n");
    printf("+------------------+\n");
    printf("选择您的操作:"); 
    scanf("%d",&cmd);
    switch(cmd)
    {
        case 1:  
            printf("输入成绩\n");
            break;

        case 2:
            printf("打印成绩\n");
            break;

        case 3:
            printf("最高成绩\n");
            break;

        case 4:
            printf("平均成绩\n");
            break;

        case 0:
            printf("退出系统\n");
            return 0;

        default:
            printf("操作数错误\n");
            break;
    }
    return 1;
}

int main(){
    int student[10];
    int cmd = 0;
    char passwd[13]; //只能存12个字符 + \0 
    int flag = 1;
    while(flag)
    {
        printf("+------------------+\n");
        printf("|      登录菜单    |\n");
        printf("+------------------+\n");
        printf("|                  |\n");
        printf("|   1.设置密码     |\n");
        printf("|   2.登录系统     |\n");
        printf("|   0.退出系统     |\n");
        printf("|                  |\n");
        printf("+------------------+\n");
        printf("选择您的操作:"); 
        scanf("%d",&cmd);
        switch(cmd)
        {
            case 1:  
                setPasswd(passwd);
                break;
            case 2:
                if(login(passwd)) //1
                {
                    //登录成功的代码
                    //printf("登录成功\n");
                    while(menu(student,10));
                }
                else
                {
                    printf("密码错误,登录失败\n"); 
                }
                flag = 0;
                break;
            case 0:
                printf("退出系统\n");
                flag = 0;
                break;

            default:
                printf("操作数错误\n");
                break;
        }

    }
    return 0;
}

/*
 * 写一个宏函数 返回 两个参数的最大值
 * 写一个返回一个数的 绝对值的宏函数ABS
 */
#include <stdio.h>
#define  DOUBLE(n)   ((n)+(n))
#define MAX(a,b)     ((a)>(b)?(a):(b))
#define ABS(n)       ((n)>=0?(n):-(n))

int max(int a,int b)
{
    /*
    if(a>b)
        return a;
    else
        return b;
   */
    return a>b?a:b;
}

int main(){
    printf("max = %d\n",MAX(5*1,2+7));
    printf("|-2| = %d\n",ABS(-2));
    printf("|-7-2| = %d\n",ABS(-7-2));
    return 0;
}


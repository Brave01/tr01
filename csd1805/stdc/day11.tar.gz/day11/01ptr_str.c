/*
 * 字符串数组
 */

#include <stdio.h>
#include <string.h>

int main(){
    char a[5][10] ={"关羽","张飞","刘备","赵云","小乔"};

    char name[10] = {0}; //用来存放输入的姓名
    for(int i = 0;i<5;i++)
    {
        printf("%s\n",a[i]);
    }
     
    //输入一个姓名 ,判读 该同学是否在上面的名单中
    printf("输入姓名:");
    scanf("%s",name);

    for(int i = 0;i<5;i++)
    {
         if(0 ==strcmp(a[i],name))
             printf("名单中由该同学\n");  
    }

    return 0;
}

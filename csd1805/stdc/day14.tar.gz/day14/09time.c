/*
 * 时间函数
 */

#include <stdio.h>
#include <time.h>
// typedef   long int  time_t
int main(){
    long int sec = 0;
    struct tm * pt = NULL; 

    //sec = time(0);
    time(&sec);

    printf("sec = %ld\n",sec);
    printf("ctime = %s\n",ctime(&sec)); //输出固定格式日历字符串

    pt = localtime(&sec); //可以定制显示日历信息
    printf("今天%d号,%d月,%d年\n",pt->tm_mday,pt->tm_mon+1,pt->tm_year+1900);
    //打印时分秒

    printf("asctime = %s\n",asctime(pt)); //跟ctime 效果一样

    return 0;
}

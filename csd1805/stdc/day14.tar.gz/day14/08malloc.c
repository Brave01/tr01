/*
 * 申请动态内存并使用 释放
 * [练习]
 *     1. 申请其他基本类型 动态内存,并使用, 使用后注意释放
 *     2. 申请一个Student类型的动态内存,并使用.注意释放
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct {
    char name[20];
    int score;
    int age;
}Student;

Student *input()
{
    Student *pi = NULL;
    pi = (Student *)malloc(sizeof(Student)*);
    //pi = (Student *)malloc(sizeof(Student)*1000);

    strcpy(pi->name,"如花");
    pi->score =  30;
    pi->age   = 18;

    return pi;
}

void output(Student* pi)
{
    printf("name = %s\n",pi->name);
    printf("score= %d\n",pi->score);
    printf("age  = %d\n",pi->age);
}
int main(){
    Student *ps = NULL; 
    ps = input();

    output(ps);

    //ps++; //不能修改指向分配内存的首地址,否则free 失败
    free(ps);
    ps = NULL; //pi原来指向的内存已经被free,pi赋值为NULL
    return 0;
}

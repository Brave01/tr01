/*
 * 申请动态内存并使用 释放
 * [练习]
 *     1. 申请其他基本类型 动态内存,并使用, 使用后注意释放
 *     2. 申请一个Student类型的动态内存,并使用.注意释放
 */
#include <stdio.h>
#include <stdlib.h>
typedef struct {
    char name[20];
    int score;
    int age;
}Student;
int main(){
    int *pi = NULL;
    pi = (int *)malloc(4);
    *pi = 200;
    printf("*pi = %d\n",*pi);
    free(pi);
    pi = NULL; //pi原来指向的内存已经被free,pi赋值为NULL
    return 0;
}

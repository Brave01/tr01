/* 
 * 变量初始化及使用
 */
#include <stdio.h>

int main(){
    int i = 0;//变量初始化,如果不初始化是不确定值
    int a = 50; //初始化a变量为50
    int b = 20;

    i = 3+2;//5
    //3+2 = i; //不能这么写
    printf("%d\n",i);//将i中数据以十进制格式输出

    i = a * b;
    printf("%d\n",i);//将i中数据以十进制格式输出
    return 0;
}

/*
 * 变量定义 及所占字节数
 * 练习：
 *      把剩下的类型 的字节数打印出来
 */
#include <stdio.h>
int main(){

    //变量  数据类型占用字节数
    char c;
    int  i;
    printf("c的大小=%d\n",sizeof(c));
    printf("i的大小=%d\n",sizeof(i));
    
    //常量  数据类型占用字节数
    printf("2的内存大小=%d\n",sizeof(2));
    printf("3.14的内存大小=%d\n",sizeof(3.14));

    //变量的地址(了解)
    printf("c变量的地址 %p\n",&c);
    printf("i变量的地址 %p\n",&i);


    return 0;
}

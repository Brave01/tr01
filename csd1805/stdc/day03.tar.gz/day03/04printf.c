/*
 * 变量的输出
 */

#include <stdio.h>

int main(){
    char c = 'a';// 10101010
    int i = 400;
    short s = 50;
    //unsigned 
    char uc = 200;

    float f = 3.14f; //单精度3.14
    double d = 3.14;

    printf("c=%c\n",c); // 字符输出
    printf("c=%d\n",c); // 十进制输出
    printf("c=0x%x\n",c); // 十六进制输出 0xab
    printf("c=0x%X\n",c); // 十六进制输出 0xAB


    printf("i=%d,i=0x%x\n",i,i); // 十进制输出
    printf("s = %hd\n",s);

    printf("uc = %u\n",uc); //读4个字节
    printf("uc = %d\n",uc);

    printf("f = %f,f=%g,f=%.3f\n",f,f,f);
    printf("d = %lf,d=%g,d=%.2lf\n",d,d,d);
   
    return 0;
}


/*
 * 变量的输入,
 * [练习：输入一个大写字母，输出其小写字母]
 */
#include <stdio.h>

int main(){
    int i = 0;
    char c = 0;

    //打印i的初始值
    printf("i = %d\n",i); //0

    //读入键盘上的值到i的存储区
    printf("请输入一个字符:");
    //scanf("%d",&i);
    scanf("%c",&c);
    //scanf("%x",&i);

    //打印i的输入后的值
    printf("i = %d\n",i);
    printf("c = %c\n",c);
    return 0;
}

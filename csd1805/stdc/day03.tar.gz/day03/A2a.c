/*
 * [练习：输入一个大写字母，输出其小写字母]
 */
#include <stdio.h>

int main(){
    char c = 0;

    //读入键盘上的值到c的存储区
    printf("请输入一个字符:");
    scanf("%c",&c);

    //查ascii 大写 和 小写 相差32

    //打印c的转换后的值
    printf("c = %c\n",c+32);
    return 0;
}

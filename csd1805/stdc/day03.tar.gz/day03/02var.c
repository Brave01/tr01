/*
 * 信息的表示，取值范围
 */
#include<stdio.h>

int main(){

    int i = 300;
    unsigned char uc;
    char c;
    //uc = 300;
    uc = i;
    c = 200;
    printf("%d\n",uc); //300?
    printf("%d\n",c); //200?
    return 0;
}

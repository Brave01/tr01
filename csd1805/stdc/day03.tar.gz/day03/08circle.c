/*
 * 输入半径，计算圆的面积
 */

#include <stdio.h>

int main(){
    int r = 0;
    float s = 0;
    float c = 0;

    //1.输入半径
    printf("输入半径:");
    scanf("%d",&r);

    //2.计算圆面积,周长

    s = 3.14 * r *r;
    c = 3.14 * 2 * r;

    //3.输出面积
    printf("面积=%f\n",s);
    printf("周长=%f\n",c);

    return 0;
}

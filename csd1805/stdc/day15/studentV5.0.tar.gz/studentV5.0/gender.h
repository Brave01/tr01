#ifndef __GENDER_H__
#define __GENDER_H__

typedef enum {FEMALE,MALE} GENDER;

void gender_scan(GENDER *gender);
void gender_print(GENDER gender);
#endif //__GENDER_H__

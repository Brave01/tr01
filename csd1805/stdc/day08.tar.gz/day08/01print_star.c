/*
 * 编程打印如下内容:
 

 *          //printf("*\n");
 **         //printf("**\n");
 ***        //printf("***\n");
 ****       //printf("****\n");
 *****      //printf("*****\n");
 ------     //printf("-------\n");
 *          //printf("*\n");
 **         //printf("**\n");
 ***        //printf("***\n");
 ****       //printf("****\n");
 *****      //printf("*****\n");
 ######     //printf("######\n");
 *          //printf("*\n");
 **         //printf("**\n");
 ***        //printf("***\n");
 ****       //printf("****\n");
 *****      //printf("*****\n");
~~~~~~~     //printf("~~~~~~\n");

*/
/*
[练习]
        1. 写一个 函数原型为  void  add() 的函数;
           功能   该函数 实现 2+3 的和,并打印 2+3的结果
           在主函数中 调用 add()函数
*/
#include <stdio.h>
//void print_star();  //说明print_star  是一个函数, 没有参数,返回值是void
                      //声明函数的原型
int main()
{

    print_star();     //函数的调用/使用 ,  先声明后使用
    printf("-------\n");

    print_star();
    printf("######\n");

    print_star();
    printf("~~~~~~\n");

    return 0;
}

void print_star()     //函数定义, 函数名 所代表的语句 ,
                      //函数定义和声明 函数名称及类型 一致
                      //c 不支持 在函数中定义函数
{
    for(int i = 0;i<5;i++)
    {
        for(int j=0;j<=i;j++) {
            printf("*");
        }
        printf("\n");
    }

}



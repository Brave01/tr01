/*
[练习]
       2.  函数原型 int  myabs(int x)
           功能 传入一个整数(正/负数) , 返回 该数的绝对值
          在主函数中通过scanf 输出一个 调用后 打印输出 该函数的返回结果

          1  -->  1
         -1  -->  1
*/
#include <stdio.h>
#include <stdlib.h>

int myabs(int num); //声明

//定义 myabs
int myabs(int num)
{
   // num == -20
    if(num<0)
    {
        num = -num;
    }
    //num == 20
    printf("myabs num = %d\n",num);
    printf("myabs num 地址 = %p\n",&num);

    return num;
}
int main(){
    int num = 0;    //在函数里面可以声明变量,局部变量,只能在当前函数通过
                    //变量名进行访问,在同一函数变量名不重名,其他函数之间
                    //可以重名
                    //
                    //C89  变量声明必须在函数最开始位置,C99无此规定

    printf("请输入一个整数:");
    scanf("%d",&num);
    //num == -20
    //num_abs = abs(num); //库函数

    int num_abs = 0;
    num_abs = myabs(num); //我们实现的函数
    printf("|%d| = %d\n",num,num_abs);
    printf("main num = %d\n",num);
    printf("main num地址 = %p\n",&num);
    //num == -20

    return 0;
}




/*
 * 将一个十进制数  转 二进制
 *     11%2  = 1  低位
 *11/2 =  5%2  = 1  第二位
  5/2  2  2%2  = 0  第三位
  2/2  1  1%2  = 1  第四位
       11  --> 1011
 */
#include <stdio.h>
#include <unistd.h>
void div(int n)
{
    int m = 0;
    m = n%2; 
    if(n)
    {
        div(n/2);
        printf("%d",m);
    }
    else
    {
        printf("0x");
    }
    fflush(stdout);
    sleep(1);
}
int main(){
    int n = 0;
    printf("输入一个数");
    scanf("%d",&n);
    div(n);
    printf("\n");
    return 0;
}

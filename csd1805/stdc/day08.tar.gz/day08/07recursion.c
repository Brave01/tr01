/*
 * 函数 调用
 *    1. 函数可以被其他函数调用        
 *       没有次数限制
 *
 *    2. 函数中可以调用函数? 函数里面可以调用自己, 递归函数
 *
 *    3. 计算n的阶乘
 */

#include<stdio.h>
#include<unistd.h>

void print_star(int n);
void print_star(int n)
{
    printf("start n = %d \n",n);
    sleep(1);
    if(n>0)
    {
        print_star(n-1);
        printf("end n = %d \n",n);
    }
    else
    {
        printf("end n = %d \n",n);
        return ;
    }
}

int main()
{
    print_star(5);
    return 0;
}

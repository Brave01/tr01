/*
[练习]
        1. 写一个 函数原型为  void  add() 的函数;
           功能   该函数 实现 2+3 的和,并打印 2+3的结果
           在主函数中 调用 add()函数
[练习]
       2.  函数原型 int  myabs(int x)
           功能 传入一个整数(正/负数) , 返回 该数的绝对值
          在主函数中通过scanf 输出一个 调用后 打印输出 该函数的返回结果

          1  -->  1
         -1  -->  1

*/
#include<stdio.h>
/*
//声明add函数原型
//void add();

//定义add函数
//void add(){
*/
//y=f(x)
int add(int a,int b);
int add(int a,int b){
    int c = a + b;
    return c; 
}/* //定义  没有分号*/

int main(){
    int sum = 0;
    sum = add(2,3);  /*//函数调用*/
    printf("sum = %d\n",sum);

    sum = add(20,30);  /*//函数调用*/
    printf("sum = %d\n",sum);

    int x = 0; 
    int y = 0;
    printf("输入x=");
    scanf("%d",&x);

    printf("输入y=");
    scanf("%d",&y);

    sum = add(x,y);  /*//函数调用*/
    printf("sum = %d\n",sum);

    return 0;
}










/*
 *[练习1]
         登录函数  int login();
         功能   用户输入密码,如该成功 返回1 
                如该用户输入三次都不对返回0
                密码用 int
         在main 函数中调用测试


  [练习2]  返回最大值函数   int max(int a,int b)   (周四)
         功能   传入两个 int类型的数,返回较大的值
         在main函数中 调用测试

 */
#include <stdio.h>

int login();
int login()
{  
    
}
int main(){

    if(login())
    {
        printf("密码正确!\n"); 
    }
    else
    {
        printf("密码错误\n"); 
    }

    return 0;
}



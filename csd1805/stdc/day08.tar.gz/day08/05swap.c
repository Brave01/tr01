/*
 * [练习]
 *        编写一个 void swap(int a,int b);
 *        功能:  实现 a ,b 值交换
 *
 *        调用  
 *           函数内部 修改不了 函数外部的局部变量
 *[练习1]
         登录函数  int login();
         功能   用户输入密码,如该成功 返回1 
                如该用户输入三次都不对返回0
                密码用 int
         在main 函数中调用测试


  [练习2]  返回最大值函数   int max(int a,int b)
         功能   传入两个 int类型的数,返回较大的值
         在main函数中 调用测试

 */
#include <stdio.h>

void swap(int a,int b);
void swap(int b,int a)
{  //写在函数参数上的形参 就是 该函数里面局部变量
    printf("交换前 a = %d,b=%d\n",a,b);
    int c = a;
    a = b;
    b = c;
    printf("交换后 a = %d,b=%d\n",a,b);
}
int main(){
    int a = 20;  //main  局部变量
    int b = 30;

    swap(a,b);  //实现a,b交换
    printf("main a = %d b = %d\n",a,b); //a = 20 b = 30
    return 0;
}



/*
 * 函数 调用
 *    1. 函数可以被其他函数调用        
 *       没有次数限制
 *
 *    2. 函数中可以调用函数? 函数里面可以调用自己, 递归函数
 *
 *    3. 计算n的阶乘
 *
 *    5! = 5*4*3*2*1
 *    5! = 5*4!
 *    1! = 1
 *
 *[练习]
 *    利用递归实现  输入一个数 n
 *    输出  从1+2+3+...+n 的和
 */
#include<stdio.h>
#include<unistd.h>
int fact(int n)
{
    if(n == 1)
    {
        printf("1\n");
        return 1;
    }
    else
    {
        printf("%d *",n);
        fflush(stdout);
        sleep(1);   
        return n*fact(n-1);
    }
}
int main()
{
    printf("5的阶乘=%d\n",fact(5));
    return 0;
}
